plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "tech.softclicks.mexinplay.core.player"
    compileSdk = 35

    defaultConfig {
        minSdk = 24
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    val media3Version = "1.4.1"
    val roomVersion = "2.6.1"

    // Playback engine. Kept as ExoPlayer/Media3 — see project notes on why
    // we didn't move to libVLC: cross-compiled native builds aren't worth
    // the CI cost for a solo-maintained app, and Media3 already covers
    // both audio and video session handling in one API surface.
    //
    // media3-exoplayer is `api`, not `implementation`: PlaybackController
    // exposes ExoPlayer directly via exoPlayerInstance(), a public method.
    // With `implementation`, that type is invisible to any module that
    // depends on core-player (e.g. :app) — Gradle only exposes
    // `api` dependencies transitively. The other three Media3 artifacts
    // stay `implementation` since MediaItem/Player usage is confined to
    // PlaybackController's method bodies, never its public signature.
    api("androidx.media3:media3-exoplayer:$media3Version")
    implementation("androidx.media3:media3-session:$media3Version")
    implementation("androidx.media3:media3-common:$media3Version")
    implementation("androidx.media3:media3-datasource:$media3Version")

    // Play-history persistence, feeds the shuffle heuristic.
    // room-runtime is `api`: PlayHistoryDatabase extends RoomDatabase, and
    // that supertype must be resolvable by any module calling
    // PlayHistoryDatabase.getInstance(...) — including :app. room-ktx has
    // no types in a public signature here, so it stays `implementation`.
    api("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")

    // `api`: PlaybackController's constructor takes a CoroutineScope as a
    // public (defaulted) parameter — same transitive-visibility issue.
    api("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
}
