package tech.softclicks.mexinplay.app

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import tech.softclicks.mexinplay.core.player.PlaybackController
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.AuraBackground
import tech.softclicks.mexinplay.core.ui.glass.FluxColors
import tech.softclicks.mexinplay.core.ui.glass.GlassTokens
import tech.softclicks.mexinplay.core.ui.glass.PulseColors
import tech.softclicks.mexinplay.core.ui.glass.ShellColors
import tech.softclicks.mexinplay.feature.flux.FluxHomeScreen
import tech.softclicks.mexinplay.feature.pulse.PulseHomeScreen

private const val ROUTE_PULSE = "pulse"
private const val ROUTE_FLUX = "flux"

@Composable
fun MexinNavHost(playbackController: PlaybackController, viewModel: MexinPlayViewModel) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ROUTE_PULSE

    val pulseQueue by viewModel.pulseQueue.collectAsState()
    val fluxQueue by viewModel.fluxQueue.collectAsState()
    val nowPlaying by viewModel.nowPlaying.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()

    val auraColor by animateColorAsState(
        targetValue = if (currentRoute == ROUTE_FLUX) FluxColors.glow else PulseColors.glow,
        animationSpec = tween(durationMillis = 600),
        label = "auraColor",
    )

    Box(modifier = Modifier.fillMaxSize().background(ShellColors.baseDeep)) {
        AuraBackground(color = auraColor)

        NavHost(navController = navController, startDestination = ROUTE_PULSE) {
            composable(ROUTE_PULSE) {
                PulseHomeScreen(
                    nowPlaying = nowPlaying,
                    isPlaying = isPlaying,
                    discoverItems = pulseQueue,
                    onSelectItem = { viewModel.play(it, pulseQueue) },
                    onPlayPause = { viewModel.togglePlayPause() },
                    onNext = { viewModel.playNext() },
                    onPrevious = { viewModel.playPrevious() },
                )
            }
            composable(ROUTE_FLUX) {
                FluxHomeScreen(
                    nowPlaying = nowPlaying,
                    isPlaying = isPlaying,
                    discoverItems = fluxQueue,
                    onSelectItem = { viewModel.play(it, fluxQueue) },
                    onPlayPause = { viewModel.togglePlayPause() },
                    onNext = { viewModel.playNext() },
                    onPrevious = { viewModel.playPrevious() },
                    playbackController = playbackController,
                )
            }
        }

        ExpensiveDock(
            currentRoute = currentRoute,
            onSelect = { route ->
                navController.navigate(route) { launchSingleTop = true; popUpTo(ROUTE_PULSE) { inclusive = false } }
            },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 24.dp),
        )
    }
}

@Composable
private fun ExpensiveDock(
    currentRoute: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(32.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(Color(0xFF0F0F14).copy(alpha = 0.82f), shape)
            .border(0.8.dp, Color.White.copy(alpha = 0.08f), shape)
    ) {
        // Inner highlight
        Box(
            modifier = Modifier
                .width(120.dp)
                .height(1.dp)
                .align(Alignment.TopCenter)
                .background(Color.White.copy(alpha = 0.10f))
        )
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            DockTab(
                label = "Pulse",
                icon = Icons.Filled.MusicNote,
                selected = currentRoute == ROUTE_PULSE,
                onClick = { onSelect(ROUTE_PULSE) }
            )
            DockTab(
                label = "Flux",
                icon = Icons.Filled.Movie,
                selected = currentRoute == ROUTE_FLUX,
                onClick = { onSelect(ROUTE_FLUX) }
            )
        }
    }
}

@Composable
private fun DockTab(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val bg = if (selected) Color.White.copy(alpha = 0.12f) else Color.Transparent
    val borderCol = if (selected) Color.White.copy(alpha = 0.10f) else Color.Transparent
    val contentCol = if (selected) Color.White else Color.White.copy(alpha = 0.45f)

    Row(
        modifier = Modifier
            .height(40.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(bg, RoundedCornerShape(24.dp))
            .border(0.5.dp, borderCol, RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(imageVector = icon, contentDescription = label, tint = contentCol, modifier = Modifier.size(18.dp))
        Text(text = label, style = AppTypography.eyebrowSmall, color = contentCol)
    }
}
