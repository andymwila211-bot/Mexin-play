package tech.softclicks.mexinplay.core.ui.glass

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Expensive glass: no harsh 1dp white line, no fake dome.
 * - Deep translucent tint (0.06)
 * - 0.5dp hairline border with top->bottom fade
 * - Subtle outer shadow for lift
 * - Top 1px inner highlight for depth
 * - Content sits on top with no extra glow
 *
 * When Haze is available, add Modifier.hazeEffect outside. This file is the seam.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 28.dp,
    tint: Color = GlassTokens.tint,
    withShadow: Boolean = true,
    content: @Composable () -> Unit,
) {
    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier
            .then(if (withShadow) Modifier.shadow(24.dp, shape, spotColor = GlassTokens.shadow.copy(alpha = 0.5f), ambientColor = GlassTokens.shadow.copy(alpha = 0.3f)) else Modifier)
            .clip(shape)
            .background(color = tint, shape = shape)
            .border(
                width = 0.8.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        GlassTokens.borderTop,
                        GlassTokens.borderBottom,
                    )
                ),
                shape = shape,
            ),
    ) {
        // Top inner highlight - 1px, 40% width centered fade
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.Transparent,
                            GlassTokens.highlight.copy(alpha = 0.6f),
                            Color.Transparent,
                        )
                    )
                )
        )
        content()
    }
}

@Composable
fun GlassSurfaceRaised(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 28.dp,
    content: @Composable () -> Unit,
) {
    GlassSurface(modifier = modifier, cornerRadius = cornerRadius, tint = GlassTokens.tintRaised, withShadow = true, content = content)
}
