package tech.softclicks.mexinplay.core.ui.glass

import androidx.compose.ui.graphics.Color

/**
 * Expensive palette: ink blacks, not violet-blacks.
 * Accents are desaturated and used sparingly - headlines stay near-white,
 * accent only for active states / progress.
 */
object PulseColors {
    val background = Color(0xFF050507)
    val surface = Color(0xFF0F0F12)
    val surfaceRaised = Color(0xFF17171E)
    val glow = Color(0xFF6B5CFF)        // single aura source, desaturated
    val glowSoft = Color(0xFF9D8CFF)
    val accent = Color(0xFFF2F0FF)      // near-white for primary text/active
    val accentSecondary = Color(0xFF8B85A8) // muted for secondary
    val onBackground = Color(0xFFF5F3FF)
    val onBackgroundMuted = Color(0xFF9A96AF)
}

object FluxColors {
    val background = Color(0xFF04080C)
    val surface = Color(0xFF0C141C)
    val surfaceRaised = Color(0xFF141E29)
    val glow = Color(0xFF2EA8FF)
    val glowSoft = Color(0xFF7ED4FF)
    val accent = Color(0xFFEFF8FF)
    val accentSecondary = Color(0xFF8AA4B5)
    val onBackground = Color(0xFFEFF6FF)
    val onBackgroundMuted = Color(0xFF8BA0B2)
}

object ShellColors {
    val base = Color(0xFF050507)
    val baseDeep = Color(0xFF020203)
}

object GlassTokens {
    val tint = Color.White.copy(alpha = 0.06f)
    val tintRaised = Color.White.copy(alpha = 0.08f)
    val borderTop = Color.White.copy(alpha = 0.10f)
    val borderBottom = Color.White.copy(alpha = 0.02f)
    val highlight = Color.White.copy(alpha = 0.14f)
    val shadow = Color.Black.copy(alpha = 0.6f)
}
