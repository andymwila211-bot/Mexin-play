package tech.softclicks.mexinplay.core.ui.glass

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun AuraBackground(
    color: Color,
    modifier: Modifier = Modifier,
) {
    Box(modifier = modifier.fillMaxSize().background(ShellColors.baseDeep)) {
        // Primary orb - top right, soft and large
        Box(
            modifier = Modifier
                .size(680.dp)
                .offset(x = 120.dp, y = (-200).dp)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            color.copy(alpha = 0.18f),
                            color.copy(alpha = 0.06f),
                            Color.Transparent,
                        ),
                    ),
                ),
        )
        // Secondary orb - bottom left, deeper, for depth
        Box(
            modifier = Modifier
                .size(520.dp)
                .offset(x = (-180).dp, y = 320.dp)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            color.copy(alpha = 0.10f),
                            Color.Transparent,
                        ),
                    ),
                ),
        )
        // Vignette - makes center feel lifted
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.45f),
                        ),
                        radius = 1200f
                    )
                )
        )
        // Top soft light
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.03f),
                            Color.Transparent,
                        ),
                        endY = 400f
                    )
                )
        )
    }
}
