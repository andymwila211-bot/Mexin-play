package tech.softclicks.mexinplay.feature.flux

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.PlayerView
import tech.softclicks.mexinplay.core.player.PlaybackController
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.FluxColors
import tech.softclicks.mexinplay.core.ui.glass.GlassSurface

@Composable
fun FluxHomeScreen(
    nowPlaying: PlayableItem?,
    isPlaying: Boolean,
    discoverItems: List<PlayableItem>,
    onSelectItem: (PlayableItem) -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    playbackController: PlaybackController,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(bottom = 120.dp, top = 12.dp),
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = "FLUX", style = AppTypography.eyebrowSmall, color = Color.White.copy(alpha = 0.35f))
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = "Cinema", style = AppTypography.displayLarge, color = Color.White)
            }
        }

        VideoSurface(nowPlaying = nowPlaying, playbackController = playbackController)

        Spacer(modifier = Modifier.height(14.dp))

        MinimalFluxProgress(
            progress = 0.32f,
            elapsed = "00:00",
            total = nowPlaying?.let { formatDuration(it.durationMs) } ?: "--:--"
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SmallCircleButton(icon = Icons.Filled.PlayArrow, rotated = true, onClick = onPrevious)
            Spacer(modifier = Modifier.width(24.dp))
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .clickable(onClick = onPlayPause),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.size(26.dp)
                )
            }
            Spacer(modifier = Modifier.width(24.dp))
            SmallCircleButton(icon = Icons.Filled.PlayArrow, onClick = onNext)
        }

        Spacer(modifier = Modifier.height(28.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "UP NEXT", style = AppTypography.eyebrowSmall, color = Color.White.copy(alpha = 0.32f))
            Text(text = "${discoverItems.size} videos", style = AppTypography.dataMonoSmall, color = Color.White.copy(alpha = 0.28f))
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (discoverItems.isEmpty()) {
            GlassSurface(modifier = Modifier.fillMaxWidth(), cornerRadius = 20.dp) {
                Column(modifier = Modifier.fillMaxWidth().padding(20.dp)) {
                    Text(text = "No videos", style = AppTypography.headline, color = Color.White.copy(alpha = 0.8f))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Grant video access to see your library. Same engine as Pulse.", style = AppTypography.bodyMuted, color = Color.White.copy(alpha = 0.42f))
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                discoverItems.take(10).forEach { item ->
                    FluxRow(item = item, isActive = item.id == nowPlaying?.id, onClick = { onSelectItem(item) })
                }
            }
        }
    }
}

@Composable
private fun VideoSurface(nowPlaying: PlayableItem?, playbackController: PlaybackController) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF0E1216))
            .border(0.6.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(20.dp))
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                PlayerView(context).apply {
                    useController = false
                    player = playbackController.exoPlayerInstance()
                }
            },
            update = { view -> view.player = playbackController.exoPlayerInstance() },
        )

        if (nowPlaying == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(text = "No video", style = AppTypography.bodyMuted, color = Color.White.copy(alpha = 0.25f))
            }
        }

        // Premium scrim
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(96.dp)
                .align(Alignment.BottomStart)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.72f)),
                    )
                )
        )
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
        ) {
            Text(
                text = nowPlaying?.title ?: "Nothing playing",
                style = AppTypography.headline,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = nowPlaying?.artistOrChannel ?: "Select a video",
                style = AppTypography.bodyMuted,
                color = Color.White.copy(alpha = 0.6f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun MinimalFluxProgress(progress: Float, elapsed: String, total: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier.fillMaxWidth().height(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(modifier = Modifier.fillMaxWidth().height(2.dp).clip(RoundedCornerShape(2.dp)).background(Color.White.copy(alpha = 0.10f)))
            Box(
                modifier = Modifier
                    .fillMaxWidth(progress.coerceIn(0f, 1f))
                    .height(2.dp)
                    .align(Alignment.CenterStart)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White)
            )
            Box(
                modifier = Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).height(24.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(Color.White).border(2.dp, Color.Black.copy(alpha = 0.15f), CircleShape))
            }
        }
        Row(modifier = Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = elapsed, style = AppTypography.dataMonoSmall, color = Color.White.copy(alpha = 0.36f))
            Text(text = total, style = AppTypography.dataMonoSmall, color = Color.White.copy(alpha = 0.36f))
        }
    }
}

@Composable
private fun SmallCircleButton(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, rotated: Boolean = false) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.06f))
            .border(0.5.dp, Color.White.copy(alpha = 0.08f), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun FluxRow(item: PlayableItem, isActive: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (isActive) Color.White.copy(alpha = 0.07f) else Color.White.copy(alpha = 0.03f))
            .border(0.5.dp, if (isActive) Color.White.copy(alpha = 0.10f) else Color.White.copy(alpha = 0.04f), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF151A20))
                .border(0.5.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(10.dp))
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = item.title, style = AppTypography.body, color = Color.White.copy(alpha = 0.88f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(text = item.artistOrChannel ?: formatDuration(item.durationMs), style = AppTypography.bodyMuted, color = Color.White.copy(alpha = 0.42f), maxLines = 1)
        }
        Text(text = formatDuration(item.durationMs), style = AppTypography.dataMonoSmall, color = Color.White.copy(alpha = 0.26f))
    }
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
