package tech.softclicks.mexinplay.feature.pulse

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.GlassSurface
import tech.softclicks.mexinplay.core.ui.glass.GlassTokens
import tech.softclicks.mexinplay.core.ui.glass.PulseColors

@Composable
fun PulseHomeScreen(
    nowPlaying: PlayableItem?,
    isPlaying: Boolean,
    discoverItems: List<PlayableItem>,
    onSelectItem: (PlayableItem) -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(bottom = 120.dp, top = 12.dp),
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "PULSE",
                    style = AppTypography.eyebrowSmall,
                    color = Color.White.copy(alpha = 0.4f),
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Listening",
                    style = AppTypography.displayLarge,
                    color = Color.White,
                )
            }
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.06f))
                    .border(0.5.dp, Color.White.copy(alpha = 0.08f), CircleShape)
                    .clickable { },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.MoreHoriz, contentDescription = null, tint = Color.White.copy(alpha = 0.6f), modifier = Modifier.size(18.dp))
            }
        }

        // Artwork - expensive: large, soft shadow, inner hairline, no neon gradient
        ArtworkCard(
            title = nowPlaying?.title,
            artist = nowPlaying?.artistOrChannel,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Title block - editorial, not centered blob
        Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.Start) {
            Text(
                text = nowPlaying?.title ?: "No track selected",
                style = AppTypography.headlineLarge,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = nowPlaying?.artistOrChannel ?: "Choose from up next",
                style = AppTypography.bodyMuted,
                color = PulseColors.onBackgroundMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Progress - minimal, 2px track, no wave
        MinimalProgress(
            progress = 0.32f, // TODO wire to real position
            elapsed = "1:24",
            total = nowPlaying?.let { formatDuration(it.durationMs) } ?: "--:--"
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Controls - quiet, no glowing dome
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ControlButton(icon = Icons.Filled.SkipPrevious, size = 44.dp, onClick = onPrevious, tintAlpha = 0.7f)
            Spacer(modifier = Modifier.width(24.dp))
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .clickable(onClick = onPlayPause),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.size(26.dp)
                )
            }
            Spacer(modifier = Modifier.width(24.dp))
            ControlButton(icon = Icons.Filled.SkipNext, size = 44.dp, onClick = onNext, tintAlpha = 0.7f)
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Up Next - premium list, not horizontal pills
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "UP NEXT", style = AppTypography.eyebrowSmall, color = Color.White.copy(alpha = 0.35f))
            Text(text = "${discoverItems.size} tracks", style = AppTypography.dataMonoSmall, color = Color.White.copy(alpha = 0.3f))
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (discoverItems.isEmpty()) {
            GlassSurface(modifier = Modifier.fillMaxWidth(), cornerRadius = 20.dp) {
                Column(modifier = Modifier.fillMaxWidth().padding(20.dp)) {
                    Text(text = "Library empty", style = AppTypography.headline, color = Color.White.copy(alpha = 0.8f))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Grant media permission to see your tracks here. Shuffle is ready when you are.",
                        style = AppTypography.bodyMuted,
                        color = Color.White.copy(alpha = 0.45f)
                    )
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                discoverItems.take(12).forEach { item ->
                    TrackRow(item = item, isActive = item.id == nowPlaying?.id, onClick = { onSelectItem(item) })
                }
            }
        }
    }
}

@Composable
private fun ArtworkCard(title: String?, artist: String?, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(32.dp))
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF1A1A22),
                        Color(0xFF0E0E13)
                    )
                )
            )
            .border(0.6.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.12f), Color.White.copy(alpha = 0.02f))), RoundedCornerShape(32.dp))
    ) {
        // Subtle inner vignette for depth
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color.White.copy(alpha = 0.04f), Color.Transparent),
                        radius = 800f
                    )
                )
        )
        // Placeholder monogram when no art
        if (title == null) {
            Text(
                text = "∅",
                style = AppTypography.displayLarge,
                color = Color.White.copy(alpha = 0.15f),
                modifier = Modifier.align(Alignment.Center)
            )
        } else {
            // When real art arrives, Coil will fill here. For now, subtle letter
            Box(modifier = Modifier.align(Alignment.Center)) {
                Text(
                    text = title.take(1).uppercase(),
                    style = AppTypography.displayLarge.copy(fontSize = androidx.compose.ui.unit.TextUnit.Unspecified),
                    color = Color.White.copy(alpha = 0.08f),
                    modifier = Modifier.align(Alignment.Center)
                )
            }
            // Bottom scrim for legibility if we ever overlay
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .align(Alignment.BottomCenter)
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.35f))
                        )
                    )
            )
        }
        // Top highlight
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.12f), Color.Transparent)
                    )
                )
        )
    }
}

@Composable
private fun MinimalProgress(progress: Float, elapsed: String, total: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(24.dp),
            contentAlignment = Alignment.Center
        ) {
            // Track bg
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.10f))
            )
            // Progress fill
            Box(
                modifier = Modifier
                    .fillMaxWidth(progress.coerceIn(0f, 1f))
                    .height(2.dp)
                    .align(Alignment.CenterStart)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White)
            )
            // Thumb
            Box(
                modifier = Modifier
                    .fillMaxWidth(progress.coerceIn(0f, 1f))
                    .height(24.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .border(2.dp, Color.Black.copy(alpha = 0.2f), CircleShape)
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = elapsed, style = AppTypography.dataMonoSmall, color = Color.White.copy(alpha = 0.4f))
            Text(text = total, style = AppTypography.dataMonoSmall, color = Color.White.copy(alpha = 0.4f))
        }
    }
}

@Composable
private fun TrackRow(item: PlayableItem, isActive: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (isActive) Color.White.copy(alpha = 0.07f) else Color.White.copy(alpha = 0.03f))
            .border(0.5.dp, if (isActive) Color.White.copy(alpha = 0.10f) else Color.White.copy(alpha = 0.04f), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF1C1C22))
                .border(0.5.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(text = item.title.take(1).uppercase(), style = AppTypography.eyebrowSmall, color = Color.White.copy(alpha = 0.3f))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = item.title, style = AppTypography.body, color = if (isActive) Color.White else Color.White.copy(alpha = 0.85f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(text = item.artistOrChannel ?: formatDuration(item.durationMs), style = AppTypography.bodyMuted, color = Color.White.copy(alpha = 0.45f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = formatDuration(item.durationMs), style = AppTypography.dataMonoSmall, color = Color.White.copy(alpha = 0.28f))
    }
}

@Composable
private fun ControlButton(icon: androidx.compose.ui.graphics.vector.ImageVector, size: androidx.compose.ui.unit.Dp, onClick: () -> Unit, tintAlpha: Float) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.06f))
            .border(0.5.dp, Color.White.copy(alpha = 0.08f), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = Color.White.copy(alpha = tintAlpha), modifier = Modifier.size(20.dp))
    }
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
