package tech.softclicks.mexinplay.feature.flux

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.FluxColors
import tech.softclicks.mexinplay.core.ui.glass.GlassSurface

/**
 * Same structural upgrades as Pulse (top bar, waveform-style scrubber,
 * horizontal discover row) but keeps the 16:9 landscape hero — a circle
 * doesn't fit video thumbnails the way it fits album art, so that one
 * element intentionally isn't shared between the two screens.
 */
@Composable
fun FluxHomeScreen(
    nowPlaying: PlayableItem?,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .padding(top = 56.dp, bottom = 130.dp),
    ) {
        TopBar()

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 20.dp)
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(24.dp))
                .background(
                    Brush.linearGradient(listOf(FluxColors.glow, FluxColors.accent, FluxColors.accentSecondary))
                ),
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp),
        ) {
            Text(
                text = nowPlaying?.title ?: "Nothing playing",
                style = AppTypography.headline.copy(fontSize = 20.sp),
                color = FluxColors.onBackground,
            )
            Text(
                text = nowPlaying?.artistOrChannel ?: "Pick something from your library",
                style = AppTypography.bodyMuted,
                color = FluxColors.onBackgroundMuted,
                modifier = Modifier.padding(top = 2.dp),
            )
        }

        TransportRow()

        WaveformProgress(
            elapsedLabel = "04:12",
            totalLabel = nowPlaying?.let { formatDuration(it.durationMs) } ?: "18:24",
            progress = 0.23f,
        )

        Text(
            text = "Discover",
            style = AppTypography.headline,
            color = FluxColors.onBackground,
            modifier = Modifier.padding(top = 32.dp, bottom = 12.dp),
        )

        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            listOf("City Nights" to "8 episodes", "Field Notes" to "12 episodes", "Quiet Hours" to "5 episodes")
                .forEach { (title, subtitle) -> DiscoverCard(title, subtitle) }
        }
    }
}

@Composable
private fun TopBar() {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "Mexin Play",
            style = AppTypography.headline.copy(fontSize = 18.sp),
            color = FluxColors.onBackground,
        )
        GlassSurface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 14.dp),
            cornerRadius = 100.dp,
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    Icons.Filled.Search,
                    contentDescription = "Search",
                    tint = FluxColors.onBackgroundMuted,
                )
                Text(
                    text = "Search your library",
                    style = AppTypography.bodyMuted,
                    color = FluxColors.onBackgroundMuted,
                    modifier = Modifier.padding(start = 10.dp),
                )
            }
        }
    }
}

@Composable
private fun TransportRow() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircleIconButton(icon = Icons.Filled.Replay10, size = 48.dp, filled = false)
        CircleIconButton(icon = Icons.Filled.PlayArrow, size = 68.dp, filled = true)
        CircleIconButton(icon = Icons.Filled.Forward10, size = 48.dp, filled = false)
    }
}

@Composable
private fun CircleIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, size: androidx.compose.ui.unit.Dp, filled: Boolean) {
    if (filled) {
        Box(
            modifier = Modifier.size(size).clip(CircleShape).background(FluxColors.accent),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = Color.Black)
        }
    } else {
        GlassSurface(modifier = Modifier.size(size), cornerRadius = size / 2) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = FluxColors.onBackground)
            }
        }
    }
}

@Composable
private fun WaveformProgress(elapsedLabel: String, totalLabel: String, progress: Float) {
    Column(modifier = Modifier.padding(top = 24.dp)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Color.White.copy(alpha = 0.12f)),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(progress)
                    .height(3.dp)
                    .background(
                        Brush.horizontalGradient(listOf(FluxColors.accent, FluxColors.accentSecondary))
                    ),
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(text = elapsedLabel, style = AppTypography.dataMono, color = FluxColors.onBackgroundMuted)
            Text(text = totalLabel, style = AppTypography.dataMono, color = FluxColors.onBackgroundMuted)
        }
    }
}

@Composable
private fun DiscoverCard(title: String, subtitle: String) {
    Column(modifier = Modifier.width(140.dp)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(12.dp))
                .background(Brush.linearGradient(listOf(FluxColors.glow, FluxColors.accentSecondary))),
        )
        Text(
            text = title,
            style = AppTypography.bodyMuted,
            color = FluxColors.onBackground,
            modifier = Modifier.padding(top = 8.dp),
        )
        Text(
            text = subtitle,
            style = AppTypography.dataMono.copy(fontSize = 11.sp),
            color = FluxColors.onBackgroundMuted,
        )
    }
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
