package tech.softclicks.mexinplay.feature.flux

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.FluxColors
import tech.softclicks.mexinplay.core.ui.glass.GlassSurface

/**
 * Same hero-first pattern as Pulse — see that file's doc comment — but
 * with a 16:9 shape, since that's the actual shape of video content, and
 * transport icons suited to video (10s skip, fullscreen) instead of
 * shuffle/repeat.
 */
@Composable
fun FluxHomeScreen(
    nowPlaying: PlayableItem?,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .padding(top = 64.dp, bottom = 130.dp),
    ) {
        HeroThumbnail(nowPlaying)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 24.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Replay10, contentDescription = "Back 10s", tint = FluxColors.onBackgroundMuted)
            PlayButton()
            Icon(Icons.Filled.Forward10, contentDescription = "Forward 10s", tint = FluxColors.onBackground)
            Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = FluxColors.onBackground)
            Icon(Icons.Filled.Fullscreen, contentDescription = "Fullscreen", tint = FluxColors.onBackgroundMuted)
        }

        Text(
            text = "Up next",
            style = AppTypography.headline,
            color = FluxColors.onBackground,
            modifier = Modifier.padding(top = 32.dp, bottom = 12.dp),
        )

        listOf("City Nights Ep. 3", "Field Notes", "Quiet Hours").forEach { title ->
            QueueRow(title = title, subtitle = "Unknown channel", durationLabel = "1" + (title.length % 6) + ":24")
        }
    }
}

@Composable
private fun HeroThumbnail(nowPlaying: PlayableItem?) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.linearGradient(
                    listOf(FluxColors.glow, FluxColors.accent, FluxColors.accentSecondary)
                )
            ),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomStart)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f)),
                    )
                )
                .padding(18.dp),
        ) {
            Column {
                Text(
                    text = nowPlaying?.title ?: "Nothing playing",
                    style = AppTypography.displayLarge.copy(fontSize = 22.sp),
                    color = Color.White,
                )
                Row(
                    modifier = Modifier.padding(top = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = nowPlaying?.artistOrChannel ?: "Pick something from your library",
                        style = AppTypography.bodyMuted,
                        color = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        text = nowPlaying?.let { formatDuration(it.durationMs) } ?: "--:--",
                        style = AppTypography.dataMono,
                        color = FluxColors.accentSecondary,
                    )
                }
            }
        }
    }
}

@Composable
private fun PlayButton() {
    Box(
        modifier = Modifier
            .size(64.dp)
            .clip(CircleShape)
            .background(FluxColors.accent),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Filled.PlayArrow, contentDescription = "Play", tint = Color.Black)
    }
}

@Composable
private fun QueueRow(title: String, subtitle: String, durationLabel: String) {
    GlassSurface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp),
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(width = 64.dp, height = 40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        Brush.linearGradient(listOf(FluxColors.accent, FluxColors.glow))
                    ),
            )
            Column(
                modifier = Modifier
                    .padding(start = 12.dp)
                    .weight(1f),
            ) {
                Text(text = title, style = AppTypography.body, color = FluxColors.onBackground)
                Text(
                    text = subtitle,
                    style = AppTypography.bodyMuted,
                    color = FluxColors.onBackgroundMuted,
                )
            }
            Text(text = durationLabel, style = AppTypography.dataMono, color = FluxColors.accentSecondary)
        }
    }
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
