package tech.softclicks.mexinplay.feature.flux

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.PlayerView
import tech.softclicks.mexinplay.core.player.PlaybackController
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.FluxColors

/**
 * Netflix-shaped, not Spotify-shaped: a real PlayerView renders actual
 * video frames (was previously audio-only despite the video-shaped UI —
 * see build.gradle.kts comment), title overlays directly on the video
 * with a scrim instead of sitting in a separate glass card, flat minimal
 * controls instead of the domed/glowing music-player button, and a
 * straight progress bar instead of a waveform. Content is bottom-
 * anchored (top Spacer with weight) so the screen breathes at the top
 * instead of the video starting immediately under the status bar.
 */
@Composable
fun FluxHomeScreen(
    nowPlaying: PlayableItem?,
    isPlaying: Boolean,
    discoverItems: List<PlayableItem>,
    onSelectItem: (PlayableItem) -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    playbackController: PlaybackController,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .padding(bottom = 130.dp),
    ) {
        Spacer(modifier = Modifier.weight(1f))

        VideoSurface(nowPlaying = nowPlaying, playbackController = playbackController)

        Spacer(modifier = Modifier.height(14.dp))

        StraightProgress(
            elapsedLabel = "00:00",
            totalLabel = nowPlaying?.let { formatDuration(it.durationMs) } ?: "--:--",
            progress = 0f,
            accent = FluxColors.accent,
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 14.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FlatIconButton(icon = Icons.Filled.Replay10, contentDescription = "Back 10s", onClick = onPrevious)
            Spacer(modifier = Modifier.width(28.dp))
            FlatIconButton(
                icon = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play",
                onClick = onPlayPause,
                primary = true,
            )
            Spacer(modifier = Modifier.width(28.dp))
            FlatIconButton(icon = Icons.Filled.Forward10, contentDescription = "Forward 10s", onClick = onNext)
        }

        Text(
            text = "Discover",
            style = AppTypography.eyebrow,
            color = Color.White,
            modifier = Modifier.padding(top = 24.dp, bottom = 12.dp),
        )

        if (discoverItems.isEmpty()) {
            Text(
                text = "No videos found yet — grant media access or add video to your device.",
                style = AppTypography.bodyMuted,
                color = Color.White.copy(alpha = 0.6f),
            )
        } else {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                discoverItems.take(10).forEach { item ->
                    DiscoverTile(item = item, onClick = { onSelectItem(item) })
                }
            }
        }
    }
}

@Composable
private fun VideoSurface(nowPlaying: PlayableItem?, playbackController: PlaybackController) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(14.dp)),
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                PlayerView(context).apply {
                    useController = false // custom controls below, not ExoPlayer's default overlay
                    player = playbackController.exoPlayerInstance()
                }
            },
            update = { view -> view.player = playbackController.exoPlayerInstance() },
        )

        // Title overlay — Netflix-tile pattern: metadata sits directly on
        // the content, not in a separate card below it.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomStart)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f)),
                    )
                )
                .padding(14.dp),
        ) {
            Column {
                Text(
                    text = nowPlaying?.title ?: "Nothing playing",
                    style = AppTypography.headline,
                    color = Color.White,
                )
                Text(
                    text = nowPlaying?.artistOrChannel ?: "Pick something from Discover below",
                    style = AppTypography.bodyMuted,
                    color = Color.White.copy(alpha = 0.75f),
                )
            }
        }
    }
}

@Composable
private fun StraightProgress(elapsedLabel: String, totalLabel: String, progress: Float, accent: Color) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Color.White.copy(alpha = 0.15f)),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(progress.coerceIn(0f, 1f))
                    .height(3.dp)
                    .background(accent),
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(text = elapsedLabel, style = AppTypography.dataMono, color = Color.White.copy(alpha = 0.6f))
            Text(text = totalLabel, style = AppTypography.dataMono, color = Color.White.copy(alpha = 0.6f))
        }
    }
}

@Composable
private fun FlatIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    primary: Boolean = false,
) {
    val size = if (primary) 56.dp else 40.dp
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(if (primary) Color.White else Color.White.copy(alpha = 0.12f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (primary) Color.Black else Color.White,
        )
    }
}

@Composable
private fun DiscoverTile(item: PlayableItem, onClick: () -> Unit) {
    Column(modifier = Modifier.width(150.dp).clickable(onClick = onClick)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(10.dp))
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(FluxColors.accentSecondary, FluxColors.glow),
                    )
                ),
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = item.title, style = AppTypography.body, color = Color.White, maxLines = 1)
        Text(
            text = item.artistOrChannel ?: formatDuration(item.durationMs),
            style = AppTypography.bodyMuted,
            color = Color.White.copy(alpha = 0.6f),
            maxLines = 1,
        )
    }
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
