package tech.softclicks.mexinplay.feature.flux

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.FluxColors
import tech.softclicks.mexinplay.core.ui.glass.GlassSurface

/**
 * Same restructure as Pulse — one glass card holds art+title+transport+
 * progress as a unit, Discover sits outside it on the plain background.
 * 16:9 hero instead of a circle (video thumbnails aren't square), same
 * reasoning as before.
 */
@Composable
fun FluxHomeScreen(
    nowPlaying: PlayableItem?,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .padding(top = 56.dp, bottom = 130.dp),
    ) {
        SearchButton()

        PlayerCard(nowPlaying)

        Text(
            text = "Discover",
            style = AppTypography.headline,
            color = FluxColors.onBackground,
            modifier = Modifier.padding(top = 28.dp, bottom = 12.dp),
        )

        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            listOf("City Nights" to "8 episodes | Drama", "Field Notes" to "12 episodes | Docs", "Quiet Hours" to "5 episodes | Ambient")
                .forEach { (title, subtitle) -> DiscoverCard(title, subtitle) }
        }
    }
}

@Composable
private fun SearchButton() {
    GlassSurface(cornerRadius = 100.dp) {
        Icon(
            Icons.Filled.Search,
            contentDescription = "Search",
            tint = FluxColors.onBackground,
            modifier = Modifier.padding(10.dp),
        )
    }
}

@Composable
private fun PlayerCard(nowPlaying: PlayableItem?) {
    GlassSurface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 20.dp),
        cornerRadius = 28.dp,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        Brush.linearGradient(listOf(FluxColors.glow, FluxColors.accent, FluxColors.accentSecondary))
                    ),
            )

            Text(
                text = nowPlaying?.title ?: "City Nights Ep. 3",
                style = AppTypography.headline.copy(fontSize = 20.sp),
                color = FluxColors.onBackground,
                modifier = Modifier.padding(top = 16.dp),
            )
            Text(
                text = nowPlaying?.artistOrChannel ?: "Pick something from your library",
                style = AppTypography.bodyMuted,
                color = FluxColors.onBackgroundMuted,
                modifier = Modifier.padding(top = 2.dp),
            )

            TransportRow()

            WaveformProgress(
                elapsedLabel = "04:12",
                totalLabel = nowPlaying?.let { formatDuration(it.durationMs) } ?: "18:24",
                progress = 0.23f,
            )
        }
    }
}

@Composable
private fun TransportRow() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircleIconButton(icon = Icons.Filled.Replay10, size = 44.dp, filled = false)
        CircleIconButton(icon = Icons.Filled.PlayArrow, size = 64.dp, filled = true)
        CircleIconButton(icon = Icons.Filled.Forward10, size = 44.dp, filled = false)
    }
}

@Composable
private fun CircleIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, size: androidx.compose.ui.unit.Dp, filled: Boolean) {
    if (filled) {
        Box(
            modifier = Modifier.size(size).clip(CircleShape).background(Color.White),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = Color.Black)
        }
    } else {
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = FluxColors.onBackground)
        }
    }
}

@Composable
private fun WaveformProgress(elapsedLabel: String, totalLabel: String, progress: Float) {
    Column(modifier = Modifier.fillMaxWidth().padding(top = 20.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(text = elapsedLabel, style = AppTypography.dataMono, color = FluxColors.onBackgroundMuted)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 10.dp)
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.12f)),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress)
                        .height(3.dp)
                        .background(
                            Brush.horizontalGradient(listOf(FluxColors.accent, FluxColors.accentSecondary))
                        ),
                )
            }
            Text(text = totalLabel, style = AppTypography.dataMono, color = FluxColors.onBackgroundMuted)
        }
    }
}

@Composable
private fun DiscoverCard(title: String, subtitle: String) {
    Column(modifier = Modifier.width(140.dp)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(12.dp))
                .background(Brush.linearGradient(listOf(FluxColors.glow, FluxColors.accentSecondary))),
        )
        Text(
            text = title,
            style = AppTypography.bodyMuted,
            color = FluxColors.onBackground,
            modifier = Modifier.padding(top = 8.dp),
        )
        Text(
            text = subtitle,
            style = AppTypography.dataMono.copy(fontSize = 10.sp),
            color = FluxColors.onBackgroundMuted,
        )
    }
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
