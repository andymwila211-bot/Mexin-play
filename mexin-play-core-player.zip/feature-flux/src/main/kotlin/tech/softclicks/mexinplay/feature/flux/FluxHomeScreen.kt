package tech.softclicks.mexinplay.feature.flux

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.FluxColors
import tech.softclicks.mexinplay.core.ui.glass.GlassSurface

@Composable
fun FluxHomeScreen(
    nowPlaying: PlayableItem?,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .padding(top = 56.dp, bottom = 120.dp),
    ) {
        Text(
            text = "FLUX",
            style = AppTypography.eyebrow,
            color = FluxColors.accentSecondary,
        )
        Text(
            text = "Your watchlist",
            style = AppTypography.displayLarge,
            color = FluxColors.onBackground,
            modifier = Modifier.padding(top = 4.dp),
        )

        Row(
            modifier = Modifier
                .padding(top = 20.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            listOf("Continue", "Trending", "Downloaded", "Watch later").forEach { label ->
                GlassSurface(cornerRadius = 100.dp) {
                    Text(
                        text = label,
                        style = AppTypography.bodyMuted,
                        color = FluxColors.onBackground,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
                    )
                }
            }
        }

        Text(
            text = "Now watching",
            style = AppTypography.headline,
            color = FluxColors.onBackground,
            modifier = Modifier.padding(top = 28.dp, bottom = 12.dp),
        )

        GlassSurface(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // Video thumbnail placeholder — wider than Pulse's square
                // art, 16:9, since that's the actual shape of the content.
                Box(
                    modifier = Modifier
                        .width(88.dp)
                        .height(56.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .aspectRatio(16f / 9f)
                        .background(
                            Brush.linearGradient(
                                listOf(FluxColors.accent, FluxColors.accentSecondary)
                            )
                        ),
                )
                Column(
                    modifier = Modifier
                        .padding(start = 14.dp)
                        .weight(1f),
                ) {
                    Text(
                        text = nowPlaying?.title ?: "Nothing playing",
                        style = AppTypography.body,
                        color = FluxColors.onBackground,
                    )
                    Text(
                        text = nowPlaying?.artistOrChannel ?: "Pick something from your library",
                        style = AppTypography.bodyMuted,
                        color = FluxColors.onBackgroundMuted,
                        modifier = Modifier.padding(top = 2.dp),
                    )
                }
                Text(
                    text = nowPlaying?.let { formatDuration(it.durationMs) } ?: "--:--",
                    style = AppTypography.dataMono,
                    color = FluxColors.accentSecondary,
                )
            }
        }
    }
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
