package tech.softclicks.mexinplay.feature.flux

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.sin
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.FluxColors
import tech.softclicks.mexinplay.core.ui.glass.GlassSurface

/**
 * Same structure as PulseHomeScreen — see that file's doc comment — but
 * artwork is a 16:9 rounded rect overlapping the card top edge instead
 * of a circle (video thumbnails aren't square), and transport controls
 * are 10s-skip instead of track-skip.
 */
@Composable
fun FluxHomeScreen(
    nowPlaying: PlayableItem?,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .padding(top = 56.dp, bottom = 130.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            IconButton(
                onClick = {},
                modifier = Modifier
                    .size(40.dp)
                    .background(Color.White.copy(alpha = 0.1f), CircleShape),
            ) {
                Icon(Icons.Filled.Search, contentDescription = "Search", tint = Color.White)
            }
        }

        GlassSurface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 32.dp),
            cornerRadius = 24.dp,
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                Box(modifier = Modifier.fillMaxWidth().height(24.dp))

                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .offset(y = (-70).dp)
                        .fillMaxWidth(0.82f)
                        .aspectRatio(16f / 9f)
                        .shadow(20.dp, RoundedCornerShape(18.dp), spotColor = FluxColors.accent.copy(alpha = 0.3f))
                        .clip(RoundedCornerShape(18.dp))
                        .background(
                            brush = Brush.linearGradient(
                                listOf(FluxColors.glow, FluxColors.accent, FluxColors.accentSecondary)
                            )
                        )
                        .border(
                            width = 3.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(Color.White.copy(alpha = 0.8f), Color.Gray.copy(alpha = 0.2f), Color.White.copy(alpha = 0.8f))
                            ),
                            shape = RoundedCornerShape(18.dp),
                        ),
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 118.dp, bottom = 24.dp, start = 24.dp, end = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = nowPlaying?.title ?: "Nothing playing",
                        style = AppTypography.headline,
                        color = Color.White,
                    )
                    Text(
                        text = nowPlaying?.artistOrChannel ?: "Pick something from your library",
                        style = AppTypography.bodyMuted,
                        color = Color.White.copy(alpha = 0.7f),
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconButton(
                            onClick = {},
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color.White.copy(alpha = 0.1f), CircleShape),
                        ) {
                            Icon(Icons.Filled.Replay10, contentDescription = "Back 10s", tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        GlowingPlayButton()
                        Spacer(modifier = Modifier.width(16.dp))
                        IconButton(
                            onClick = {},
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color.White.copy(alpha = 0.1f), CircleShape),
                        ) {
                            Icon(Icons.Filled.Forward10, contentDescription = "Forward 10s", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(text = "04:12", style = AppTypography.dataMono, color = Color.White.copy(alpha = 0.7f))
                        Text(
                            text = nowPlaying?.let { formatDuration(it.durationMs) } ?: "18:24",
                            style = AppTypography.dataMono,
                            color = Color.White.copy(alpha = 0.7f),
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    WaveProgress(progress = 0.23f, accentA = FluxColors.accent, accentB = FluxColors.accentSecondary)
                }
            }
        }

        Text(text = "Discover", style = AppTypography.eyebrow, color = Color.White)

        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            DiscoverCard("City Nights", "8 episodes | Drama", listOf(Color(0xFF0B2B42), Color(0xFF4FD1FF)))
            DiscoverCard("Field Notes", "12 episodes | Docs", listOf(Color(0xFF0F172A), Color(0xFF7CFFC4)))
            DiscoverCard("Quiet Hours", "5 episodes | Ambient", listOf(Color(0xFF06121F), Color(0xFF1E9BFF)))
        }
    }
}

@Composable
private fun WaveProgress(progress: Float, accentA: Color, accentB: Color) {
    val density = LocalDensity.current
    BoxWithConstraints(modifier = Modifier.fillMaxWidth().height(32.dp)) {
        val widthPx = with(density) { maxWidth.toPx() }
        val heightPx = with(density) { maxHeight.toPx() }
        val amplitudePx = with(density) { 6.dp.toPx() }
        val waveLenPx = with(density) { 60.dp.toPx() }

        Canvas(modifier = Modifier.fillMaxSize()) {
            val centerY = heightPx / 2
            val endX = widthPx * progress

            val playedPath = Path().apply {
                moveTo(0f, centerY)
                var x = 0
                while (x <= endX.toInt()) {
                    val y = centerY + amplitudePx * sin(x / waveLenPx * 2 * PI).toFloat()
                    lineTo(x.toFloat(), y)
                    x += 2
                }
            }
            drawPath(
                path = playedPath,
                brush = Brush.horizontalGradient(colors = listOf(accentA, accentB)),
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round),
            )

            val remainingPath = Path().apply {
                moveTo(endX, centerY + amplitudePx * sin(endX / waveLenPx * 2 * PI).toFloat())
                var x = endX.toInt()
                while (x <= widthPx.toInt()) {
                    val y = centerY + amplitudePx * sin(x / waveLenPx * 2 * PI).toFloat()
                    lineTo(x.toFloat(), y)
                    x += 2
                }
            }
            drawPath(
                path = remainingPath,
                color = Color.White.copy(alpha = 0.15f),
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round),
            )

            val thumbY = centerY + amplitudePx * sin(endX / waveLenPx * 2 * PI).toFloat()
            drawCircle(color = Color.White.copy(alpha = 0.25f), radius = 14.dp.toPx(), center = Offset(endX, thumbY))
            drawCircle(color = Color.White, radius = 6.dp.toPx(), center = Offset(endX, thumbY))
        }
    }
}

@Composable
private fun DiscoverCard(title: String, subtitle: String, colors: List<Color>) {
    Column(modifier = Modifier.width(140.dp)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(12.dp))
                .background(brush = Brush.radialGradient(colors = colors)),
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = title, style = AppTypography.body, color = Color.White)
        Text(text = subtitle, style = AppTypography.bodyMuted, color = Color.White.copy(alpha = 0.6f))
    }
}

@Composable
private fun GlowingPlayButton() {
    Box(
        modifier = Modifier
            .size(64.dp)
            .shadow(12.dp, CircleShape, spotColor = Color.White.copy(alpha = 0.3f))
            .clip(CircleShape),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(Color.White.copy(alpha = 0.8f), Color.Gray.copy(alpha = 0.2f)),
                        center = Offset(0.3f, 0.3f),
                        radius = 0.8f,
                    )
                ),
        ) {
            Box(
                modifier = Modifier
                    .padding(3.dp)
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(Color.White.copy(alpha = 0.2f), Color.Black.copy(alpha = 0.2f)),
                            center = Offset(0.2f, 0.2f),
                            radius = 1.0f,
                        )
                    ),
            ) {
                Icon(
                    imageVector = Icons.Filled.PlayArrow,
                    contentDescription = "Play",
                    tint = Color.White,
                    modifier = Modifier.align(Alignment.Center).size(36.dp),
                )
            }
        }
    }
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
