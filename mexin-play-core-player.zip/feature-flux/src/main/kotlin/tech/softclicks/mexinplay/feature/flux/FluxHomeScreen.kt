package tech.softclicks.mexinplay.feature.flux

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.FluxColors
import tech.softclicks.mexinplay.core.ui.glass.GlassSurface

/**
 * Entry screen for the Flux (video) section. Same scope note as
 * PulseHomeScreen — proves the module graph compiles, not a finished UI.
 */
@Composable
fun FluxHomeScreen(
    nowPlaying: PlayableItem?,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.fillMaxSize(),
        color = FluxColors.background,
    ) {
        Column(modifier = Modifier.padding(24.dp)) {
            Text(
                text = "Flux",
                color = FluxColors.onBackground,
                style = MaterialTheme.typography.headlineMedium,
            )
            Box(modifier = Modifier.padding(top = 16.dp)) {
                GlassSurface {
                    Text(
                        text = nowPlaying?.title ?: "Nothing playing",
                        color = FluxColors.onBackground,
                        modifier = Modifier.padding(16.dp),
                    )
                }
            }
        }
    }
}
