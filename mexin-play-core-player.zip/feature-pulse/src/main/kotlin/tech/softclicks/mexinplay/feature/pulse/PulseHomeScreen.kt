package tech.softclicks.mexinplay.feature.pulse

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.GlassSurface
import tech.softclicks.mexinplay.core.ui.glass.PulseColors

/**
 * Circular hero artwork sitting on the shared Aura glow (see
 * AuraBackground) — the glow reads as light coming from behind the disc,
 * same trick as a portfolio reference this was adapted from, but built
 * with our own components/brand rather than copied wholesale. Waveform-
 * style scrubber and a horizontal "Discover" row replace the old
 * overlaid-text hero and vertical queue list.
 */
@Composable
fun PulseHomeScreen(
    nowPlaying: PlayableItem?,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .padding(top = 56.dp, bottom = 130.dp),
    ) {
        TopBar()

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 28.dp),
            contentAlignment = Alignment.Center,
        ) {
            CircularArt()
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = nowPlaying?.title ?: "Nothing playing",
                style = AppTypography.headline.copy(fontSize = 20.sp),
                color = PulseColors.onBackground,
            )
            Text(
                text = nowPlaying?.artistOrChannel ?: "Pick something from your library",
                style = AppTypography.bodyMuted,
                color = PulseColors.onBackgroundMuted,
                modifier = Modifier.padding(top = 2.dp),
            )
        }

        TransportRow()

        WaveformProgress(
            elapsedLabel = "01:48",
            totalLabel = nowPlaying?.let { formatDuration(it.durationMs) } ?: "03:22",
            progress = 0.45f,
        )

        Text(
            text = "Discover",
            style = AppTypography.headline,
            color = PulseColors.onBackground,
            modifier = Modifier.padding(top = 32.dp, bottom = 12.dp),
        )

        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            listOf("Midnight Lofi" to "32 tracks", "Starlight Beats" to "39 tracks", "Chill Anthems" to "21 tracks")
                .forEach { (title, subtitle) -> DiscoverCard(title, subtitle) }
        }
    }
}

@Composable
private fun TopBar() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        GlassSurface(cornerRadius = 100.dp) {
            Icon(
                Icons.Filled.Search,
                contentDescription = "Search",
                tint = PulseColors.onBackground,
                modifier = Modifier.padding(10.dp),
            )
        }
        GlassSurface(cornerRadius = 100.dp) {
            Icon(
                Icons.Filled.AccountCircle,
                contentDescription = "Profile",
                tint = PulseColors.accent,
                modifier = Modifier.padding(10.dp),
            )
        }
    }
}

@Composable
private fun CircularArt() {
    Box(
        modifier = Modifier.size(220.dp),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(220.dp)
                .clip(CircleShape)
                .background(
                    Brush.sweepGradient(
                        listOf(PulseColors.glow, PulseColors.accent, PulseColors.accentSecondary, PulseColors.glow)
                    )
                ),
        )
    }
}

@Composable
private fun TransportRow() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircleIconButton(icon = Icons.Filled.SkipPrevious, size = 48.dp, filled = false)
        CircleIconButton(icon = Icons.Filled.PlayArrow, size = 68.dp, filled = true)
        CircleIconButton(icon = Icons.Filled.SkipNext, size = 48.dp, filled = false)
    }
}

@Composable
private fun CircleIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, size: androidx.compose.ui.unit.Dp, filled: Boolean) {
    if (filled) {
        Box(
            modifier = Modifier.size(size).clip(CircleShape).background(PulseColors.accent),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = Color.Black)
        }
    } else {
        GlassSurface(modifier = Modifier.size(size), cornerRadius = size / 2) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = PulseColors.onBackground)
            }
        }
    }
}

@Composable
private fun WaveformProgress(elapsedLabel: String, totalLabel: String, progress: Float) {
    Column(modifier = Modifier.padding(top = 24.dp)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Color.White.copy(alpha = 0.12f)),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(progress)
                    .height(3.dp)
                    .background(
                        Brush.horizontalGradient(listOf(PulseColors.accent, PulseColors.accentSecondary))
                    ),
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(text = elapsedLabel, style = AppTypography.dataMono, color = PulseColors.onBackgroundMuted)
            Text(text = totalLabel, style = AppTypography.dataMono, color = PulseColors.onBackgroundMuted)
        }
    }
}

@Composable
private fun DiscoverCard(title: String, subtitle: String) {
    Column(modifier = Modifier.width(112.dp)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(14.dp))
                .background(Brush.linearGradient(listOf(PulseColors.glow, PulseColors.accentSecondary))),
        )
        Text(
            text = title,
            style = AppTypography.bodyMuted,
            color = PulseColors.onBackground,
            modifier = Modifier.padding(top = 8.dp),
        )
        Text(
            text = subtitle,
            style = AppTypography.dataMono.copy(fontSize = 11.sp),
            color = PulseColors.onBackgroundMuted,
        )
    }
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
