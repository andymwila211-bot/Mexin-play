package tech.softclicks.mexinplay.feature.pulse

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.sin
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.GlassSurface
import tech.softclicks.mexinplay.core.ui.glass.PulseColors

/**
 * Player card with artwork overlapping the top edge of the glass panel
 * (offset -30dp), a wave-form progress path drawn with Canvas, and a
 * layered "domed glass" play button. Nav/bottom bar intentionally not
 * included here — that's owned by MexinNavHost and shared across both
 * screens; duplicating it here would render two bottom bars.
 */
@Composable
fun PulseHomeScreen(
    nowPlaying: PlayableItem?,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .padding(top = 56.dp, bottom = 130.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        IconButton(
            onClick = {},
            modifier = Modifier
                .size(40.dp)
                .background(Color.White.copy(alpha = 0.1f), CircleShape),
        ) {
            Icon(Icons.Filled.Search, contentDescription = "Search", tint = Color.White)
        }

        GlassSurface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 40.dp),
            cornerRadius = 24.dp,
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                Box(modifier = Modifier.fillMaxWidth().height(60.dp))

                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .offset(y = (-30).dp)
                        .size(140.dp)
                        .shadow(20.dp, CircleShape, spotColor = PulseColors.accent.copy(alpha = 0.3f))
                        .clip(CircleShape)
                        .background(
                            brush = Brush.radialGradient(
                                colors = listOf(PulseColors.accent, PulseColors.glow),
                                center = Offset(0.3f, 0.3f),
                                radius = 0.7f,
                            )
                        )
                        .border(
                            width = 4.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(Color.White.copy(alpha = 0.8f), Color.Gray.copy(alpha = 0.2f), Color.White.copy(alpha = 0.8f))
                            ),
                            shape = CircleShape,
                        ),
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 60.dp, bottom = 24.dp, start = 24.dp, end = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = nowPlaying?.title ?: "Nothing playing",
                        style = AppTypography.headline,
                        color = Color.White,
                    )
                    Text(
                        text = nowPlaying?.artistOrChannel ?: "Pick something from your library",
                        style = AppTypography.bodyMuted,
                        color = Color.White.copy(alpha = 0.7f),
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconButton(
                            onClick = {},
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color.White.copy(alpha = 0.1f), CircleShape),
                        ) {
                            Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        GlowingPlayButton()
                        Spacer(modifier = Modifier.width(16.dp))
                        IconButton(
                            onClick = {},
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color.White.copy(alpha = 0.1f), CircleShape),
                        ) {
                            Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(text = "01:48", style = AppTypography.dataMono, color = Color.White.copy(alpha = 0.7f))
                        Text(
                            text = nowPlaying?.let { formatDuration(it.durationMs) } ?: "03:22",
                            style = AppTypography.dataMono,
                            color = Color.White.copy(alpha = 0.7f),
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    WaveProgress(progress = 0.55f, accentA = PulseColors.accent, accentB = PulseColors.accentSecondary)
                }
            }
        }

        Text(text = "Discover", style = AppTypography.eyebrow, color = Color.White)

        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            DiscoverCard("Midnight Lofi", "32 tracks | Ambient", listOf(Color(0xFF2B2D42), Color(0xFF77A7FF)))
            DiscoverCard("Starlight Beats", "39 tracks | Ambient", listOf(Color(0xFF1A101F), Color(0xFF7A4AB4)))
            DiscoverCard("Chill Anthems", "21 tracks | Ambient", listOf(Color(0xFF0F172A), Color(0xFFB47DDB)))
        }
    }
}

@Composable
private fun WaveProgress(progress: Float, accentA: Color, accentB: Color) {
    // toPx() needs an explicit Density — BoxWithConstraintsScope doesn't
    // provide one implicitly like DrawScope does inside Canvas.
    val density = LocalDensity.current
    BoxWithConstraints(modifier = Modifier.fillMaxWidth().height(32.dp)) {
        val widthPx = with(density) { maxWidth.toPx() }
        val heightPx = with(density) { maxHeight.toPx() }
        val amplitudePx = with(density) { 6.dp.toPx() }
        val waveLenPx = with(density) { 60.dp.toPx() }

        Canvas(modifier = Modifier.fillMaxSize()) {
            val centerY = heightPx / 2
            val endX = widthPx * progress

            val playedPath = Path().apply {
                moveTo(0f, centerY)
                var x = 0
                while (x <= endX.toInt()) {
                    val y = centerY + amplitudePx * sin(x / waveLenPx * 2 * PI).toFloat()
                    lineTo(x.toFloat(), y)
                    x += 2
                }
            }
            drawPath(
                path = playedPath,
                brush = Brush.horizontalGradient(colors = listOf(accentA, accentB)),
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round),
            )

            val remainingPath = Path().apply {
                moveTo(endX, centerY + amplitudePx * sin(endX / waveLenPx * 2 * PI).toFloat())
                var x = endX.toInt()
                while (x <= widthPx.toInt()) {
                    val y = centerY + amplitudePx * sin(x / waveLenPx * 2 * PI).toFloat()
                    lineTo(x.toFloat(), y)
                    x += 2
                }
            }
            drawPath(
                path = remainingPath,
                color = Color.White.copy(alpha = 0.15f),
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round),
            )

            val thumbY = centerY + amplitudePx * sin(endX / waveLenPx * 2 * PI).toFloat()
            drawCircle(color = Color.White.copy(alpha = 0.25f), radius = 14.dp.toPx(), center = Offset(endX, thumbY))
            drawCircle(color = Color.White, radius = 6.dp.toPx(), center = Offset(endX, thumbY))
        }
    }
}

@Composable
private fun DiscoverCard(title: String, subtitle: String, colors: List<Color>) {
    Column(modifier = Modifier.width(120.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(brush = Brush.radialGradient(colors = colors)),
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = title, style = AppTypography.body, color = Color.White)
        Text(text = subtitle, style = AppTypography.bodyMuted, color = Color.White.copy(alpha = 0.6f))
    }
}

@Composable
private fun GlowingPlayButton() {
    Box(
        modifier = Modifier
            .size(64.dp)
            .shadow(12.dp, CircleShape, spotColor = Color.White.copy(alpha = 0.3f))
            .clip(CircleShape),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(Color.White.copy(alpha = 0.8f), Color.Gray.copy(alpha = 0.2f)),
                        center = Offset(0.3f, 0.3f),
                        radius = 0.8f,
                    )
                ),
        ) {
            Box(
                modifier = Modifier
                    .padding(3.dp)
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(Color.White.copy(alpha = 0.2f), Color.Black.copy(alpha = 0.2f)),
                            center = Offset(0.2f, 0.2f),
                            radius = 1.0f,
                        )
                    ),
            ) {
                Icon(
                    imageVector = Icons.Filled.PlayArrow,
                    contentDescription = "Play",
                    tint = Color.White,
                    modifier = Modifier.align(Alignment.Center).size(36.dp),
                )
            }
        }
    }
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
