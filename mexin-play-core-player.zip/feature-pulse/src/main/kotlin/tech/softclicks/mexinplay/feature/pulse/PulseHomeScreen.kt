package tech.softclicks.mexinplay.feature.pulse

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.GlassSurface
import tech.softclicks.mexinplay.core.ui.glass.PulseColors

@Composable
fun PulseHomeScreen(
    nowPlaying: PlayableItem?,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .padding(top = 56.dp, bottom = 120.dp),
    ) {
        Text(
            text = "PULSE",
            style = AppTypography.eyebrow,
            color = PulseColors.accentSecondary,
        )
        Text(
            text = "Your sound",
            style = AppTypography.displayLarge,
            color = PulseColors.onBackground,
            modifier = Modifier.padding(top = 4.dp),
        )

        // Quick-filter chip row — real content density instead of one
        // floating card. Static labels for now (no library data wired
        // up yet), but the layout itself is real.
        Row(
            modifier = Modifier
                .padding(top = 20.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            listOf("Recent", "Favorites", "Discover", "Downloaded").forEach { label ->
                GlassSurface(cornerRadius = 100.dp) {
                    Text(
                        text = label,
                        style = AppTypography.bodyMuted,
                        color = PulseColors.onBackground,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
                    )
                }
            }
        }

        Text(
            text = "Now playing",
            style = AppTypography.headline,
            color = PulseColors.onBackground,
            modifier = Modifier.padding(top = 28.dp, bottom = 12.dp),
        )

        GlassSurface(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // Cover-art placeholder — gradient block, not a broken
                // image icon, until real artwork loading is wired up.
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .aspectRatio(1f)
                        .background(
                            Brush.linearGradient(
                                listOf(PulseColors.accent, PulseColors.accentSecondary)
                            )
                        ),
                )
                Column(
                    modifier = Modifier
                        .padding(start = 14.dp)
                        .weight(1f),
                ) {
                    Text(
                        text = nowPlaying?.title ?: "Nothing playing",
                        style = AppTypography.body,
                        color = PulseColors.onBackground,
                    )
                    Text(
                        text = nowPlaying?.artistOrChannel ?: "Pick something from your library",
                        style = AppTypography.bodyMuted,
                        color = PulseColors.onBackgroundMuted,
                        modifier = Modifier.padding(top = 2.dp),
                    )
                }
                Text(
                    text = nowPlaying?.let { formatDuration(it.durationMs) } ?: "--:--",
                    style = AppTypography.dataMono,
                    color = PulseColors.accentSecondary,
                )
            }
        }
    }
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
