package tech.softclicks.mexinplay.feature.pulse

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.GlassSurface
import tech.softclicks.mexinplay.core.ui.glass.PulseColors

/**
 * Entry screen for the Pulse (audio) section. Deliberately minimal for
 * now — this exists to prove the module graph (core-player + core-ui-glass
 * consumed together, Compose configured correctly) compiles, not as a
 * finished screen. Real library browsing/queue UI comes next once this
 * foundation is confirmed green in CI.
 */
@Composable
fun PulseHomeScreen(
    nowPlaying: PlayableItem?,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.fillMaxSize(),
        color = PulseColors.background,
    ) {
        Column(modifier = Modifier.padding(24.dp)) {
            Text(
                text = "Pulse",
                color = PulseColors.onBackground,
                style = MaterialTheme.typography.headlineMedium,
            )
            Box(modifier = Modifier.padding(top = 16.dp)) {
                GlassSurface {
                    Text(
                        text = nowPlaying?.title ?: "Nothing playing",
                        color = PulseColors.onBackground,
                        modifier = Modifier.padding(16.dp),
                    )
                }
            }
        }
    }
}
