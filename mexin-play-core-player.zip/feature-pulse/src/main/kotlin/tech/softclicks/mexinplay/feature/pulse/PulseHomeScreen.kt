package tech.softclicks.mexinplay.feature.pulse

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.GlassSurface
import tech.softclicks.mexinplay.core.ui.glass.PulseColors

/**
 * Hero-first layout, matching how real music players are actually
 * structured (Spotify/Apple Music "now playing"): the artwork itself
 * carries the title/artist overlaid on it, not a separate text header
 * above a small thumbnail. Transport controls are visual-only here —
 * not wired to PlaybackController yet, that's the next step once real
 * media loading exists to control.
 */
@Composable
fun PulseHomeScreen(
    nowPlaying: PlayableItem?,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .padding(top = 64.dp, bottom = 130.dp),
    ) {
        HeroArtwork(nowPlaying)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 24.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Shuffle, contentDescription = "Shuffle", tint = PulseColors.onBackgroundMuted)
            Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = PulseColors.onBackground)
            PlayButton()
            Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = PulseColors.onBackground)
            Icon(Icons.Filled.Repeat, contentDescription = "Repeat", tint = PulseColors.onBackgroundMuted)
        }

        Text(
            text = "Up next",
            style = AppTypography.headline,
            color = PulseColors.onBackground,
            modifier = Modifier.padding(top = 32.dp, bottom = 12.dp),
        )

        listOf("Evening Drift", "Static Hours", "Low Light").forEach { title ->
            QueueRow(title = title, subtitle = "Unknown artist", durationLabel = "3:4" + (title.length % 10))
        }
    }
}

@Composable
private fun HeroArtwork(nowPlaying: PlayableItem?) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(28.dp))
            .background(
                Brush.linearGradient(
                    listOf(PulseColors.glow, PulseColors.accent, PulseColors.accentSecondary)
                )
            ),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomStart)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f)),
                    )
                )
                .padding(20.dp),
        ) {
            Column {
                Text(
                    text = nowPlaying?.title ?: "Nothing playing",
                    style = AppTypography.displayLarge.copy(fontSize = 26.sp),
                    color = Color.White,
                )
                Row(
                    modifier = Modifier.padding(top = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = nowPlaying?.artistOrChannel ?: "Pick something from your library",
                        style = AppTypography.bodyMuted,
                        color = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        text = nowPlaying?.let { formatDuration(it.durationMs) } ?: "--:--",
                        style = AppTypography.dataMono,
                        color = PulseColors.accentSecondary,
                    )
                }
            }
        }
    }
}

@Composable
private fun PlayButton() {
    Box(
        modifier = Modifier
            .size(64.dp)
            .clip(CircleShape)
            .background(PulseColors.accent),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Filled.PlayArrow, contentDescription = "Play", tint = Color.Black)
    }
}

@Composable
private fun QueueRow(title: String, subtitle: String, durationLabel: String) {
    GlassSurface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp),
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        Brush.linearGradient(listOf(PulseColors.accent, PulseColors.glow))
                    ),
            )
            Column(
                modifier = Modifier
                    .padding(start = 12.dp)
                    .weight(1f),
            ) {
                Text(text = title, style = AppTypography.body, color = PulseColors.onBackground)
                Text(
                    text = subtitle,
                    style = AppTypography.bodyMuted,
                    color = PulseColors.onBackgroundMuted,
                )
            }
            Text(text = durationLabel, style = AppTypography.dataMono, color = PulseColors.accentSecondary)
        }
    }
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
