package tech.softclicks.mexinplay.feature.pulse

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.sin
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.GlassSurface
import tech.softclicks.mexinplay.core.ui.glass.PulseColors

/**
 * Player card with artwork overlapping the top edge of the glass panel,
 * a wave-form progress path, and a layered "domed glass" play button.
 * Now backed by real state/callbacks from MexinPlayViewModel instead of
 * hardcoded nulls and no-op buttons — Discover shows actual device
 * tracks (shuffled by SmartShuffleEngine), tapping one plays it for
 * real, and transport controls call into PlaybackController.
 */
@Composable
fun PulseHomeScreen(
    nowPlaying: PlayableItem?,
    isPlaying: Boolean,
    discoverItems: List<PlayableItem>,
    onSelectItem: (PlayableItem) -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .padding(bottom = 130.dp),
    ) {
        Spacer(modifier = Modifier.weight(1f))

        GlassSurface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 48.dp),
            cornerRadius = 24.dp,
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                Box(modifier = Modifier.fillMaxWidth().height(60.dp))

                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .offset(y = (-90).dp)
                        .size(200.dp)
                        .shadow(20.dp, CircleShape, spotColor = PulseColors.accent.copy(alpha = 0.3f))
                        .clip(CircleShape)
                        .background(
                            // Matched to the reference: a uniform violet
                            // sphere with a soft top-left highlight, not
                            // a multi-hue sweep — the earlier 3-color
                            // version read as pink-tinged and busier
                            // than the reference actually is.
                            brush = Brush.radialGradient(
                                colors = listOf(PulseColors.accent, PulseColors.glow),
                                center = Offset(0.35f, 0.3f),
                                radius = 0.9f,
                            )
                        )
                        .border(
                            width = 4.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(Color.White.copy(alpha = 0.8f), Color.Gray.copy(alpha = 0.2f), Color.White.copy(alpha = 0.8f))
                            ),
                            shape = CircleShape,
                        ),
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 128.dp, bottom = 24.dp, start = 24.dp, end = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = nowPlaying?.title ?: "Nothing playing",
                        style = AppTypography.headline,
                        color = Color.White,
                    )
                    Text(
                        text = nowPlaying?.artistOrChannel ?: "Pick something from Discover below",
                        style = AppTypography.bodyMuted,
                        color = Color.White.copy(alpha = 0.7f),
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconButton(
                            onClick = onPrevious,
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color.White.copy(alpha = 0.1f), CircleShape),
                        ) {
                            Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        GlowingPlayButton(isPlaying = isPlaying, onClick = onPlayPause)
                        Spacer(modifier = Modifier.width(16.dp))
                        IconButton(
                            onClick = onNext,
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color.White.copy(alpha = 0.1f), CircleShape),
                        ) {
                            Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(text = "00:00", style = AppTypography.dataMono, color = Color.White.copy(alpha = 0.7f))
                        Text(
                            text = nowPlaying?.let { formatDuration(it.durationMs) } ?: "--:--",
                            style = AppTypography.dataMono,
                            color = Color.White.copy(alpha = 0.7f),
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Progress is still visual-only (fixed 0f) — real
                    // playback-position tracking needs an ExoPlayer
                    // position listener, a further step from here.
                    WaveProgress(progress = 0f, accentA = PulseColors.accent, accentB = PulseColors.accentSecondary)
                }
            }
        }

        Text(
            text = "Discover",
            style = AppTypography.eyebrow,
            color = Color.White,
            modifier = Modifier.padding(top = 20.dp, bottom = 12.dp),
        )

        if (discoverItems.isEmpty()) {
            Text(
                text = "No tracks found yet — grant media access or add music to your device.",
                style = AppTypography.bodyMuted,
                color = Color.White.copy(alpha = 0.6f),
            )
        } else {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                discoverItems.take(10).forEach { item ->
                    DiscoverCard(item = item, onClick = { onSelectItem(item) })
                }
            }
        }
    }
}

@Composable
private fun WaveProgress(progress: Float, accentA: Color, accentB: Color) {
    // toPx() needs an explicit Density — BoxWithConstraintsScope doesn't
    // provide one implicitly like DrawScope does inside Canvas.
    val density = LocalDensity.current
    BoxWithConstraints(modifier = Modifier.fillMaxWidth().height(32.dp)) {
        val widthPx = with(density) { maxWidth.toPx() }
        val heightPx = with(density) { maxHeight.toPx() }
        val amplitudePx = with(density) { 6.dp.toPx() }
        val waveLenPx = with(density) { 60.dp.toPx() }

        Canvas(modifier = Modifier.fillMaxSize()) {
            val centerY = heightPx / 2
            val endX = widthPx * progress

            val playedPath = Path().apply {
                moveTo(0f, centerY)
                var x = 0
                while (x <= endX.toInt()) {
                    val y = centerY + amplitudePx * sin(x / waveLenPx * 2 * PI).toFloat()
                    lineTo(x.toFloat(), y)
                    x += 2
                }
            }
            drawPath(
                path = playedPath,
                brush = Brush.horizontalGradient(colors = listOf(accentA, accentB)),
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round),
            )

            val remainingPath = Path().apply {
                moveTo(endX, centerY + amplitudePx * sin(endX / waveLenPx * 2 * PI).toFloat())
                var x = endX.toInt()
                while (x <= widthPx.toInt()) {
                    val y = centerY + amplitudePx * sin(x / waveLenPx * 2 * PI).toFloat()
                    lineTo(x.toFloat(), y)
                    x += 2
                }
            }
            drawPath(
                path = remainingPath,
                color = Color.White.copy(alpha = 0.15f),
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round),
            )

            val thumbY = centerY + amplitudePx * sin(endX / waveLenPx * 2 * PI).toFloat()
            drawCircle(color = Color.White.copy(alpha = 0.25f), radius = 14.dp.toPx(), center = Offset(endX, thumbY))
            drawCircle(color = Color.White, radius = 6.dp.toPx(), center = Offset(endX, thumbY))
        }
    }
}

@Composable
private fun DiscoverCard(item: PlayableItem, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(110.dp)
            .clickable(onClick = onClick),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(14.dp))
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(PulseColors.accentSecondary, PulseColors.glow),
                    )
                ),
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = item.title, style = AppTypography.body, color = Color.White, maxLines = 1)
        Text(
            text = item.artistOrChannel ?: formatDuration(item.durationMs),
            style = AppTypography.bodyMuted,
            color = Color.White.copy(alpha = 0.6f),
            maxLines = 1,
        )
    }
}

@Composable
private fun GlowingPlayButton(isPlaying: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(64.dp)
            .shadow(12.dp, CircleShape, spotColor = Color.White.copy(alpha = 0.3f))
            .clip(CircleShape)
            .clickable(onClick = onClick),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(Color.White.copy(alpha = 0.8f), Color.Gray.copy(alpha = 0.2f)),
                        center = Offset(0.3f, 0.3f),
                        radius = 0.8f,
                    )
                ),
        ) {
            Box(
                modifier = Modifier
                    .padding(3.dp)
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(Color.White.copy(alpha = 0.2f), Color.Black.copy(alpha = 0.2f)),
                            center = Offset(0.2f, 0.2f),
                            radius = 1.0f,
                        )
                    ),
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = Color.White,
                    modifier = Modifier.align(Alignment.Center).size(36.dp),
                )
            }
        }
    }
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
