package tech.softclicks.mexinplay.feature.pulse

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import tech.softclicks.mexinplay.core.player.PlaybackController
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.ArtworkColors
import tech.softclicks.mexinplay.core.ui.glass.LiquidBackdrop
import tech.softclicks.mexinplay.core.ui.glass.loadArtworkWithPalette

/**
 * The player only — Discover moved out to its own sub-screen (a
 * ModalBottomSheet built in the app module, since it needs the shared
 * queue/playlist state). This screen no longer scrolls: without Discover
 * appended, the player content fits without it on every normal device
 * size, so verticalScroll was removed rather than kept as a safety net
 * that was really just compensating for the old combined layout.
 */
@Composable
fun PulseHomeScreen(
    nowPlaying: PlayableItem?,
    isPlaying: Boolean,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onOpenDiscover: () -> Unit,
    playbackController: PlaybackController,
    modifier: Modifier = Modifier,
) {
    val (positionMs, durationMs) = rememberPlaybackProgress(playbackController, isPlaying, nowPlaying?.id)

    val context = LocalContext.current
    var artworkBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var artworkColors by remember { mutableStateOf(ArtworkColors(Color(0xFF2A2A32), Color(0xFF1A1A1F), Color(0xFF0C0C10))) }
    LaunchedEffect(nowPlaying?.artworkUri) {
        val (bitmap, colors) = loadArtworkWithPalette(context, nowPlaying?.artworkUri)
        artworkBitmap = bitmap
        artworkColors = colors
    }

    Box(modifier = modifier.fillMaxSize()) {
        LiquidBackdrop(artworkBitmap = artworkBitmap, colors = artworkColors, modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .padding(top = 24.dp, bottom = 150.dp),
        ) {
            Text(
                text = "PULSE",
                style = AppTypography.eyebrow,
                color = Color.White.copy(alpha = 0.55f),
            )

            Spacer(modifier = Modifier.height(20.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .heightIn(max = 360.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0xFF121216)),
                contentAlignment = Alignment.Center,
            ) {
                if (nowPlaying?.artworkUri != null) {
                    AsyncImage(
                        model = nowPlaying.artworkUri,
                        contentDescription = "${nowPlaying.title} artwork",
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    Text(
                        text = "P",
                        fontSize = 170.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.Black.copy(alpha = 0.35f),
                        modifier = Modifier.offset(x = 2.dp, y = 3.dp),
                    )
                    Text(
                        text = "P",
                        fontSize = 170.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White.copy(alpha = 0.05f),
                        modifier = Modifier.offset(x = (-1).dp, y = (-1).dp),
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = nowPlaying?.title ?: "Nothing playing",
                style = AppTypography.displayLarge.copy(fontSize = 26.sp),
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = nowPlaying?.artistOrChannel ?: "Open Discover to pick something",
                style = AppTypography.body,
                color = Color.White.copy(alpha = 0.5f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(modifier = Modifier.height(24.dp))

            SeekableProgress(
                elapsedLabel = formatDuration(positionMs),
                totalLabel = if (durationMs > 0) "-" + formatDuration((durationMs - positionMs).coerceAtLeast(0)) else "--:--",
                progress = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f,
                enabled = nowPlaying != null && durationMs > 0,
                onSeek = { fraction -> playbackController.seekTo((fraction * durationMs).toLong()) },
            )

            Spacer(modifier = Modifier.height(28.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RoundTransportButton(icon = Icons.Filled.FastRewind, contentDescription = "Previous", onClick = onPrevious)
                Spacer(modifier = Modifier.width(24.dp))
                RoundTransportButton(
                    icon = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    onClick = onPlayPause,
                    primary = true,
                )
                Spacer(modifier = Modifier.width(24.dp))
                RoundTransportButton(icon = Icons.Filled.FastForward, contentDescription = "Next", onClick = onNext)
            }

            Spacer(modifier = Modifier.height(36.dp))

            // Sub-screen entry point, not an inline list — tapping opens
            // Discover as its own half-height sheet (see MexinNavHost).
            Row(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = 0.08f))
                    .clickable(onClick = onOpenDiscover)
                    .padding(horizontal = 22.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.GridView, contentDescription = null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Discover", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
            }
        }
    }
}

/**
 * Polls the real ExoPlayer position/duration on a ~250ms tick while
 * playing. ExoPlayer doesn't push continuous position updates, so this
 * is the standard Compose pattern rather than a bug workaround. Resets
 * to 0 whenever the now-playing id changes so a new track doesn't show
 * the previous one's stale position for a frame.
 */
@Composable
private fun rememberPlaybackProgress(
    playbackController: PlaybackController,
    isPlaying: Boolean,
    nowPlayingId: String?,
): Pair<Long, Long> {
    var positionMs by remember(nowPlayingId) { mutableLongStateOf(0L) }
    var durationMs by remember(nowPlayingId) { mutableLongStateOf(0L) }

    LaunchedEffect(nowPlayingId, isPlaying) {
        if (nowPlayingId == null) return@LaunchedEffect
        while (true) {
            val player = playbackController.exoPlayerInstance()
            positionMs = player.currentPosition.coerceAtLeast(0)
            val total = player.duration
            durationMs = if (total > 0) total else 0L
            if (!isPlaying) break
            delay(250)
        }
    }

    return positionMs to durationMs
}

@Composable
private fun SeekableProgress(
    elapsedLabel: String,
    totalLabel: String,
    progress: Float,
    enabled: Boolean,
    onSeek: (Float) -> Unit,
) {
    var trackWidthPx by remember { mutableStateOf(0) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(24.dp)
                .onSizeChanged { trackWidthPx = it.width }
                .pointerInput(enabled) {
                    if (!enabled) return@pointerInput
                    detectTapGestures { offset ->
                        if (trackWidthPx > 0) onSeek((offset.x / trackWidthPx).coerceIn(0f, 1f))
                    }
                },
            contentAlignment = Alignment.CenterStart,
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .clip(RoundedCornerShape(1.dp))
                    .background(Color.White.copy(alpha = 0.22f)),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress.coerceIn(0.02f, 1f))
                        .height(2.dp)
                        .background(Color.White),
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(text = elapsedLabel, style = AppTypography.body, fontSize = 14.sp, color = Color.White.copy(alpha = 0.5f))
            Text(text = totalLabel, style = AppTypography.body, fontSize = 14.sp, color = Color.White.copy(alpha = 0.5f))
        }
    }
}

@Composable
private fun RoundTransportButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    primary: Boolean = false,
) {
    val size = if (primary) 76.dp else 60.dp
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(if (primary) Color.White else Color.White.copy(alpha = 0.08f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (primary) Color.Black else Color.White,
            modifier = Modifier.size(if (primary) 30.dp else 22.dp),
        )
    }
}

internal fun formatDuration(durationMs: Long): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
