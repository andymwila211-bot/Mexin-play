package tech.softclicks.mexinplay.core.ui.glass

import androidx.compose.ui.graphics.Color

/**
 * Pulse (audio) and Flux (video) share one glass shell and interaction
 * model — only the palette/accent differ. This is the themed-variant
 * approach, not two separate UI paradigms (see project notes on why
 * that split was rejected: doubles design/QA surface for a solo dev).
 *
 * Each section has a primary accent (nav, headlines) and a secondary
 * accent (used sparingly — waveform/progress highlights) so a section
 * doesn't read as "one color slapped on defaults."
 */
object PulseColors {
    val background = Color(0xFF0B0A14) // deep violet-black
    val glow = Color(0xFF6E3FF2)        // Aura source color for Pulse
    val accent = Color(0xFFB388FF)      // lilac — headlines, active nav
    val accentSecondary = Color(0xFFFF6FB5) // warm pink — waveform/progress
    val onBackground = Color(0xFFF2EFFA)
    val onBackgroundMuted = Color(0xFFB9B3CC)
}

object FluxColors {
    val background = Color(0xFF060B14) // deep cyan-black
    val glow = Color(0xFF1E9BFF)         // Aura source color for Flux
    val accent = Color(0xFF4FD1FF)       // cyan — headlines, active nav
    val accentSecondary = Color(0xFF7CFFC4) // mint — progress/duration bars
    val onBackground = Color(0xFFEAF6FF)
    val onBackgroundMuted = Color(0xFFA9C4D6)
}

/** Base backdrop shared by both sections, sitting beneath the Aura glow. */
object ShellColors {
    val base = Color(0xFF07070C)
}
