package tech.softclicks.mexinplay.core.ui.glass

import androidx.compose.ui.graphics.Color

/**
 * Pulse (audio) and Flux (video) share one glass shell and interaction
 * model — only the palette/accent differ. This is the themed-variant
 * approach, not two separate UI paradigms (see project notes on why
 * that split was rejected: doubles design/QA surface for a solo dev).
 */
object PulseColors {
    val background = Color(0xFF0B0A14)
    val accent = Color(0xFFB388FF) // violet — warmer, music-coded
    val onBackground = Color(0xFFF2EFFA)
}

object FluxColors {
    val background = Color(0xFF060B14)
    val accent = Color(0xFF4FD1FF) // cyan — cooler, motion/video-coded
    val onBackground = Color(0xFFEAF6FF)
}
