package tech.softclicks.mexinplay.core.ui.glass

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Stand-in for real glassmorphism. Same shape a Haze-backed blur panel
 * will have (rounded corners, translucent fill, gradient border, a
 * top sheen for depth) so swapping the internals later doesn't touch
 * any feature-pulse/feature-flux call site.
 *
 * SWAP POINT: when Haze is added, replace the `background(...)` call
 * below with the real blur modifier chain. Nothing else in this file,
 * or any caller, needs to change.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 20.dp,
    tint: Color = Color.White.copy(alpha = 0.07f),
    content: @Composable () -> Unit,
) {
    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier
            .background(color = tint, shape = shape)
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.28f),
                        Color.White.copy(alpha = 0.04f),
                    )
                ),
                shape = shape,
            ),
    ) {
        // Top sheen: a quiet highlight along the upper edge, the one
        // detail that reads as "glass" rather than "translucent card."
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.5f),
                            Color.Transparent,
                        )
                    )
                )
        )
        content()
    }
}
