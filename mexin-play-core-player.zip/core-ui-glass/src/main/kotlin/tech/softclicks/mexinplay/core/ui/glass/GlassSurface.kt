package tech.softclicks.mexinplay.core.ui.glass

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Stand-in for real glassmorphism. This gives every call site the same
 * shape (rounded corners, translucent fill, subtle top-light border) that
 * a Haze-backed blur panel will have, so swapping the internals later
 * doesn't touch feature-pulse/feature-flux call sites at all.
 *
 * SWAP POINT: when Haze is added, replace the `background(...)` call
 * below with the real blur modifier chain (rememberHazeState + the
 * source/effect modifiers on whatever's behind this surface). Nothing
 * else in this file, or any caller, needs to change.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 20.dp,
    tint: Color = Color.White.copy(alpha = 0.08f),
    content: @Composable () -> Unit,
) {
    val shape = RoundedCornerShape(cornerRadius)
    androidx.compose.foundation.layout.Box(
        modifier = modifier
            .background(color = tint, shape = shape)
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.25f),
                        Color.White.copy(alpha = 0.05f),
                    )
                ),
                shape = shape,
            ),
    ) {
        content()
    }
}
