package tech.softclicks.mexinplay.core.ui.glass

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * A single soft radial glow anchored off-canvas, top-trailing. Callers
 * pass an already-animated Color (see MexinNavHost) so the glow
 * physically cross-fades hue when switching sections, rather than
 * cutting between two flat backgrounds. This is the one place this app
 * spends its visual boldness — everything else stays quiet by design.
 */
@Composable
fun AuraBackground(
    color: Color,
    modifier: Modifier = Modifier,
) {
    Box(modifier = modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .size(520.dp)
                .offset(x = 140.dp, y = (-160).dp)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            color.copy(alpha = 0.35f),
                            color.copy(alpha = 0.12f),
                            Color.Transparent,
                        ),
                    ),
                ),
        )
    }
}
