package tech.softclicks.mexinplay.app

import android.app.Application
import tech.softclicks.mexinplay.core.player.PlaybackController
import tech.softclicks.mexinplay.core.player.history.PlayHistoryDatabase

/**
 * Owns the one PlaybackController and one PlayHistoryDatabase instance
 * for the whole app. Pulse and Flux screens both read from this — see
 * PlaybackController's own doc comment for why there's only one engine
 * instance instead of one per section.
 */
class MexinPlayApplication : Application() {

    lateinit var playbackController: PlaybackController
        private set

    override fun onCreate() {
        super.onCreate()
        val historyDao = PlayHistoryDatabase.getInstance(this).playHistoryDao()
        playbackController = PlaybackController(
            context = this,
            historyDao = historyDao,
        )
    }
}
