package tech.softclicks.mexinplay.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.player.playlist.PlaylistSummary

/**
 * Manual playlists — separate from the Pulse/Flux Discover queues, which
 * are the smart-shuffle-ordered device library, not user-curated lists.
 * Reached via the playlist icon next to search rather than a third
 * Pulse/Flux pill segment, since that pill was copied pixel-for-pixel
 * from the reference and adding a third state there wasn't part of it.
 */
@Composable
fun PlaylistsScreen(
    playlists: List<PlaylistSummary>,
    onCreatePlaylist: (String) -> Unit,
    onDeletePlaylist: (Long) -> Unit,
    onOpenPlaylist: (Long) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var isCreating by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }

    Column(modifier = modifier.fillMaxSize().padding(horizontal = 24.dp).padding(top = 24.dp, bottom = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.ArrowBack,
                contentDescription = "Back",
                tint = Color.White,
                modifier = Modifier.size(22.dp).clickable(onClick = onBack),
            )
            Spacer(modifier = Modifier.width(16.dp))
            Text(text = "Playlists", fontSize = 22.sp, color = Color.White)
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (isCreating) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF1A1A1F))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    if (newName.isEmpty()) {
                        Text("Playlist name", color = Color.White.copy(alpha = 0.4f), fontSize = 15.sp)
                    }
                    BasicTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                        cursorBrush = SolidColor(Color.White),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                Text(
                    text = "Create",
                    color = Color.White,
                    fontSize = 14.sp,
                    modifier = Modifier.clickable {
                        onCreatePlaylist(newName)
                        newName = ""
                        isCreating = false
                    },
                )
                Spacer(modifier = Modifier.width(12.dp))
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "Cancel",
                    tint = Color.White.copy(alpha = 0.6f),
                    modifier = Modifier.size(18.dp).clickable { isCreating = false; newName = "" },
                )
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White.copy(alpha = 0.06f))
                    .clickable { isCreating = true }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text(text = "New playlist", color = Color.White, fontSize = 15.sp)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (playlists.isEmpty()) {
            Text(
                text = "No playlists yet — create one above, then add tracks by long-pressing them in Discover.",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 14.sp,
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(playlists, key = { it.id }) { playlist ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White.copy(alpha = 0.04f))
                            .clickable { onOpenPlaylist(playlist.id) }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.PlaylistPlay, contentDescription = null, tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = playlist.name, color = Color.White, fontSize = 16.sp)
                            Text(
                                text = if (playlist.trackCount == 1) "1 track" else "${playlist.trackCount} tracks",
                                color = Color.White.copy(alpha = 0.5f),
                                fontSize = 13.sp,
                            )
                        }
                        Icon(
                            Icons.Filled.Delete,
                            contentDescription = "Delete playlist",
                            tint = Color.White.copy(alpha = 0.4f),
                            modifier = Modifier.size(18.dp).clickable { onDeletePlaylist(playlist.id) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PlaylistDetailScreen(
    playlistName: String,
    tracks: List<PlayableItem>,
    onPlay: (PlayableItem) -> Unit,
    onRemove: (String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier.fillMaxSize().padding(horizontal = 24.dp).padding(top = 24.dp, bottom = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.ArrowBack,
                contentDescription = "Back",
                tint = Color.White,
                modifier = Modifier.size(22.dp).clickable(onClick = onBack),
            )
            Spacer(modifier = Modifier.width(16.dp))
            Text(text = playlistName, fontSize = 22.sp, color = Color.White, maxLines = 1)
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (tracks.isEmpty()) {
            Text(
                text = "Nothing here yet — long-press a track in Discover to add it.",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 14.sp,
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tracks, key = { it.id }) { track ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.04f))
                            .clickable { onPlay(track) }
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = track.title, color = Color.White, fontSize = 15.sp, maxLines = 1)
                            track.artistOrChannel?.let {
                                Text(text = it, color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp, maxLines = 1)
                            }
                        }
                        Icon(
                            Icons.Filled.Close,
                            contentDescription = "Remove from playlist",
                            tint = Color.White.copy(alpha = 0.4f),
                            modifier = Modifier.size(16.dp).clickable { onRemove(track.id) },
                        )
                    }
                }
            }
        }
    }
}

/** Minimal picker shown on long-press — pick an existing playlist or make a new one, in one step. */
/** Content only — hosted inside a real ModalBottomSheet by MexinNavHost, which supplies the scrim/dismiss/drag handling itself. */
@Composable
fun AddToPlaylistSheetContent(
    item: PlayableItem,
    playlists: List<PlaylistSummary>,
    onPickPlaylist: (Long) -> Unit,
    onCreateAndAdd: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var newName by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Text(text = "Add \"${item.title}\" to…", color = Color.White, fontSize = 16.sp, maxLines = 1)
        Spacer(modifier = Modifier.height(14.dp))

            playlists.forEach { playlist ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onPickPlaylist(playlist.id) }
                        .padding(vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.PlaylistPlay, contentDescription = null, tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(text = playlist.name, color = Color.White, fontSize = 15.sp)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White.copy(alpha = 0.06f))
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    if (newName.isEmpty()) {
                        Text("New playlist name", color = Color.White.copy(alpha = 0.4f), fontSize = 14.sp)
                    }
                    BasicTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                        cursorBrush = SolidColor(Color.White),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                Text(
                    text = "Add",
                    color = Color.White,
                    fontSize = 14.sp,
                    modifier = Modifier.clickable(enabled = newName.isNotBlank()) { onCreateAndAdd(newName) },
                )
            }
        }
    }
