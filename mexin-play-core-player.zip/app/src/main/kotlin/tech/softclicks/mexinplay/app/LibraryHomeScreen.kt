package tech.softclicks.mexinplay.app

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private data class LibrarySection(
    val title: String,
    val subtitle: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val accent: Color,
)

private val SECTIONS = listOf(
    LibrarySection("Pulse", "Your music", Icons.Filled.GraphicEq, Color(0xFF2A2A32)),
    LibrarySection("Flux", "Your videos", Icons.Filled.AutoAwesome, Color(0xFF1E222C)),
    LibrarySection("Playlists", "What you've built", Icons.Filled.PlaylistPlay, Color(0xFF241E2C)),
)

/**
 * Real landing screen — not the player. A 3D cover-flow of section
 * panels the person picks a destination from, built directly on the
 * apple-design skill's motion rules rather than a Compose HorizontalPager
 * with default settling: §2 (1:1 drag tracking), §5 (velocity carries
 * into the settle animation, no seam), §6 (Apple's own momentum
 * projection function picks the landing panel, not just nearest-to-
 * release-point), §9 (rubber-band past the first/last panel instead of
 * a hard stop).
 */
@Composable
fun LibraryHomeScreen(
    onOpenPulse: () -> Unit,
    onOpenFlux: () -> Unit,
    onOpenPlaylists: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var containerWidthPx by remember { mutableFloatStateOf(0f) }
    val offsetPx = remember { Animatable(0f) }
    val coroutineScope = rememberCoroutineScope()
    var velocityTracker by remember { mutableStateOf(VelocityTracker()) }

    val pageCount = SECTIONS.size
    val minOffset = -(pageCount - 1) * containerWidthPx
    val maxOffset = 0f

    Column(
        modifier = modifier.fillMaxSize().padding(top = 24.dp),
    ) {
        Text(
            text = "MEXIN PLAY",
            style = tech.softclicks.mexinplay.core.ui.glass.AppTypography.eyebrow,
            color = Color.White.copy(alpha = 0.5f),
            modifier = Modifier.padding(horizontal = 24.dp),
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Your library",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier.padding(horizontal = 24.dp),
        )

        Spacer(modifier = Modifier.height(28.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .onSizeChanged { containerWidthPx = it.width.toFloat() }
                .pointerInput(containerWidthPx) {
                    if (containerWidthPx <= 0f) return@pointerInput
                    detectDragForCoverFlow(
                        onDragStart = { velocityTracker = VelocityTracker() },
                        onDrag = { change, dragAmount ->
                            velocityTracker.addPosition(change.uptimeMillis, change.position)
                            val proposed = offsetPx.value + dragAmount
                            val clamped = when {
                                proposed > maxOffset -> maxOffset + rubberband(proposed - maxOffset, containerWidthPx)
                                proposed < minOffset -> minOffset - rubberband(minOffset - proposed, containerWidthPx)
                                else -> proposed
                            }
                            coroutineScope.launch { offsetPx.snapTo(clamped) }
                        },
                        onDragEnd = {
                            val velocity = velocityTracker.calculateVelocity().x
                            val projected = offsetPx.value + project(velocity)
                            val targetPage = (-projected / containerWidthPx).roundToInt().coerceIn(0, pageCount - 1)
                            val target = -targetPage * containerWidthPx
                            coroutineScope.launch {
                                offsetPx.animateTo(target, appleMomentumSpring(), initialVelocity = velocity)
                            }
                        },
                    )
                },
        ) {
            if (containerWidthPx > 0f) {
                SECTIONS.forEachIndexed { index, section ->
                    val basePosition = index * containerWidthPx
                    val distanceFromCenter = (basePosition + offsetPx.value) / containerWidthPx

                    CoverFlowPanel(
                        section = section,
                        distanceFromCenter = distanceFromCenter,
                        containerWidthPx = containerWidthPx,
                        onClick = {
                            when (index) {
                                0 -> onOpenPulse()
                                1 -> onOpenFlux()
                                else -> onOpenPlaylists()
                            }
                        },
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Page indicator — reads the same continuous offset, so it eases
        // in step with the drag instead of snapping between dots.
        Box(modifier = Modifier.fillMaxWidth().padding(bottom = 28.dp), contentAlignment = Alignment.Center) {
            val currentPage = if (containerWidthPx > 0f) -offsetPx.value / containerWidthPx else 0f
            androidx.compose.foundation.layout.Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                SECTIONS.indices.forEach { i ->
                    val proximity = (1f - (currentPage - i).let { if (it < 0) -it else it }).coerceIn(0f, 1f)
                    Box(
                        modifier = Modifier
                            .size(width = (6 + proximity * 12).dp, height = 6.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.25f + proximity * 0.65f)),
                    )
                }
            }
        }
    }
}

@Composable
private fun CoverFlowPanel(
    section: LibrarySection,
    distanceFromCenter: Float,
    containerWidthPx: Float,
    onClick: () -> Unit,
) {
    val density = LocalDensity.current
    val panelWidthDp = with(density) { (containerWidthPx * 0.72f).toDp() }
    val clampedDistance = distanceFromCenter.coerceIn(-2f, 2f)
    val scale = 1f - (kotlin.math.abs(clampedDistance) * 0.22f)
    val rotationY = clampedDistance * -35f
    val alpha = (1f - kotlin.math.abs(clampedDistance) * 0.55f).coerceIn(0.15f, 1f)
    val translationXPx = distanceFromCenter * containerWidthPx

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                this.translationX = translationXPx
                this.scaleX = scale
                this.scaleY = scale
                this.rotationY = rotationY
                this.alpha = alpha
                this.cameraDistance = 24f * density.density // flattens the perspective so rotationY reads as a card tilt, not a warp
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .width(panelWidthDp)
                .fillMaxSize()
                .padding(vertical = 16.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(section.accent)
                .pressScale(onTap = onClick),
            contentAlignment = Alignment.BottomStart,
        ) {
            Icon(
                imageVector = section.icon,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.08f),
                modifier = Modifier.size(180.dp).align(Alignment.Center),
            )
            Column(modifier = Modifier.padding(24.dp)) {
                Text(text = section.title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(text = section.subtitle, fontSize = 14.sp, color = Color.White.copy(alpha = 0.6f))
            }
        }
    }
}

/** Thin wrapper so the raw pointer-event loop (needed for real VelocityTracker input) reads like the higher-level drag APIs elsewhere in the codebase. */
private suspend fun androidx.compose.ui.input.pointer.PointerInputScope.detectDragForCoverFlow(
    onDragStart: () -> Unit,
    onDrag: (change: androidx.compose.ui.input.pointer.PointerInputChange, dragAmount: Float) -> Unit,
    onDragEnd: () -> Unit,
) {
    androidx.compose.foundation.gestures.detectHorizontalDragGestures(
        onDragStart = { onDragStart() },
        onDragEnd = onDragEnd,
        onDragCancel = onDragEnd,
        onHorizontalDrag = { change, dragAmount -> onDrag(change, dragAmount) },
    )
}
