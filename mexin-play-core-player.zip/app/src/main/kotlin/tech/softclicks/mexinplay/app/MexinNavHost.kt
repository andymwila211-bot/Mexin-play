package tech.softclicks.mexinplay.app

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import tech.softclicks.mexinplay.core.player.PlaybackController
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.AuraBackground
import tech.softclicks.mexinplay.core.ui.glass.FluxColors
import tech.softclicks.mexinplay.core.ui.glass.GlassSurface
import tech.softclicks.mexinplay.core.ui.glass.PulseColors
import tech.softclicks.mexinplay.core.ui.glass.ShellColors
import tech.softclicks.mexinplay.feature.flux.FluxHomeScreen
import tech.softclicks.mexinplay.feature.pulse.PulseHomeScreen

private const val ROUTE_PULSE = "pulse"
private const val ROUTE_FLUX = "flux"

/**
 * Top-level shell. One shared Aura glow lives behind both screens and
 * cross-fades color on navigation — see AuraBackground's doc comment
 * for why: it's the visual expression of "one engine, two themed UIs,"
 * not decoration. Real media/playback state now comes from
 * MexinPlayViewModel instead of hardcoded null/placeholder lists.
 */
@Composable
fun MexinNavHost(playbackController: PlaybackController, viewModel: MexinPlayViewModel) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ROUTE_PULSE

    val pulseQueue by viewModel.pulseQueue.collectAsState()
    val fluxQueue by viewModel.fluxQueue.collectAsState()
    val nowPlaying by viewModel.nowPlaying.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()

    val auraColor by animateColorAsState(
        targetValue = if (currentRoute == ROUTE_FLUX) FluxColors.glow else PulseColors.glow,
        animationSpec = tween(durationMillis = 450),
        label = "auraColor",
    )

    Box(modifier = Modifier.fillMaxSize().background(ShellColors.base)) {
        AuraBackground(color = auraColor)

        NavHost(navController = navController, startDestination = ROUTE_PULSE) {
            composable(ROUTE_PULSE) {
                PulseHomeScreen(
                    nowPlaying = nowPlaying,
                    isPlaying = isPlaying,
                    discoverItems = pulseQueue,
                    onSelectItem = { viewModel.play(it, pulseQueue) },
                    onPlayPause = { viewModel.togglePlayPause() },
                    onNext = { viewModel.playNext() },
                    onPrevious = { viewModel.playPrevious() },
                )
            }
            composable(ROUTE_FLUX) {
                FluxHomeScreen(
                    nowPlaying = nowPlaying,
                    isPlaying = isPlaying,
                    discoverItems = fluxQueue,
                    onSelectItem = { viewModel.play(it, fluxQueue) },
                    onPlayPause = { viewModel.togglePlayPause() },
                    onNext = { viewModel.playNext() },
                    onPrevious = { viewModel.playPrevious() },
                )
            }
        }

        GlassBottomBar(
            currentRoute = currentRoute,
            onSelect = { route ->
                navController.navigate(route) { launchSingleTop = true }
            },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(20.dp),
        )
    }
}

@Composable
private fun GlassBottomBar(
    currentRoute: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val navAccent = if (currentRoute == ROUTE_FLUX) FluxColors.accent else PulseColors.accent

    GlassSurface(modifier = modifier.width(232.dp), cornerRadius = 28.dp) {
        Row(
            modifier = Modifier.padding(start = 20.dp, end = 14.dp, top = 14.dp, bottom = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                NavTab(
                    label = "Pulse",
                    icon = Icons.Filled.MusicNote,
                    selected = currentRoute == ROUTE_PULSE,
                    accent = PulseColors.accent,
                    onClick = { onSelect(ROUTE_PULSE) },
                )
                NavTab(
                    label = "Flux",
                    icon = Icons.Filled.Movie,
                    selected = currentRoute == ROUTE_FLUX,
                    accent = FluxColors.accent,
                    onClick = { onSelect(ROUTE_FLUX) },
                )
            }

            // Divider separates persistent navigation (left) from a
            // one-off action (right) — mixing them undifferentiated
            // would read as "three tabs" when search isn't a destination
            // you stay on the way Pulse/Flux are.
            Box(
                modifier = Modifier
                    .padding(horizontal = 16.dp)
                    .width(1.dp)
                    .height(24.dp)
                    .background(Color.White.copy(alpha = 0.15f)),
            )

            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.08f))
                    .selectable(selected = false, onClick = { /* search: not wired yet */ }),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Filled.Search,
                    contentDescription = "Search",
                    tint = navAccent,
                    modifier = Modifier.size(18.dp),
                )
            }
        }
    }
}

@Composable
private fun NavTab(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val tint = if (selected) accent else accent.copy(alpha = 0.35f)
    Column(
        modifier = modifier.selectable(selected = selected, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(imageVector = icon, contentDescription = label, tint = tint)
        Box(
            modifier = Modifier
                .padding(top = 6.dp)
                .size(width = if (selected) 18.dp else 0.dp, height = 3.dp)
                .background(
                    color = accent,
                    shape = RoundedCornerShape(2.dp),
                ),
        )
    }
}
