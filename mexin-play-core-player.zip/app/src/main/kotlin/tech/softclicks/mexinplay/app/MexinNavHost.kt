package tech.softclicks.mexinplay.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import tech.softclicks.mexinplay.core.player.PlaybackController
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AuraBackground
import tech.softclicks.mexinplay.core.ui.glass.ShellColors
import tech.softclicks.mexinplay.feature.flux.FluxHomeScreen
import tech.softclicks.mexinplay.feature.pulse.PulseHomeScreen

private const val ROUTE_PULSE = "pulse"
private const val ROUTE_FLUX = "flux"

/**
 * Top-level shell. Flat backdrop, no color-morphing glow — Pulse and
 * Flux are visually distinct through layout, not a shared decorative
 * effect. The Pulse/Flux switcher is a two-segment pill matching the
 * reference; a search button sits above it and opens a minimal
 * text-filter overlay over whichever queue (Pulse or Flux) is active —
 * the reference screenshots didn't show a search affordance at all, so
 * this is a functional addition rather than a copy of anything pictured.
 */
@Composable
fun MexinNavHost(playbackController: PlaybackController, viewModel: MexinPlayViewModel) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ROUTE_PULSE

    val pulseQueue by viewModel.pulseQueue.collectAsState()
    val fluxQueue by viewModel.fluxQueue.collectAsState()
    val nowPlaying by viewModel.nowPlaying.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()

    var isSearchOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    fun filtered(items: List<PlayableItem>): List<PlayableItem> {
        if (searchQuery.isBlank()) return items
        return items.filter { it.title.contains(searchQuery, ignoreCase = true) }
    }

    Box(modifier = Modifier.fillMaxSize().background(ShellColors.base)) {
        AuraBackground()

        NavHost(navController = navController, startDestination = ROUTE_PULSE) {
            composable(ROUTE_PULSE) {
                PulseHomeScreen(
                    nowPlaying = nowPlaying,
                    isPlaying = isPlaying,
                    discoverItems = filtered(pulseQueue),
                    onSelectItem = { viewModel.play(it, pulseQueue) },
                    onPlayPause = { viewModel.togglePlayPause() },
                    onNext = { viewModel.playNext() },
                    onPrevious = { viewModel.playPrevious() },
                    playbackController = playbackController,
                )
            }
            composable(ROUTE_FLUX) {
                FluxHomeScreen(
                    nowPlaying = nowPlaying,
                    isPlaying = isPlaying,
                    discoverItems = filtered(fluxQueue),
                    onSelectItem = { viewModel.play(it, fluxQueue) },
                    onPlayPause = { viewModel.togglePlayPause() },
                    onNext = { viewModel.playNext() },
                    onPrevious = { viewModel.playPrevious() },
                    playbackController = playbackController,
                )
            }
        }

        if (isSearchOpen) {
            SearchOverlay(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                onClose = { isSearchOpen = false; searchQuery = "" },
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 20.dp, start = 20.dp, end = 20.dp),
            )
        } else {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 20.dp, end = 20.dp)
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1A1A1F))
                    .border(1.dp, Color.White.copy(alpha = 0.08f), CircleShape)
                    .clickable { isSearchOpen = true },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Search, contentDescription = "Search", tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(20.dp))
            }
        }

        // Both reference screens — portrait Pulse and landscape Flux —
        // anchor the pill bottom-center, so one placement covers both.
        PulseFluxSwitch(
            currentRoute = currentRoute,
            onSelect = { route -> navController.navigate(route) { launchSingleTop = true } },
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp),
        )
    }
}

@Composable
private fun SearchOverlay(
    query: String,
    onQueryChange: (String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xFF1A1A1F))
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(24.dp))
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Search, contentDescription = null, tint = Color.White.copy(alpha = 0.5f), modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Box(modifier = Modifier.weight(1f)) {
            if (query.isEmpty()) {
                Text("Search your library", fontSize = 15.sp, color = Color.White.copy(alpha = 0.4f))
            }
            BasicTextField(
                value = query,
                onValueChange = onQueryChange,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                cursorBrush = androidx.compose.ui.graphics.SolidColor(Color.White),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Icon(
            Icons.Filled.Close,
            contentDescription = "Close search",
            tint = Color.White.copy(alpha = 0.6f),
            modifier = Modifier.size(18.dp).clickable(onClick = onClose),
        )
    }
}

@Composable
private fun PulseFluxSwitch(
    currentRoute: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(30.dp))
            .background(Color(0xFF1A1A1F))
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(30.dp))
            .padding(5.dp),
    ) {
        SwitchSegment(
            label = "Pulse",
            icon = Icons.Filled.GraphicEq,
            selected = currentRoute == ROUTE_PULSE,
            onClick = { onSelect(ROUTE_PULSE) },
        )
        SwitchSegment(
            label = "Flux",
            icon = Icons.Filled.AutoAwesome,
            selected = currentRoute == ROUTE_FLUX,
            onClick = { onSelect(ROUTE_FLUX) },
        )
    }
}

@Composable
private fun SwitchSegment(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(24.dp))
            .background(if (selected) Color.White else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (selected) Color.Black else Color.White.copy(alpha = 0.55f),
            modifier = Modifier.height(16.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = label,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (selected) Color.Black else Color.White.copy(alpha = 0.6f),
        )
    }
}
