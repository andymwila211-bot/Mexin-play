package tech.softclicks.mexinplay.app

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import tech.softclicks.mexinplay.core.player.PlaybackController
import tech.softclicks.mexinplay.core.ui.glass.FluxColors
import tech.softclicks.mexinplay.core.ui.glass.GlassSurface
import tech.softclicks.mexinplay.core.ui.glass.PulseColors
import tech.softclicks.mexinplay.feature.flux.FluxHomeScreen
import tech.softclicks.mexinplay.feature.pulse.PulseHomeScreen

private const val ROUTE_PULSE = "pulse"
private const val ROUTE_FLUX = "flux"

/**
 * Top-level shell: two destinations (Pulse, Flux), one glass bottom bar
 * to switch between them. `nowPlaying` is hardcoded null on both screens
 * for now — real media loading (device library scan) isn't wired yet,
 * that's the next isolated step, not bundled in here.
 */
@Composable
fun MexinNavHost(playbackController: PlaybackController) {
    val navController = rememberNavController()

    Box {
        NavHost(navController = navController, startDestination = ROUTE_PULSE) {
            composable(ROUTE_PULSE) {
                PulseHomeScreen(nowPlaying = null)
            }
            composable(ROUTE_FLUX) {
                FluxHomeScreen(nowPlaying = null)
            }
        }

        GlassBottomBar(
            navController = navController,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp),
        )
    }
}

@Composable
private fun GlassBottomBar(
    navController: NavHostController,
    modifier: Modifier = Modifier,
) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ROUTE_PULSE

    GlassSurface(modifier = modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(horizontal = 24.dp, vertical = 14.dp)) {
            NavTab(
                label = "Pulse",
                selected = currentRoute == ROUTE_PULSE,
                accent = PulseColors.accent,
                onClick = {
                    navController.navigate(ROUTE_PULSE) {
                        launchSingleTop = true
                    }
                },
                modifier = Modifier.weight(1f),
            )
            NavTab(
                label = "Flux",
                selected = currentRoute == ROUTE_FLUX,
                accent = FluxColors.accent,
                onClick = {
                    navController.navigate(ROUTE_FLUX) {
                        launchSingleTop = true
                    }
                },
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun NavTab(
    label: String,
    selected: Boolean,
    accent: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier.selectable(selected = selected, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (selected) accent else accent.copy(alpha = 0.4f),
            style = MaterialTheme.typography.labelLarge,
        )
    }
}
