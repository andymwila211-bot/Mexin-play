package tech.softclicks.mexinplay.app

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import tech.softclicks.mexinplay.core.player.PlaybackController
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.AuraBackground
import tech.softclicks.mexinplay.core.ui.glass.FluxColors
import tech.softclicks.mexinplay.core.ui.glass.GlassSurface
import tech.softclicks.mexinplay.core.ui.glass.PulseColors
import tech.softclicks.mexinplay.core.ui.glass.ShellColors
import tech.softclicks.mexinplay.feature.flux.FluxHomeScreen
import tech.softclicks.mexinplay.feature.pulse.PulseHomeScreen

private const val ROUTE_PULSE = "pulse"
private const val ROUTE_FLUX = "flux"

/**
 * Top-level shell. One shared Aura glow lives behind both screens and
 * cross-fades color on navigation — see AuraBackground's doc comment
 * for why: it's the visual expression of "one engine, two themed UIs,"
 * not decoration. `nowPlaying` is hardcoded null on both screens for
 * now — real media loading isn't wired yet, that's the next isolated
 * step (see README).
 */
@Composable
fun MexinNavHost(playbackController: PlaybackController) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ROUTE_PULSE

    val auraColor by animateColorAsState(
        targetValue = if (currentRoute == ROUTE_FLUX) FluxColors.glow else PulseColors.glow,
        animationSpec = tween(durationMillis = 450),
        label = "auraColor",
    )

    Box(modifier = Modifier.fillMaxSize().background(ShellColors.base)) {
        AuraBackground(color = auraColor)

        NavHost(navController = navController, startDestination = ROUTE_PULSE) {
            composable(ROUTE_PULSE) { PulseHomeScreen(nowPlaying = null) }
            composable(ROUTE_FLUX) { FluxHomeScreen(nowPlaying = null) }
        }

        GlassBottomBar(
            currentRoute = currentRoute,
            onSelect = { route ->
                navController.navigate(route) { launchSingleTop = true }
            },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(20.dp),
        )
    }
}

@Composable
private fun GlassBottomBar(
    currentRoute: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    GlassSurface(modifier = modifier.fillMaxWidth(), cornerRadius = 28.dp) {
        Row(modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
            NavTab(
                label = "Pulse",
                icon = Icons.Filled.MusicNote,
                selected = currentRoute == ROUTE_PULSE,
                accent = PulseColors.accent,
                onClick = { onSelect(ROUTE_PULSE) },
                modifier = Modifier.weight(1f),
            )
            NavTab(
                label = "Flux",
                icon = Icons.Filled.Movie,
                selected = currentRoute == ROUTE_FLUX,
                accent = FluxColors.accent,
                onClick = { onSelect(ROUTE_FLUX) },
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun NavTab(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val tint = if (selected) accent else accent.copy(alpha = 0.35f)
    Column(
        modifier = modifier.selectable(selected = selected, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(imageVector = icon, contentDescription = label, tint = tint)
        Box(
            modifier = Modifier
                .padding(top = 6.dp)
                .size(if (selected) 4.dp else 0.dp)
                .background(color = accent, shape = androidx.compose.foundation.shape.CircleShape),
        )
    }
}
