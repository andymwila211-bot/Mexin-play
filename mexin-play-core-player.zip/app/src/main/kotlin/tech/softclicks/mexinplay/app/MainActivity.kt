package tech.softclicks.mexinplay.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val app = application as MexinPlayApplication

        setContent {
            MexinNavHost(playbackController = app.playbackController)
        }
    }
}
