package tech.softclicks.mexinplay.core.player.history

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * One row per playback event (a play that started, and whether/when it
 * was skipped). This is the entire "learning" substrate for v1 — no
 * model, just a log the heuristic shuffle engine scores against. See
 * SmartShuffleEngine for why this is enough for now.
 */
@Entity(tableName = "play_events")
data class PlayEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "media_id") val mediaId: String,
    @ColumnInfo(name = "started_at_epoch_ms") val startedAtEpochMs: Long,
    @ColumnInfo(name = "hour_of_day") val hourOfDay: Int,
    @ColumnInfo(name = "day_of_week") val dayOfWeek: Int,
    @ColumnInfo(name = "played_ms") val playedMs: Long,
    @ColumnInfo(name = "duration_ms") val durationMs: Long,
    @ColumnInfo(name = "was_skipped") val wasSkipped: Boolean,
)

@Dao
interface PlayHistoryDao {
    @Insert
    suspend fun record(event: PlayEventEntity)

    @Query("SELECT * FROM play_events WHERE media_id = :mediaId ORDER BY started_at_epoch_ms DESC")
    fun eventsFor(mediaId: String): Flow<List<PlayEventEntity>>

    @Query(
        """
        SELECT media_id, COUNT(*) as playCount,
               SUM(CASE WHEN was_skipped THEN 1 ELSE 0 END) as skipCount,
               MAX(started_at_epoch_ms) as lastPlayedAt
        FROM play_events
        GROUP BY media_id
        """
    )
    fun aggregatedStats(): Flow<List<MediaPlayStats>>

    @Query(
        """
        SELECT media_id, COUNT(*) as playCount,
               SUM(CASE WHEN was_skipped THEN 1 ELSE 0 END) as skipCount,
               MAX(started_at_epoch_ms) as lastPlayedAt
        FROM play_events
        WHERE hour_of_day BETWEEN :startHour AND :endHour
        GROUP BY media_id
        """
    )
    suspend fun statsForHourWindow(startHour: Int, endHour: Int): List<MediaPlayStats>
}

data class MediaPlayStats(
    @ColumnInfo(name = "media_id") val mediaId: String,
    val playCount: Int,
    val skipCount: Int,
    val lastPlayedAt: Long,
)
