package tech.softclicks.mexinplay.core.player.shuffle

import tech.softclicks.mexinplay.core.player.history.MediaPlayStats
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import java.util.Calendar
import kotlin.random.Random

/**
 * v1 shuffle: a weighted-random pick, not a trained model.
 *
 * Deliberate choice, not a shortcut we plan to hide: an on-device model
 * trained on zero/near-zero data at install time produces noise, not
 * personalization. This heuristic gives the "it learns me" feel
 * immediately from real signal (play_events), and is the thing a future
 * embedding-based model would need to beat — not replace on day one.
 *
 * Score components, each in [0, 1] before weighting:
 *  - recencyPenalty: recently played items are less likely to repeat
 *  - skipRatePenalty: items with a high skip rate score lower
 *  - timeOfDayAffinity: items historically played in the current hour
 *    window score higher (keys off hour_of_day bucket, not a live clock
 *    dependency inside this class — caller passes the current hour so
 *    this stays pure/testable)
 */
class SmartShuffleEngine(
    private val random: Random = Random.Default,
) {
    fun weightedShuffle(
        candidates: List<PlayableItem>,
        statsByMediaId: Map<String, MediaPlayStats>,
        currentEpochMs: Long,
        currentHourOfDay: Int,
        weights: Weights = Weights(),
    ): List<PlayableItem> {
        if (candidates.isEmpty()) return emptyList()

        val scored = candidates.map { item ->
            val stats = statsByMediaId[item.id]
            val score = scoreFor(item, stats, currentEpochMs, currentHourOfDay, weights)
            item to score
        }

        // Weighted sampling without replacement: repeatedly draw from the
        // remaining pool proportional to score, rather than a plain sort,
        // so the result isn't perfectly deterministic run-to-run (that
        // would feel robotic, not "smart").
        val pool = scored.toMutableList()
        val ordered = mutableListOf<PlayableItem>()
        while (pool.isNotEmpty()) {
            val totalWeight = pool.sumOf { it.second.toDouble() }.coerceAtLeast(0.0001)
            var pick = random.nextDouble() * totalWeight
            var index = 0
            for (i in pool.indices) {
                pick -= pool[i].second
                if (pick <= 0) {
                    index = i
                    break
                }
                index = i
            }
            ordered += pool.removeAt(index).first
        }
        return ordered
    }

    private fun scoreFor(
        item: PlayableItem,
        stats: MediaPlayStats?,
        currentEpochMs: Long,
        currentHourOfDay: Int,
        weights: Weights,
    ): Float {
        if (stats == null) {
            // Unplayed items get a flat mid score — new content shouldn't
            // be buried, but also shouldn't dominate every shuffle.
            return weights.baselineForUnplayed
        }

        val hoursSincePlayed = ((currentEpochMs - stats.lastPlayedAt) / 3_600_000L)
            .coerceAtLeast(0)
        val recencyScore = (1f - (1f / (1f + hoursSincePlayed / 24f))).coerceIn(0f, 1f)

        val skipRate = if (stats.playCount > 0) {
            stats.skipCount.toFloat() / stats.playCount.toFloat()
        } else 0f
        val skipPenalty = 1f - skipRate

        // Placeholder until per-item hour buckets are wired through the
        // DAO call site; caller currently supplies the pre-filtered stats
        // set for the active hour window, so this is a light boost, not
        // the primary signal, until that plumbing lands.
        val timeAffinity = if (currentHourOfDay in 0..23) 1f else 0.5f

        return (recencyScore * weights.recency +
            skipPenalty * weights.skipRate +
            timeAffinity * weights.timeOfDay)
            .coerceAtLeast(0.01f) // never fully zero out — keep it in the pool
    }

    data class Weights(
        val recency: Float = 0.5f,
        val skipRate: Float = 0.35f,
        val timeOfDay: Float = 0.15f,
        val baselineForUnplayed: Float = 0.6f,
    )

    companion object {
        fun currentHourOfDay(calendar: Calendar = Calendar.getInstance()): Int =
            calendar.get(Calendar.HOUR_OF_DAY)
    }
}
