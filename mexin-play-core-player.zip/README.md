# Mexin Play — core-player (Phase 1)

SOFTCLICKS TECH. Multi-purpose media player for Android — music (**Pulse**)
and video (**Flux**) in one app, themed distinctly but sharing one
playback engine and one shuffle brain.

## What's in this drop

Only `:core-player` — the module every other feature depends on, built
first on purpose so the UI layers (`feature-pulse`, `feature-flux`,
`core-ui-glass`) have something real to sit on top of instead of mocking
a player interface that changes later.

- `PlaybackController` — wraps a single ExoPlayer/Media3 instance. Both
  Pulse and Flux screens call into this; neither talks to Media3 directly.
- `history/` — Room database logging every play event (started, duration
  played, skipped or not, hour/day). This is the entire training signal
  for v1's shuffle.
- `shuffle/SmartShuffleEngine` — weighted-random shuffle scored on
  recency, skip rate, and time-of-day, **not** a trained model. See the
  doc comment in that file for why: a model trained on install-day data
  is noise. This heuristic is the baseline a future model has to beat.
- `model/MediaType.kt` — the `PULSE` / `FLUX` split that the theming
  layer keys off of.

## Deliberately not decided/built here

- Engine choice: staying on ExoPlayer, not libVLC — cross-compiling
  native libVLC for CI wasn't worth it for a solo-maintained app. See
  the comment in `core-player/build.gradle.kts`.
- UI: themed variants (different palette/density per Pulse vs. Flux),
  not two fully separate interaction paradigms — full paradigm split
  roughly doubles design/QA surface for one dev; flag it again if that's
  actually wanted instead.
- Glassmorphism via the **Haze** library, once `core-ui-glass` lands.
  Haze blurs real content behind it — screens need actual thumbnail/art
  density behind glass panels or it just looks like flat gray.

## CI

`.github/workflows/android-build.yml` runs unit tests + assembles
`core-player` on every push. **It currently calls `gradle` directly, not
`./gradlew`**, because this scaffold doesn't include a committed
`gradle-wrapper.jar` (binary file, can't be generated in the sandbox this
was built in). Before relying on this long-term: run `gradle wrapper`
locally once, commit `gradle/wrapper/gradle-wrapper.jar` +
`.properties`, and swap the workflow back to `./gradlew`.

## Not yet scaffolded

`:feature-pulse`, `:feature-flux`, `:core-ui-glass`, `:app` — next phase,
per "player core first, then player UI."
