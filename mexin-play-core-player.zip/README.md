# Mexin Play — core-player (Phase 1)

SOFTCLICKS TECH. Multi-purpose media player for Android — music (**Pulse**)
and video (**Flux**) in one app, themed distinctly but sharing one
playback engine and one shuffle brain.

# Mexin Play (Phase 2: UI foundation)

SOFTCLICKS TECH. Multi-purpose media player for Android — music (**Pulse**)
and video (**Flux**) in one app, themed distinctly but sharing one
playback engine and one shuffle brain.

## What's in this drop

Phase 1 (`:core-player`) plus the UI foundation:

- `:core-ui-glass` — `GlassSurface`, a placeholder glassmorphism
  composable (solid translucent fill + gradient border, same shape a
  real blur panel will have) and the `PulseColors`/`FluxColors` palettes.
  **Haze is deliberately not wired in yet** — see below.
- `:feature-pulse` / `:feature-flux` — minimal themed home screens
  proving the module graph (`core-player` + `core-ui-glass` consumed
  together, Compose configured correctly) actually compiles. Not
  finished UI — that's next, once this is confirmed green.

Phase 1 contents (`PlaybackController`, Room play-history, `SmartShuffleEngine`)
unchanged — see git history / prior README revision for those notes.

## Why Haze isn't in yet

Real reason, not a stall: the current Haze release's exact dependency
surface (plain AndroidX Compose vs. Compose Multiplatform artifacts) has
enough version ambiguity that it couldn't be verified without a live
compile, which isn't available in the environment this was built in.
Wiring it in alongside a Kotlin version bump *and* two new modules risked
breaking all of it at once with no clear signal of which change was at
fault. `GlassSurface` exists as the seam — swapping its internals for
real Haze blur later won't touch any call site in `feature-pulse` or
`feature-flux`.

## Kotlin/AGP/Compose version bump

Compose requires a much newer Kotlin than Phase 1 was on. Bumped
project-wide (affects `core-player` too, automatically, since it inherits
the root-declared plugin versions):

- Kotlin `1.9.24` → `2.0.21`
- KSP `1.9.24-1.0.20` → `2.0.21-1.0.28` (must track the Kotlin version)
- AGP `8.5.2` → `8.6.0`
- Added `org.jetbrains.kotlin.plugin.compose` (Compose Compiler is a
  separate Gradle plugin as of Kotlin 2.0 — the old
  `composeOptions.kotlinCompilerExtensionVersion` approach is deprecated)
- Compose BOM: `androidx.compose:compose-bom:2024.10.01`

## Deliberately not decided/built here

- Engine choice: staying on ExoPlayer, not libVLC.
- UI: themed variants (different palette per Pulse/Flux, same shell),
  not two fully separate interaction paradigms.
- Real Haze blur — see above.
- Navigation, actual library browsing, queue UI — `PulseHomeScreen`/
  `FluxHomeScreen` are proof-of-wiring stubs, not real screens.

## CI

`.github/workflows/build.yml` — maintained directly in the GitHub web
editor (typed path, not uploaded — see repo history). **Needs a manual
update** to build the three new modules; the version shipped with Phase 1
only knew about `:core-player`. Updated content provided separately.

No committed `gradle-wrapper.jar` — workflow calls `gradle` directly,
not `./gradlew`. Generate the wrapper locally when moving off CI-only
verification.

## Not yet scaffolded

`:app` — once Pulse/Flux screens are real enough to host in an actual
installable application.
