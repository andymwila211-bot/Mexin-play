pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "MexinPlay"

// Phase 1: core-player. Phase 2: UI foundation (core-ui-glass) and the
// two themed screen modules. :app still not scaffolded — comes once
// Pulse/Flux screens are real enough to host in an actual application.
include(":core-player")
include(":core-ui-glass")
include(":feature-pulse")
include(":feature-flux")
