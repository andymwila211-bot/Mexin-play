pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "MexinPlay"

// Phase 1: player core only. feature-pulse, feature-flux, core-ui-glass,
// and app are scaffolded next once the playback/shuffle core is settled.
include(":core-player")
