package tech.softclicks.mexinplay.feature.flux

import android.app.Activity
import android.content.pm.ActivityInfo
import android.view.WindowManager
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import tech.softclicks.mexinplay.core.player.PlaybackController
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.GlassWeight
import tech.softclicks.mexinplay.core.ui.glass.Scrubber
import tech.softclicks.mexinplay.core.ui.glass.appleSpring
import tech.softclicks.mexinplay.core.ui.glass.glassSurface
import tech.softclicks.mexinplay.core.ui.glass.pressScale
import tech.softclicks.mexinplay.core.ui.glass.rememberReducedMotionPreference

/**
 * Matches the Flux reference: landscape "Cinema" layout with a preview
 * pane (camera glyph + "No Signal — Preview" placeholder when nothing
 * is loaded), title + runtime/format metadata row, straight progress
 * bar, and prev/play/next controls in circular chrome. This screen
 * locks the activity to landscape while it's on screen — Flux is a
 * landscape-only surface, Pulse stays portrait. Tapping the preview
 * pane goes further than the screenshot: it hides system bars and the
 * chrome entirely for actual edge-to-edge fullscreen playback, since
 * "full screen" wasn't literally what the static mockup shows.
 */
@Composable
fun FluxHomeScreen(
    nowPlaying: PlayableItem?,
    isPlaying: Boolean,
    library: List<PlayableItem>,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onOpenDiscover: () -> Unit,
    onSelectItem: (PlayableItem) -> Unit,
    playbackController: PlaybackController,
    modifier: Modifier = Modifier,
) {
    LockLandscapeWhileVisible()
    var isFullscreen by remember { mutableStateOf(false) }
    val (positionMs, durationMs) = rememberPlaybackProgress(playbackController, isPlaying, nowPlaying?.id)

    if (isFullscreen) {
        FullscreenPlayer(
            playbackController = playbackController,
            onExit = { isFullscreen = false },
        )
        return
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 32.dp)
            .padding(top = 28.dp, bottom = 90.dp), // clearance for the Pulse/Flux switch overlay anchored at the bottom
    ) {
        Text(
            text = "FLUX",
            style = AppTypography.eyebrow,
            color = Color.White.copy(alpha = 0.5f),
        )
        Text(
            // Kept static, like the "PULSE" eyebrow — this is the section
            // label, not a content field. Making it track nowPlaying.title
            // would just duplicate the title already shown in the card
            // below it.
            text = "Cinema",
            style = AppTypography.displayLarge.copy(fontSize = 44.sp),
            color = Color.White,
            modifier = Modifier.padding(top = 2.dp, bottom = 18.dp),
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .glassSurface(shape = RoundedCornerShape(20.dp), weight = GlassWeight.Regular),
        ) {
            PreviewPane(
                nowPlaying = nowPlaying,
                playbackController = playbackController,
                onTap = { isFullscreen = true },
                modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f),
            )

            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = nowPlaying?.title ?: "Nothing loaded",
                    style = AppTypography.headline,
                    color = Color.White,
                )
                Text(
                    text = nowPlaying?.let { "Runtime ${formatDuration(it.durationMs)}" }
                        ?: "Pick something from Discover below",
                    style = AppTypography.bodyMuted,
                    color = Color.White.copy(alpha = 0.55f),
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp),
                )

                Scrubber(
                    elapsedLabel = formatDuration(positionMs),
                    totalLabel = if (durationMs > 0) "-" + formatDuration((durationMs - positionMs).coerceAtLeast(0)) else "--:--",
                    progress = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f,
                    enabled = nowPlaying != null && durationMs > 0,
                    onSeek = { fraction -> playbackController.seekTo((fraction * durationMs).toLong()) },
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 18.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RoundIconButton(icon = Icons.Filled.ChevronLeft, contentDescription = "Previous", onClick = onPrevious)
                    Spacer(modifier = Modifier.width(24.dp))
                    RoundIconButton(
                        icon = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        onClick = onPlayPause,
                        primary = true,
                    )
                    Spacer(modifier = Modifier.width(24.dp))
                    RoundIconButton(icon = Icons.Filled.ChevronRight, contentDescription = "Next", onClick = onNext)
                }
            }
        }

        if (library.isNotEmpty()) {
            Spacer(modifier = Modifier.height(32.dp))
            MovieRow(
                title = "Your Library",
                items = library,
                nowPlayingId = nowPlaying?.id,
                onSelectItem = onSelectItem,
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Sub-screen entry point — matches Pulse. Discover opens as its
        // own sheet instead of an inline row here.
        Row(
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .glassSurface(shape = RoundedCornerShape(50), weight = GlassWeight.Light)
                .pressScale(pressedScale = 0.96f, onTap = onOpenDiscover)
                .padding(horizontal = 22.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.GridView, contentDescription = null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "Discover", style = AppTypography.body, color = Color.White.copy(alpha = 0.85f))
        }
    }
}

/**
 * The actual "movie advertising platform" browse row: a horizontal shelf
 * of poster cards (2:3, the real movie-poster aspect ratio — not the
 * square album-tile shape Pulse uses) with real video-frame artwork,
 * title + runtime burned into a bottom gradient scrim like a streaming
 * app's row, and a lit border on whichever card is currently playing.
 * Horizontal, not a vertical grid, because Flux is landscape-locked —
 * a shelf reads naturally in the available width where a multi-column
 * grid would fight the aspect ratio.
 */
@Composable
private fun MovieRow(
    title: String,
    items: List<PlayableItem>,
    nowPlayingId: String?,
    onSelectItem: (PlayableItem) -> Unit,
) {
    Column {
        Text(
            text = title,
            style = AppTypography.headline,
            color = Color.White,
            modifier = Modifier.padding(bottom = 14.dp),
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(items, key = { it.id }) { item ->
                PosterCard(
                    item = item,
                    isNowPlaying = item.id == nowPlayingId,
                    onClick = { onSelectItem(item) },
                )
            }
        }
    }
}

@Composable
private fun PosterCard(item: PlayableItem, isNowPlaying: Boolean, onClick: () -> Unit) {
    // §12 "materialize, don't just fade" — same entrance treatment as
    // DiscoverSheetContent's grid cards, kept consistent across the app.
    val reduceMotion = rememberReducedMotionPreference()
    val entrance = remember { Animatable(if (reduceMotion) 1f else 0.92f) }
    val alpha = remember { Animatable(if (reduceMotion) 1f else 0f) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(item.id) {
        scope.launch { entrance.animateTo(1f, appleSpring(damping = 1f, response = 0.35f)) }
        scope.launch { alpha.animateTo(1f, appleSpring(damping = 1f, response = 0.25f)) }
    }

    Box(
        modifier = Modifier
            .graphicsLayer { scaleX = entrance.value; scaleY = entrance.value; this.alpha = alpha.value }
            .width(148.dp)
            .aspectRatio(2f / 3f)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF17171C))
            .pressScale(pressedScale = 0.96f, onTap = onClick)
            .then(
                if (isNowPlaying) {
                    Modifier.border(1.5.dp, Color.White.copy(alpha = 0.7f), RoundedCornerShape(14.dp))
                } else Modifier,
            ),
    ) {
        if (item.artworkUri != null) {
            AsyncImage(
                model = item.artworkUri,
                contentDescription = "${item.title} poster",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Icon(
                imageVector = Icons.Filled.Movie,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.15f),
                modifier = Modifier.size(40.dp).align(Alignment.Center),
            )
        }

        // Bottom scrim so title/runtime stay legible over any still frame.
        // Brush.verticalGradient's startY/endY are absolute pixels, not
        // fractions — leaving them at the defaults (0 to full height) and
        // weighting the stops instead is the correct way to bias the
        // gradient toward the bottom of the card.
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0.5f to Color.Transparent,
                        1f to Color.Black.copy(alpha = 0.9f),
                    ),
                ),
        )

        if (isNowPlaying) {
            Icon(
                imageVector = Icons.Filled.PlayCircleFilled,
                contentDescription = "Now playing",
                tint = Color.White,
                modifier = Modifier.align(Alignment.Center).size(36.dp),
            )
        }

        Column(modifier = Modifier.align(Alignment.BottomStart).padding(10.dp)) {
            Text(
                text = item.title,
                style = AppTypography.body.copy(fontSize = 13.sp),
                color = Color.White,
                maxLines = 2,
            )
            Text(
                text = formatDuration(item.durationMs),
                style = AppTypography.dataMono.copy(fontSize = 11.sp),
                color = Color.White.copy(alpha = 0.6f),
                modifier = Modifier.padding(top = 2.dp),
            )
        }
    }
}

/** No-chrome, edge-to-edge playback surface with system bars hidden. */
@Composable
private fun FullscreenPlayer(playbackController: PlaybackController, onExit: () -> Unit) {
    HideSystemBarsWhileVisible()

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                PlayerView(context).apply {
                    useController = false
                    player = playbackController.exoPlayerInstance()
                }
            },
            update = { view -> view.player = playbackController.exoPlayerInstance() },
        )

        Box(
            modifier = Modifier
                .padding(20.dp)
                .size(44.dp)
                .glassSurface(shape = CircleShape, weight = GlassWeight.Heavy)
                .pressScale(pressedScale = 0.9f, onTap = onExit),
            contentAlignment = Alignment.TopStart,
        ) {
            Icon(
                imageVector = Icons.Filled.FullscreenExit,
                contentDescription = "Exit fullscreen",
                tint = Color.White,
                modifier = Modifier.padding(10.dp),
            )
        }
    }
}

@Composable
private fun PreviewPane(
    nowPlaying: PlayableItem?,
    playbackController: PlaybackController,
    onTap: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier.clickable(enabled = nowPlaying != null, onClick = onTap),
        contentAlignment = Alignment.Center,
    ) {
        if (nowPlaying != null) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { context ->
                    PlayerView(context).apply {
                        useController = false
                        player = playbackController.exoPlayerInstance()
                    }
                },
                update = { view -> view.player = playbackController.exoPlayerInstance() },
            )
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Filled.Videocam,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.3f),
                    modifier = Modifier.size(36.dp),
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "No Signal — Preview",
                    style = AppTypography.bodyMuted,
                    color = Color.White.copy(alpha = 0.4f),
                )
            }
        }
    }
}

/**
 * Polls real ExoPlayer position/duration on a ~250ms tick while
 * playing — mirrors PulseHomeScreen's helper. Duplicated rather than
 * shared across feature-pulse/feature-flux to avoid adding a new
 * cross-module dependency for one small composable.
 */
@Composable
private fun rememberPlaybackProgress(
    playbackController: PlaybackController,
    isPlaying: Boolean,
    nowPlayingId: String?,
): Pair<Long, Long> {
    var positionMs by remember(nowPlayingId) { mutableLongStateOf(0L) }
    var durationMs by remember(nowPlayingId) { mutableLongStateOf(0L) }

    LaunchedEffect(nowPlayingId, isPlaying) {
        if (nowPlayingId == null) return@LaunchedEffect
        while (true) {
            val player = playbackController.exoPlayerInstance()
            positionMs = player.currentPosition.coerceAtLeast(0)
            val total = player.duration
            durationMs = if (total > 0) total else 0L
            if (!isPlaying) break
            delay(250)
        }
    }

    return positionMs to durationMs
}

@Composable
private fun RoundIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    primary: Boolean = false,
) {
    val size = if (primary) 60.dp else 44.dp
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(if (primary) Color.White else Color.White.copy(alpha = 0.08f))
            .pressScale(onTap = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (primary) Color.Black else Color.White,
            modifier = Modifier.size(if (primary) 26.dp else 22.dp),
        )
    }
}

/**
 * Locks the hosting Activity to landscape on entry, restores portrait on
 * exit.
 *
 * CRASH FIX: `setRequestedOrientation` throws
 * `IllegalStateException: Only fullscreen opaque activities can request
 * orientation` on API 26+ whenever the activity isn't in a state Android
 * considers "fullscreen" — most commonly split-screen/multi-window or
 * freeform mode, which plenty of real devices (and the emulator, if
 * resized) enter without any user action needed beyond a drag from
 * recents. This screen forced landscape unconditionally with no guard at
 * all, so opening Flux while the app happened to be in multi-window threw
 * immediately, before a single pixel of the screen drew — indistinguishable
 * from "opening Flux crashes the app." `isInMultiWindowMode` is the direct
 * check; the try/catch is a second line of defense since a few OEM skins
 * throw this in situations `isInMultiWindowMode` doesn't report.
 */
@Composable
private fun LockLandscapeWhileVisible() {
    val activity = LocalContext.current.findActivity()
    DisposableEffect(activity) {
        val previous = activity?.requestedOrientation
        if (activity?.isInMultiWindowModeCompat() == false) {
            runCatching { activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE }
        }
        onDispose {
            if (activity?.isInMultiWindowModeCompat() == false) {
                runCatching {
                    activity.requestedOrientation = previous ?: ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                }
            }
        }
    }
}

private fun Activity.isInMultiWindowModeCompat(): Boolean =
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) isInMultiWindowMode else false

/** Hides status/nav bars for true edge-to-edge playback, restores them on exit. */
@Composable
private fun HideSystemBarsWhileVisible() {
    val view = LocalView.current
    val activity = LocalContext.current.findActivity()
    DisposableEffect(view) {
        val window = activity?.window
        if (window != null) {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            val controller = WindowInsetsControllerCompat(window, view)
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose {
            if (window != null) {
                WindowCompat.setDecorFitsSystemWindows(window, true)
                WindowInsetsControllerCompat(window, view).show(WindowInsetsCompat.Type.systemBars())
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }
}

private tailrec fun android.content.Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is android.content.ContextWrapper -> baseContext.findActivity()
    else -> null
}

private fun formatDuration(durationMs: Long): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
