pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "MexinPlay"

// Phase 1: core-player. Phase 2: UI foundation + themed screens.
// Phase 3: :app — real navigable application tying Pulse/Flux together.
include(":core-player")
include(":core-ui-glass")
include(":feature-pulse")
include(":feature-flux")
include(":app")
