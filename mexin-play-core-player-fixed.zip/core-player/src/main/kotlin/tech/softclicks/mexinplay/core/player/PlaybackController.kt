package tech.softclicks.mexinplay.core.player

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import tech.softclicks.mexinplay.core.player.history.PlayEventEntity
import tech.softclicks.mexinplay.core.player.history.PlayHistoryDao
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import java.util.Calendar

/**
 * Single ExoPlayer instance shared by both Pulse (audio) and Flux (video)
 * screens — one engine, two themed UIs on top, per the earlier decision
 * not to fork playback per content type. feature-pulse/feature-flux
 * should depend on this class, never on androidx.media3 directly.
 */
class PlaybackController(
    context: Context,
    private val historyDao: PlayHistoryDao,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main),
) {
    private val exoPlayer: ExoPlayer = ExoPlayer.Builder(context).build()

    private var currentItem: PlayableItem? = null
    private var currentItemStartedAtEpochMs: Long = 0L

    init {
        exoPlayer.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    recordCurrentItem(wasSkipped = false)
                }
            }
        })
    }

    fun play(item: PlayableItem) {
        // A new item starting counts the previous one as skipped unless
        // it had already reached STATE_ENDED (handled above).
        currentItem?.let { recordCurrentItem(wasSkipped = true) }

        val mediaItem = MediaItem.Builder()
            .setUri(item.uri)
            .setMediaId(item.id)
            .build()

        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.play()

        currentItem = item
        currentItemStartedAtEpochMs = System.currentTimeMillis()
    }

    fun pause() = exoPlayer.pause()

    fun resume() = exoPlayer.play()

    /** Absolute seek in milliseconds — used by the draggable/tappable progress tracks. */
    fun seekTo(positionMs: Long) = exoPlayer.seekTo(positionMs.coerceAtLeast(0))

    fun stop() {
        currentItem?.let { recordCurrentItem(wasSkipped = true) }
        exoPlayer.stop()
        currentItem = null
    }

    fun release() {
        currentItem?.let { recordCurrentItem(wasSkipped = true) }
        exoPlayer.release()
    }

    /** Exposed for UI layers that need raw transport controls beyond play/pause. */
    fun exoPlayerInstance(): ExoPlayer = exoPlayer

    private fun recordCurrentItem(wasSkipped: Boolean) {
        val item = currentItem ?: return
        val playedMs = (System.currentTimeMillis() - currentItemStartedAtEpochMs)
            .coerceAtLeast(0)
        val calendar = Calendar.getInstance()

        scope.launch {
            historyDao.record(
                PlayEventEntity(
                    mediaId = item.id,
                    startedAtEpochMs = currentItemStartedAtEpochMs,
                    hourOfDay = calendar.get(Calendar.HOUR_OF_DAY),
                    dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK),
                    playedMs = playedMs,
                    durationMs = item.durationMs,
                    wasSkipped = wasSkipped,
                )
            )
        }
    }
}
