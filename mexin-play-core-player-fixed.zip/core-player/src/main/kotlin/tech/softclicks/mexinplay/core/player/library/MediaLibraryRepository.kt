package tech.softclicks.mexinplay.core.player.library

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import tech.softclicks.mexinplay.core.player.model.MediaType
import tech.softclicks.mexinplay.core.player.model.PlayableItem

/**
 * Real device media, replacing the hardcoded Discover placeholders.
 * Callers must only invoke these after READ_MEDIA_AUDIO/READ_MEDIA_VIDEO
 * (or the legacy READ_EXTERNAL_STORAGE) permission is actually granted —
 * this class doesn't check permissions itself, the caller owns that.
 */
class MediaLibraryRepository(private val context: Context) {

    suspend fun loadPulseLibrary(): List<PlayableItem> = withContext(Dispatchers.IO) { queryAudio() }

    suspend fun loadFluxLibrary(): List<PlayableItem> = withContext(Dispatchers.IO) { queryVideo() }

    private fun queryAudio(): List<PlayableItem> {
        val items = mutableListOf<PlayableItem>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION,
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"

        context.contentResolver.query(
            collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} ASC",
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                items += PlayableItem(
                    id = id.toString(),
                    uri = ContentUris.withAppendedId(collection, id).toString(),
                    title = cursor.getString(titleCol) ?: "Untitled",
                    artistOrChannel = cursor.getString(artistCol),
                    durationMs = cursor.getLong(durationCol),
                    type = MediaType.PULSE,
                )
            }
        }
        return items
    }

    private fun queryVideo(): List<PlayableItem> {
        val items = mutableListOf<PlayableItem>()
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME, // folder name — stand-in for "channel"
            MediaStore.Video.Media.DURATION,
        )

        context.contentResolver.query(
            collection, projection, null, null, "${MediaStore.Video.Media.TITLE} ASC",
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
            val folderCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val contentUri = ContentUris.withAppendedId(collection, id).toString()
                items += PlayableItem(
                    id = id.toString(),
                    uri = contentUri,
                    title = cursor.getString(titleCol) ?: "Untitled",
                    artistOrChannel = cursor.getString(folderCol),
                    durationMs = cursor.getLong(durationCol),
                    type = MediaType.FLUX,
                    // Videos have no separate thumbnail asset — point
                    // artworkUri at the video itself. coil-video's
                    // VideoFrameDecoder (registered app-wide in
                    // MexinPlayApplication) decodes a real frame from it.
                    // Before this, artworkUri was always null and every
                    // Flux grid card rendered as a blank tile.
                    artworkUri = contentUri,
                )
            }
        }
        return items
    }
}
