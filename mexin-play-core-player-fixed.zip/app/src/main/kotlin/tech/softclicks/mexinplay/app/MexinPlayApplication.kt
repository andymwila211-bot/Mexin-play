package tech.softclicks.mexinplay.app

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import tech.softclicks.mexinplay.core.player.PlaybackController
import tech.softclicks.mexinplay.core.player.history.PlayHistoryDatabase
import tech.softclicks.mexinplay.core.player.playlist.PlaylistDatabase
import tech.softclicks.mexinplay.core.player.playlist.PlaylistRepository

/**
 * Owns the one PlaybackController, PlayHistoryDatabase, and
 * PlaylistDatabase instance for the whole app. Pulse and Flux screens
 * both read from this — see PlaybackController's own doc comment for
 * why there's only one engine instance instead of one per section.
 *
 * Also supplies the app-wide Coil [ImageLoader]: [VideoFrameDecoder] (from
 * the open-source `coil-video` extension) is registered here so any
 * `AsyncImage` fed a video's own content Uri decodes a real frame instead
 * of rendering nothing — see [tech.softclicks.mexinplay.core.player.library.MediaLibraryRepository]
 * where a Flux item's `artworkUri` is set to its own video Uri.
 */
class MexinPlayApplication : Application(), ImageLoaderFactory {

    lateinit var playbackController: PlaybackController
        private set

    lateinit var playlistRepository: PlaylistRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val historyDao = PlayHistoryDatabase.getInstance(this).playHistoryDao()
        playbackController = PlaybackController(
            context = this,
            historyDao = historyDao,
        )
        playlistRepository = PlaylistRepository(PlaylistDatabase.getInstance(this).playlistDao())
    }

    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .components { add(VideoFrameDecoder.Factory()) }
        .build()
}
