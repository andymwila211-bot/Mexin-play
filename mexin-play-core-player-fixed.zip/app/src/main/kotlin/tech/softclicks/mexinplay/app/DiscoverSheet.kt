package tech.softclicks.mexinplay.app

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloseFullscreen
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.GlassWeight
import tech.softclicks.mexinplay.core.ui.glass.appleSpring
import tech.softclicks.mexinplay.core.ui.glass.glassSurface
import tech.softclicks.mexinplay.core.ui.glass.pressScale
import tech.softclicks.mexinplay.core.ui.glass.rememberReducedMotionPreference

/**
 * Content for Discover's ModalBottomSheet (see MexinNavHost) — a real
 * sub-screen reached via a button, not an inline list on the player
 * screen. Starts at partial height; [isExpanded] plus [onToggleExpand]
 * give an explicit control to go full-screen rather than relying on
 * drag alone, since drag-to-expand isn't discoverable on its own.
 *
 * Redesign pass (apple-design skill): the expand toggle is a real glass
 * chip (§12) with press feedback (§1/§13) instead of a flat circle +
 * bare `clickable`; the header text now uses the shared typography
 * roles (§15) instead of a raw `fontSize`; and each grid card
 * materializes in with a scale+fade on first composition (§12 —
 * "materialize, don't just fade") rather than popping in instantly when
 * the column count changes between 2 and 3.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DiscoverSheetContent(
    items: List<PlayableItem>,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onSelectItem: (PlayableItem) -> Unit,
    onLongPressItem: (PlayableItem) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(text = "Discover", style = AppTypography.headline, color = Color.White)
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .glassSurface(shape = CircleShape, weight = GlassWeight.Light)
                    .pressScale(onTap = onToggleExpand),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = if (isExpanded) Icons.Filled.CloseFullscreen else Icons.Filled.OpenInFull,
                    contentDescription = if (isExpanded) "Collapse" else "Expand to full screen",
                    tint = Color.White.copy(alpha = 0.8f),
                    modifier = Modifier.size(16.dp),
                )
            }
        }

        if (items.isEmpty()) {
            Text(text = "Nothing here yet.", style = AppTypography.bodyMuted, color = Color.White.copy(alpha = 0.5f))
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(if (isExpanded) 3 else 2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                items(items, key = { it.id }) { item ->
                    DiscoverGridCard(
                        item = item,
                        onClick = { onSelectItem(item) },
                        onLongClick = { onLongPressItem(item) },
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DiscoverGridCard(item: PlayableItem, onClick: () -> Unit, onLongClick: () -> Unit) {
    // §12 "materialize, don't just fade" — scale up from 0.92 alongside
    // the alpha fade so the card reads as arriving, not just appearing.
    val reduceMotion = rememberReducedMotionPreference()
    val entrance = remember { Animatable(if (reduceMotion) 1f else 0.92f) }
    val alpha = remember { Animatable(if (reduceMotion) 1f else 0f) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(item.id) {
        scope.launch { entrance.animateTo(1f, appleSpring(damping = 1f, response = 0.35f)) }
        scope.launch { alpha.animateTo(1f, appleSpring(damping = 1f, response = 0.25f)) }
    }

    Column(
        modifier = Modifier
            .graphicsLayer {
                scaleX = entrance.value; scaleY = entrance.value
                this.alpha = alpha.value
            }
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF17171C)),
        ) {
            if (item.artworkUri != null) {
                AsyncImage(
                    model = item.artworkUri,
                    contentDescription = "${item.title} artwork",
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = item.title, style = AppTypography.body, color = Color.White, maxLines = 1)
        item.artistOrChannel?.let {
            Text(text = it, style = AppTypography.bodyMuted, color = Color.White.copy(alpha = 0.5f), maxLines = 1)
        }
    }
}
