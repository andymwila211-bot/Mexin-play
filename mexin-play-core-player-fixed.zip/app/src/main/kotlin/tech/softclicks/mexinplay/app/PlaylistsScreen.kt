package tech.softclicks.mexinplay.app

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.player.playlist.PlaylistSummary
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.GlassWeight
import tech.softclicks.mexinplay.core.ui.glass.confirm
import tech.softclicks.mexinplay.core.ui.glass.glassSurface
import tech.softclicks.mexinplay.core.ui.glass.pressScale
import tech.softclicks.mexinplay.core.ui.glass.swipeToDelete

/**
 * Manual playlists — separate from the Pulse/Flux Discover queues, which
 * are the smart-shuffle-ordered device library, not user-curated lists.
 * Reached via the playlist icon next to search rather than a third
 * Pulse/Flux pill segment, since that pill was copied pixel-for-pixel
 * from the reference and adding a third state there wasn't part of it.
 *
 * Redesign pass: every flat `Color(0xFF1A1A1F)` row/chip is now a real
 * glass surface (§12) with weight signaling role — Light for the
 * primary "New playlist" action so it draws the eye, Regular for rows.
 * The static trash-can icon is gone; rows now swipe left to delete
 * (§2/§6/§9 — 1:1 drag, momentum decides commit, rubber-band past the
 * threshold), which is both more direct (grab the thing you're removing,
 * not a small adjacent icon) and matches the swipe-to-delete pattern
 * people already know from Mail/Messages (§16.4 — familiarity). The
 * inline "create" row now animates open/closed (§4/§12) instead of
 * hard-swapping between two Composables.
 */
@Composable
fun PlaylistsScreen(
    playlists: List<PlaylistSummary>,
    onCreatePlaylist: (String) -> Unit,
    onDeletePlaylist: (Long) -> Unit,
    onOpenPlaylist: (Long) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var isCreating by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    val haptics = LocalHapticFeedback.current

    Column(modifier = modifier.fillMaxSize().padding(horizontal = 24.dp).padding(top = 24.dp, bottom = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(36.dp).glassSurface(shape = CircleShape, weight = GlassWeight.Light).pressScale(onTap = onBack),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(text = "Playlists", style = AppTypography.displayLarge.copy(fontSize = 24.sp), color = Color.White)
        }

        Spacer(modifier = Modifier.height(20.dp))

        AnimatedVisibility(
            visible = isCreating,
            enter = fadeIn(tween(150)) + expandVertically(tween(220)),
            exit = fadeOut(tween(120)) + shrinkVertically(tween(180)),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .glassSurface(shape = RoundedCornerShape(16.dp), weight = GlassWeight.Regular)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    if (newName.isEmpty()) {
                        Text("Playlist name", style = AppTypography.body, color = Color.White.copy(alpha = 0.4f))
                    }
                    BasicTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                        cursorBrush = SolidColor(Color.White),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                Text(
                    text = "Create",
                    color = Color.White,
                    style = AppTypography.body,
                    modifier = Modifier.clickable(enabled = newName.isNotBlank()) {
                        onCreatePlaylist(newName)
                        newName = ""
                        isCreating = false
                    },
                )
                Spacer(modifier = Modifier.width(12.dp))
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "Cancel",
                    tint = Color.White.copy(alpha = 0.6f),
                    modifier = Modifier.size(18.dp).clickable { isCreating = false; newName = "" },
                )
            }
        }
        AnimatedVisibility(
            visible = !isCreating,
            enter = fadeIn(tween(180)),
            exit = fadeOut(tween(100)),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .glassSurface(shape = RoundedCornerShape(16.dp), weight = GlassWeight.Light)
                    .pressScale(pressedScale = 0.985f) { isCreating = true }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text(text = "New playlist", style = AppTypography.body, color = Color.White)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (playlists.isEmpty()) {
            Text(
                text = "No playlists yet — create one above, then add tracks by long-pressing them in Discover.",
                style = AppTypography.bodyMuted,
                color = Color.White.copy(alpha = 0.5f),
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(playlists, key = { it.id }) { playlist ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .swipeToDelete(onDelete = {
                                haptics.confirm()
                                onDeletePlaylist(playlist.id)
                            }),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .glassSurface(shape = RoundedCornerShape(14.dp), weight = GlassWeight.Regular)
                                .pressScale(pressedScale = 0.99f) { onOpenPlaylist(playlist.id) }
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Filled.PlaylistPlay, contentDescription = null, tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = playlist.name, style = AppTypography.headline.copy(fontSize = 16.sp), color = Color.White)
                                Text(
                                    text = if (playlist.trackCount == 1) "1 track" else "${playlist.trackCount} tracks",
                                    style = AppTypography.dataMono,
                                    color = Color.White.copy(alpha = 0.5f),
                                )
                            }
                            Icon(
                                Icons.Filled.Delete,
                                contentDescription = "Delete playlist",
                                tint = Color.White.copy(alpha = 0.3f),
                                modifier = Modifier.size(16.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PlaylistDetailScreen(
    playlistName: String,
    tracks: List<PlayableItem>,
    onPlay: (PlayableItem) -> Unit,
    onRemove: (String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val haptics = LocalHapticFeedback.current

    Column(modifier = modifier.fillMaxSize().padding(horizontal = 24.dp).padding(top = 24.dp, bottom = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(36.dp).glassSurface(shape = CircleShape, weight = GlassWeight.Light).pressScale(onTap = onBack),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(text = playlistName, style = AppTypography.displayLarge.copy(fontSize = 24.sp), color = Color.White, maxLines = 1)
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (tracks.isEmpty()) {
            Text(
                text = "Nothing here yet — long-press a track in Discover to add it.",
                style = AppTypography.bodyMuted,
                color = Color.White.copy(alpha = 0.5f),
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tracks, key = { it.id }) { track ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .swipeToDelete(onDelete = {
                                haptics.confirm()
                                onRemove(track.id)
                            }),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .glassSurface(shape = RoundedCornerShape(12.dp), weight = GlassWeight.Regular)
                                .pressScale(pressedScale = 0.99f) { onPlay(track) }
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = track.title, style = AppTypography.body, color = Color.White, maxLines = 1)
                                track.artistOrChannel?.let {
                                    Text(text = it, style = AppTypography.bodyMuted, color = Color.White.copy(alpha = 0.5f), maxLines = 1)
                                }
                            }
                            Icon(
                                Icons.Filled.Close,
                                contentDescription = "Remove from playlist",
                                tint = Color.White.copy(alpha = 0.3f),
                                modifier = Modifier.size(16.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Minimal picker shown on long-press — pick an existing playlist or make a new one, in one step. */
/** Content only — hosted inside a real ModalBottomSheet by MexinNavHost, which supplies the scrim/dismiss/drag handling itself. */
@Composable
fun AddToPlaylistSheetContent(
    item: PlayableItem,
    playlists: List<PlaylistSummary>,
    onPickPlaylist: (Long) -> Unit,
    onCreateAndAdd: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var newName by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Text(text = "Add \"${item.title}\" to…", style = AppTypography.headline.copy(fontSize = 16.sp), color = Color.White, maxLines = 1)
        Spacer(modifier = Modifier.height(14.dp))

        playlists.forEach { playlist ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .pressScale(pressedScale = 0.99f) { onPickPlaylist(playlist.id) }
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.PlaylistPlay, contentDescription = null, tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Text(text = playlist.name, style = AppTypography.body, color = Color.White)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .glassSurface(shape = RoundedCornerShape(14.dp), weight = GlassWeight.Light)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(modifier = Modifier.weight(1f)) {
                if (newName.isEmpty()) {
                    Text("New playlist name", style = AppTypography.bodyMuted, color = Color.White.copy(alpha = 0.4f))
                }
                BasicTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Text(
                text = "Add",
                color = Color.White,
                style = AppTypography.bodyMuted,
                modifier = Modifier.clickable(enabled = newName.isNotBlank()) { onCreateAndAdd(newName) },
            )
        }
    }
}
