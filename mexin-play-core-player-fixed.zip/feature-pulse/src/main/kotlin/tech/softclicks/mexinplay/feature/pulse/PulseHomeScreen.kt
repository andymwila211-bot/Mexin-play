package tech.softclicks.mexinplay.feature.pulse

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import tech.softclicks.mexinplay.core.player.PlaybackController
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.ArtworkColors
import tech.softclicks.mexinplay.core.ui.glass.GlassWeight
import tech.softclicks.mexinplay.core.ui.glass.LiquidBackdrop
import tech.softclicks.mexinplay.core.ui.glass.Scrubber
import tech.softclicks.mexinplay.core.ui.glass.appleSpring
import tech.softclicks.mexinplay.core.ui.glass.glassSurface
import tech.softclicks.mexinplay.core.ui.glass.loadArtworkWithPalette
import tech.softclicks.mexinplay.core.ui.glass.pressScale
import tech.softclicks.mexinplay.core.ui.glass.rememberReducedMotionPreference

/**
 * The player, plus a real browse grid ("Your Library") below the
 * transport controls — this is the actual landing surface, not just a
 * single-track display. Discover remains its own sub-screen (a
 * ModalBottomSheet built in the app module) for long-press add-to-playlist
 * and the expand-to-full-grid flow; this screen's own grid is for
 * one-tap browsing without leaving the player. Scrolls again now that
 * there's more than one screenful of content once a library is loaded.
 */
@Composable
fun PulseHomeScreen(
    nowPlaying: PlayableItem?,
    isPlaying: Boolean,
    library: List<PlayableItem>,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onOpenDiscover: () -> Unit,
    onSelectItem: (PlayableItem) -> Unit,
    playbackController: PlaybackController,
    modifier: Modifier = Modifier,
) {
    val (positionMs, durationMs) = rememberPlaybackProgress(playbackController, isPlaying, nowPlaying?.id)

    val context = LocalContext.current
    var artworkBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var artworkColors by remember { mutableStateOf(ArtworkColors(Color(0xFF2A2A32), Color(0xFF1A1A1F), Color(0xFF0C0C10))) }
    LaunchedEffect(nowPlaying?.artworkUri) {
        val (bitmap, colors) = loadArtworkWithPalette(context, nowPlaying?.artworkUri)
        artworkBitmap = bitmap
        artworkColors = colors
    }

    Box(modifier = modifier.fillMaxSize()) {
        LiquidBackdrop(artworkBitmap = artworkBitmap, colors = artworkColors, modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .padding(top = 24.dp, bottom = 150.dp),
        ) {
            Text(
                text = "PULSE",
                style = AppTypography.eyebrow,
                color = Color.White.copy(alpha = 0.55f),
            )

            Spacer(modifier = Modifier.height(20.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .heightIn(max = 360.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0xFF121216)),
                contentAlignment = Alignment.Center,
            ) {
                if (nowPlaying?.artworkUri != null) {
                    AsyncImage(
                        model = nowPlaying.artworkUri,
                        contentDescription = "${nowPlaying.title} artwork",
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    Text(
                        text = "P",
                        fontSize = 170.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.Black.copy(alpha = 0.35f),
                        modifier = Modifier.offset(x = 2.dp, y = 3.dp),
                    )
                    Text(
                        text = "P",
                        fontSize = 170.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White.copy(alpha = 0.05f),
                        modifier = Modifier.offset(x = (-1).dp, y = (-1).dp),
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = nowPlaying?.title ?: "Nothing playing",
                style = AppTypography.displayLarge.copy(fontSize = 26.sp),
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = nowPlaying?.artistOrChannel ?: "Open Discover to pick something",
                style = AppTypography.body,
                color = Color.White.copy(alpha = 0.5f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(modifier = Modifier.height(24.dp))

            Scrubber(
                elapsedLabel = formatDuration(positionMs),
                totalLabel = if (durationMs > 0) "-" + formatDuration((durationMs - positionMs).coerceAtLeast(0)) else "--:--",
                progress = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f,
                enabled = nowPlaying != null && durationMs > 0,
                onSeek = { fraction -> playbackController.seekTo((fraction * durationMs).toLong()) },
            )

            Spacer(modifier = Modifier.height(28.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RoundTransportButton(icon = Icons.Filled.FastRewind, contentDescription = "Previous", onClick = onPrevious)
                Spacer(modifier = Modifier.width(24.dp))
                RoundTransportButton(
                    icon = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    onClick = onPlayPause,
                    primary = true,
                )
                Spacer(modifier = Modifier.width(24.dp))
                RoundTransportButton(icon = Icons.Filled.FastForward, contentDescription = "Next", onClick = onNext)
            }

            Spacer(modifier = Modifier.height(36.dp))

            if (library.isNotEmpty()) {
                AlbumGrid(
                    title = "Your Library",
                    items = library,
                    nowPlayingId = nowPlaying?.id,
                    isPlaying = isPlaying,
                    onSelectItem = onSelectItem,
                )
                Spacer(modifier = Modifier.height(28.dp))
            }

            // Sub-screen entry point, not an inline list — tapping opens
            // Discover as its own half-height sheet (see MexinNavHost).
            Row(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .glassSurface(shape = RoundedCornerShape(50), weight = GlassWeight.Light)
                    .pressScale(pressedScale = 0.96f, onTap = onOpenDiscover)
                    .padding(horizontal = 22.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.GridView, contentDescription = null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Discover", style = AppTypography.body, color = Color.White.copy(alpha = 0.85f))
            }
        }
    }
}

/**
 * The "audio platform" browse grid: a 2-column shelf of square album
 * tiles (real artwork via AsyncImage, matching the format an audio
 * library app is expected to use — square, not the 2:3 poster shape
 * Flux uses for movies). This is the actual landing content the request
 * asked for; before this, Pulse had no way to browse past the single
 * now-playing track without opening the separate Discover sheet.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AlbumGrid(
    title: String,
    items: List<PlayableItem>,
    nowPlayingId: String?,
    isPlaying: Boolean,
    onSelectItem: (PlayableItem) -> Unit,
) {
    Column {
        Text(
            text = title,
            style = AppTypography.headline,
            color = Color.White,
            modifier = Modifier.padding(bottom = 14.dp),
        )
        // FlowRow, not LazyVerticalGrid: this section lives inside the
        // screen's own verticalScroll Column, and a lazy grid nested in a
        // scrollable parent throws "vertically scrollable component was
        // measured with an infinity maximum height" — a real crash this
        // rewrite is careful not to introduce. FlowRow just wraps content
        // to new lines, no independent scroll, so it composes safely here.
        FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items.forEach { item ->
                AlbumTile(
                    item = item,
                    isNowPlaying = item.id == nowPlayingId,
                    isPlaying = isPlaying,
                    onClick = { onSelectItem(item) },
                    modifier = Modifier.width(108.dp),
                )
            }
        }
    }
}

@Composable
private fun AlbumTile(
    item: PlayableItem,
    isNowPlaying: Boolean,
    isPlaying: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val reduceMotion = rememberReducedMotionPreference()
    val entrance = remember { Animatable(if (reduceMotion) 1f else 0.92f) }
    val alpha = remember { Animatable(if (reduceMotion) 1f else 0f) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(item.id) {
        scope.launch { entrance.animateTo(1f, appleSpring(damping = 1f, response = 0.35f)) }
        scope.launch { alpha.animateTo(1f, appleSpring(damping = 1f, response = 0.25f)) }
    }

    Column(
        modifier = modifier
            .graphicsLayer { scaleX = entrance.value; scaleY = entrance.value; this.alpha = alpha.value }
            .pressScale(pressedScale = 0.96f, onTap = onClick)
            .padding(bottom = 6.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF17171C))
                .then(
                    if (isNowPlaying) {
                        Modifier.border(1.5.dp, Color.White.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
                    } else Modifier,
                ),
        ) {
            if (item.artworkUri != null) {
                AsyncImage(
                    model = item.artworkUri,
                    contentDescription = "${item.title} artwork",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Icon(
                    imageVector = Icons.Filled.MusicNote,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.2f),
                    modifier = Modifier.size(28.dp).align(Alignment.Center),
                )
            }
            if (isNowPlaying) {
                Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)))
                Icon(
                    imageVector = if (isPlaying) Icons.Filled.Equalizer else Icons.Filled.PlayArrow,
                    contentDescription = if (isPlaying) "Playing" else "Paused",
                    tint = Color.White,
                    modifier = Modifier.align(Alignment.Center).size(22.dp),
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = item.title, style = AppTypography.bodyMuted, color = Color.White, maxLines = 1)
        item.artistOrChannel?.let {
            Text(text = it, style = AppTypography.dataMono.copy(fontSize = 10.sp), color = Color.White.copy(alpha = 0.5f), maxLines = 1)
        }
    }
}

/**
 * Polls the real ExoPlayer position/duration on a ~250ms tick while
 * playing. ExoPlayer doesn't push continuous position updates, so this
 * is the standard Compose pattern rather than a bug workaround. Resets
 * to 0 whenever the now-playing id changes so a new track doesn't show
 * the previous one's stale position for a frame.
 */
@Composable
private fun rememberPlaybackProgress(
    playbackController: PlaybackController,
    isPlaying: Boolean,
    nowPlayingId: String?,
): Pair<Long, Long> {
    var positionMs by remember(nowPlayingId) { mutableLongStateOf(0L) }
    var durationMs by remember(nowPlayingId) { mutableLongStateOf(0L) }

    LaunchedEffect(nowPlayingId, isPlaying) {
        if (nowPlayingId == null) return@LaunchedEffect
        while (true) {
            val player = playbackController.exoPlayerInstance()
            positionMs = player.currentPosition.coerceAtLeast(0)
            val total = player.duration
            durationMs = if (total > 0) total else 0L
            if (!isPlaying) break
            delay(250)
        }
    }

    return positionMs to durationMs
}

@Composable
private fun RoundTransportButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    primary: Boolean = false,
) {
    val size = if (primary) 76.dp else 60.dp
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(if (primary) Color.White else Color.White.copy(alpha = 0.08f))
            .pressScale(onTap = onClick), // §1/§3: instant scale feedback on pointer-down, not just a ripple on release
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (primary) Color.Black else Color.White,
            modifier = Modifier.size(if (primary) 30.dp else 22.dp),
        )
    }
}

internal fun formatDuration(durationMs: Long): String {
    val totalSeconds = durationMs / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
