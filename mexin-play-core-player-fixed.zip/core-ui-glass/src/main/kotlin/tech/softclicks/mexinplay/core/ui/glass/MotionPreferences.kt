package tech.softclicks.mexinplay.core.ui.glass

import android.provider.Settings
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext

/**
 * §14 — `prefers-reduced-motion` equivalent. Android's real signal is
 * the system "Remove animations" developer/accessibility toggle, which
 * zeroes ANIMATOR_DURATION_SCALE. Reading it means spring-driven UI
 * (cover flow, scrubber thumb, swipe-to-delete) automatically drops to
 * a short opacity cross-fade instead of the physical motion — never
 * *no* feedback, per the skill, just a gentler equivalent.
 */
@Composable
fun rememberReducedMotionPreference(): Boolean {
    val context = LocalContext.current
    return remember(context) {
        runCatching {
            Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
        }.getOrDefault(false)
    }
}

/** Short opacity cross-fade used in place of a spring when reduced motion is on — no elastic/overshoot, per §14. */
fun reducedMotionTween() = tween<Float>(durationMillis = 200)
