package tech.softclicks.mexinplay.core.ui.glass

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.isActive
import androidx.compose.runtime.withFrameNanos

/**
 * Animated artwork background for the now-playing screen — the "premium"
 * effect. This is a real port of Apple Music's actual mechanism, not a
 * guess: per a public reverse-engineering of Apple Music's Mac/web build
 * (github.com/aadishv/html-music, aadishv.dev/music, Nov 2025 — process
 * was Xcode-attach + decompiling the web bundle, not black-box), the
 * background is NOT color-extraction-and-gradient. It's several rotated,
 * animated copies of the album artwork run through a per-pixel "twist"
 * distortion, blurred, and drawn oversaturated. The twist math below is
 * a direct port of the GLSL that writeup extracted:
 *
 *   coord -= offset
 *   dist = length(coord)
 *   if dist < radius:
 *     angleMod = ((radius-dist)/radius)^2 * angle
 *     coord = rotate(coord, angleMod)
 *   coord += offset
 *
 * On API 33+ this runs as a real AGSL RuntimeShader (Android's on-GPU
 * shader language) sampling the artwork bitmap directly — three layered,
 * independently-animated copies, matching the source material's "some
 * layers spin in place, some also drift" structure, composited with a
 * RenderEffect blur and a saturation boost. Below API 33 (AGSL's floor)
 * there's no shader path available at all, so it falls back to a slow,
 * animated 3-stop gradient built from real Palette-extracted swatches
 * (see ArtworkPalette.kt) — not the twist effect, but still driven by
 * the actual artwork's real colors rather than a static placeholder.
 */
private const val TWIST_SHADER = """
uniform shader inputShader;
uniform float2 uOffset;
uniform float uAngle;
uniform float uRadius;

half4 main(float2 fragCoord) {
    float2 coord = fragCoord - uOffset;
    float dist = length(coord);
    if (dist < uRadius) {
        float ratioDist = (uRadius - dist) / uRadius;
        float angleMod = ratioDist * ratioDist * uAngle;
        float s = sin(angleMod);
        float c = cos(angleMod);
        coord = float2(coord.x * c - coord.y * s, coord.x * s + coord.y * c);
    }
    coord += uOffset;
    return inputShader.eval(coord);
}
"""

private data class TwistLayer(
    val scale: Float,
    val alpha: Float,
    val orbitRadiusFraction: Float, // 0 = spins in place only, >0 = also drifts on a circular track
    val speed: Float,               // radians/sec for both spin and orbit
    val twistAngleDeg: Float,
    val twistRadiusFraction: Float,
)

// Mirrors the source material's structure: two small layers that spin AND
// orbit, two large layers that only spin in place.
private val LAYERS = listOf(
    TwistLayer(scale = 0.5f, alpha = 0.55f, orbitRadiusFraction = 0.18f, speed = 0.25f, twistAngleDeg = 140f, twistRadiusFraction = 0.6f),
    TwistLayer(scale = 0.8f, alpha = 0.45f, orbitRadiusFraction = 0.10f, speed = 0.17f, twistAngleDeg = 100f, twistRadiusFraction = 0.7f),
    TwistLayer(scale = 1.25f, alpha = 0.5f, orbitRadiusFraction = 0f, speed = 0.09f, twistAngleDeg = 70f, twistRadiusFraction = 0.8f),
)

private fun oversaturatedColorFilter(): ColorMatrixColorFilter {
    val matrix = ColorMatrix().apply { setSaturation(1.8f) } // "deliberately oversaturated" per the source writeup
    return ColorMatrixColorFilter(matrix)
}

@Composable
fun LiquidBackdrop(
    artworkBitmap: Bitmap?,
    colors: ArtworkColors,
    modifier: Modifier = Modifier,
) {
    val shaderCapable = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU // AGSL RuntimeShader floor
    if (shaderCapable && artworkBitmap != null) {
        AnimatedTwistBackdrop(artworkBitmap = artworkBitmap, modifier = modifier)
    } else {
        AnimatedGradientFallback(colors = colors, modifier = modifier)
    }
}

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
@Composable
private fun AnimatedTwistBackdrop(artworkBitmap: Bitmap, modifier: Modifier = Modifier) {
    var timeSeconds by remember { mutableFloatStateOf(0f) }
    LaunchedFrameClock { deltaSeconds -> timeSeconds += deltaSeconds }

    val bitmapShader = remember(artworkBitmap) {
        BitmapShader(artworkBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
    }
    val colorFilter = remember { oversaturatedColorFilter() }
    val blurEffect = remember {
        RenderEffect.createBlurEffect(60f, 60f, Shader.TileMode.CLAMP).asComposeRenderEffect()
    }

    Box(modifier = modifier.fillMaxSize()) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { renderEffect = blurEffect },
        ) {
            val w = size.width
            val h = size.height
            val cx = w / 2f
            val cy = h / 2f
            drawIntoCanvas { canvas ->
                val paint = android.graphics.Paint().apply {
                    isAntiAlias = true
                    isFilterBitmap = true
                }
                LAYERS.forEach { layer ->
                    val orbitR = layer.orbitRadiusFraction * w
                    val centerX = cx + cos(timeSeconds * layer.speed) * orbitR
                    val centerY = cy + sin(timeSeconds * layer.speed) * orbitR
                    val spinAngle = timeSeconds * layer.speed * 40f // deg, independent visual spin

                    val runtimeShader = RuntimeShader(TWIST_SHADER)
                    runtimeShader.setInputShader("inputShader", bitmapShader)
                    runtimeShader.setFloatUniform("uOffset", centerX, centerY)
                    runtimeShader.setFloatUniform("uAngle", Math.toRadians(layer.twistAngleDeg.toDouble()).toFloat())
                    runtimeShader.setFloatUniform("uRadius", layer.twistRadiusFraction * w)

                    paint.shader = runtimeShader
                    paint.alpha = (layer.alpha * 255).toInt()
                    paint.colorFilter = colorFilter

                    val side = layer.scale * w
                    canvas.nativeCanvas.save()
                    canvas.nativeCanvas.rotate(spinAngle, centerX, centerY)
                    canvas.nativeCanvas.drawRect(
                        centerX - side / 2f, centerY - side / 2f,
                        centerX + side / 2f, centerY + side / 2f,
                        paint,
                    )
                    canvas.nativeCanvas.restore()
                }
            }
        }
        // Dark scrim on top keeps foreground text legible over a busy, bright,
        // oversaturated backdrop — the reference material does this too.
        Box(modifier = Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.45f)))
    }
}

/** Runs [onFrame] every animation frame with the elapsed seconds since the last frame. */
@Composable
private fun LaunchedFrameClock(onFrame: (deltaSeconds: Float) -> Unit) {
    androidx.compose.runtime.LaunchedEffect(Unit) {
        var lastNanos = -1L
        while (isActive) {
            withFrameNanos { nowNanos ->
                if (lastNanos >= 0) {
                    onFrame((nowNanos - lastNanos) / 1_000_000_000f)
                }
                lastNanos = nowNanos
            }
        }
    }
}

/**
 * Pre-API-33 / no-artwork fallback: a slow, animated gradient built from
 * real Palette swatches, not the twist effect (AGSL isn't available), and
 * not a static color either — the center of the gradient drifts slowly so
 * it doesn't read as a dead, flat fill.
 */
@Composable
private fun AnimatedGradientFallback(colors: ArtworkColors, modifier: Modifier = Modifier) {
    var timeSeconds by remember { mutableFloatStateOf(0f) }
    LaunchedFrameClock { deltaSeconds -> timeSeconds += deltaSeconds }

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val driftX = (sin(timeSeconds * 0.15f) * 0.5f + 0.5f) * w
        val driftY = (cos(timeSeconds * 0.12f) * 0.5f + 0.5f) * h
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(colors.vibrant, colors.muted, colors.darkVibrant),
                center = Offset(driftX, driftY),
                radius = (w.coerceAtLeast(h)) * 0.9f,
            ),
        )
    }
}
