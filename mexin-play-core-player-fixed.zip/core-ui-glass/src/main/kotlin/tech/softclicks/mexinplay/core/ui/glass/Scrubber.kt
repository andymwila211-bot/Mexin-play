package tech.softclicks.mexinplay.core.ui.glass

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.horizontalDrag
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/**
 * A real scrubber, not a tap-only progress bar: 1:1 finger tracking
 * while dragging (§2), a thumb that only appears once you've grabbed
 * it (§8 — hints where you are before you commit), a light haptic tick
 * on grab and on release (§13 — causality: the moment the gesture
 * actually starts/ends, not before or after), and a critically-damped
 * spring that snaps the visual position to the real playback position
 * on release rather than jumping (§4). Shared by Pulse and Flux instead
 * of each screen keeping its own tap-only copy.
 */
@Composable
fun Scrubber(
    elapsedLabel: String,
    totalLabel: String,
    progress: Float,
    enabled: Boolean,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    var trackWidthPx by remember { mutableFloatStateOf(0f) }
    var isDragging by remember { mutableStateOf(false) }
    val dragFraction = remember { Animatable(progress) }
    val thumbScale = remember { Animatable(0f) }
    val haptics = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    // Follow the real playback position only while not actively grabbed —
    // grabbing must win over the ongoing position poll, or the thumb
    // fights the finger every 250ms tick (§2: touch and content move together).
    androidx.compose.runtime.LaunchedEffect(progress, isDragging) {
        if (!isDragging) dragFraction.snapTo(progress)
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(28.dp)
                .onSizeChanged { trackWidthPx = it.width.toFloat() }
                .pointerInput(enabled, trackWidthPx) {
                    if (!enabled || trackWidthPx <= 0f) return@pointerInput
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        isDragging = true
                        haptics.tap()
                        scope.launch { thumbScale.animateTo(1f, appleSpring(damping = 0.85f, response = 0.25f)) }
                        var lastFraction = (down.position.x / trackWidthPx).coerceIn(0f, 1f)
                        scope.launch { dragFraction.snapTo(lastFraction) }

                        horizontalDrag(down.id) { change ->
                            lastFraction = (change.position.x / trackWidthPx).coerceIn(0f, 1f)
                            scope.launch { dragFraction.snapTo(lastFraction) }
                        }

                        isDragging = false
                        haptics.snap()
                        onSeek(lastFraction)
                        // A tap is just a zero-distance drag — the same commit path
                        // above already handles it, so no separate tap detector is
                        // needed (and stacking one would double-fire onSeek).
                        scope.launch { thumbScale.animateTo(0f, appleSpring(damping = 1f, response = 0.3f)) }
                    }
                },
            contentAlignment = Alignment.CenterStart,
        ) {
            val fraction = dragFraction.value.coerceIn(0f, 1f)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.18f)),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(fraction.coerceAtLeast(0.008f))
                        .height(3.dp)
                        .background(Color.White),
                )
            }
            if (trackWidthPx > 0f) {
                Box(
                    modifier = Modifier
                        .padding(start = with(androidx.compose.ui.platform.LocalDensity.current) { (fraction * trackWidthPx).toDp() - 7.dp })
                        .size(14.dp)
                        .graphicsLayer { scaleX = thumbScale.value; scaleY = thumbScale.value }
                        .clip(CircleShape)
                        .background(Color.White),
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(text = elapsedLabel, style = AppTypography.dataMono, color = Color.White.copy(alpha = 0.55f))
            Text(text = totalLabel, style = AppTypography.dataMono, color = Color.White.copy(alpha = 0.55f))
        }
    }
}
