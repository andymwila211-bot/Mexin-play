package tech.softclicks.mexinplay.core.ui.glass

import androidx.compose.ui.graphics.Color

/**
 * Reference redesign: near-black, flat panels, no colored glow. Pulse
 * and Flux stay visually distinct only through accent color and layout
 * shape (square card vs. widescreen player), not through a shared
 * radial-glow backdrop — that glow was the "cheap" element being cut.
 */
object PulseColors {
    val background = Color(0xFF0A0A0D)
    val accent = Color(0xFFFFFFFF)
    val accentMuted = Color(0xFF8A8A93)
    val onBackground = Color(0xFFF5F5F7)
    val onBackgroundMuted = Color(0xFF9A9AA2)
}

object FluxColors {
    val background = Color(0xFF07090C)
    val accent = Color(0xFFFFFFFF)
    val accentMuted = Color(0xFF8A94A0)
    val onBackground = Color(0xFFF0F4F8)
    val onBackgroundMuted = Color(0xFF9AA4B0)
}

/** Flat shell backdrop shared by both sections — no glow, no gradient sweep. */
object ShellColors {
    val base = Color(0xFF060608)
}
