package tech.softclicks.mexinplay.core.ui.glass

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.horizontalDrag
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.platform.LocalHapticFeedback
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min

/**
 * Direct implementation of the motion rules from the "apple-design"
 * skill — not a vague "make it feel nicer" pass. Every function here
 * maps to a specific numbered section of that document, so the mapping
 * from rule to code stays traceable instead of the physics getting
 * reinvented ad hoc per screen.
 */

/**
 * §4 — Apple's damping/response spring parameters, converted to Compose's
 * dampingRatio/stiffness. The conversion is a real physics identity, not
 * an approximation: for a unit-mass spring, dampingRatio is the same
 * unitless ζ in both APIs (Compose's `dampingRatio` param IS Apple's
 * "damping"), and stiffness derives from the desired settle time via
 * ω = 2π/response, stiffness = ω². This is the same identity SwiftUI's
 * own response/dampingFraction spring uses under the hood.
 *
 * Defaults (1.0, 0.4) match the skill's "Move / reposition" row — start
 * everything here unless a gesture actually carried momentum (§4: "Add
 * bounce only when the gesture itself carried momentum").
 */
fun <T> appleSpring(damping: Float = 1f, response: Float = 0.4f): SpringSpec<T> {
    val omega = (2f * PI.toFloat()) / response
    return spring(dampingRatio = damping, stiffness = omega * omega)
}

/** §4 — the momentum-driven variant: use only after a flick/drag release, never on a passive appearance. */
fun <T> appleMomentumSpring(response: Float = 0.4f): SpringSpec<T> = appleSpring(damping = 0.8f, response = response)

/**
 * §6 — Apple's exact momentum-projection function from the Designing
 * Fluid Interfaces sample code. Projects where a flick's momentum would
 * naturally settle, so a snap target can be chosen from the projected
 * point instead of the raw release point — "take a small input and make
 * a big output." decelerationRate ≈ 0.998 for normal scroll feel.
 */
fun project(initialVelocityPxPerSec: Float, decelerationRate: Float = 0.998f): Float =
    (initialVelocityPxPerSec / 1000f) * decelerationRate / (1f - decelerationRate)

/**
 * §9 — progressive edge resistance instead of a hard stop. The further
 * past the boundary, the less the content follows the finger.
 */
fun rubberband(overshoot: Float, dimension: Float, constant: Float = 0.55f): Float =
    (overshoot * dimension * constant) / (dimension + constant * abs(overshoot))

/**
 * §1 + §3 — instant press feedback that animates from whatever the
 * *current* on-screen scale is (not a fixed keyframe), so a rapid
 * double-tap or an interrupted press never jump-cuts. Deliberately not
 * `clickable`'s ripple alone: §1 wants the response on pointer-DOWN, not
 * release, and the scale-down here starts the instant a finger lands.
 */
fun Modifier.pressScale(pressedScale: Float = 0.97f, haptic: Boolean = true, onTap: () -> Unit): Modifier = composed {
    val scale = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()
    val haptics = LocalHapticFeedback.current
    val reduceMotion = rememberReducedMotionPreference()
    val downSpring = if (reduceMotion) appleSpring<Float>(damping = 1f, response = 0.08f) else appleSpring(damping = 1f, response = 0.15f)
    val upSpring = if (reduceMotion) appleSpring<Float>(damping = 1f, response = 0.08f) else appleSpring(damping = 0.8f, response = 0.3f)
    val pressTarget = if (reduceMotion) 1f else pressedScale // §14: drop the visible squash, keep the tap itself instant

    this
        .graphicsLayer { scaleX = scale.value; scaleY = scale.value }
        .pointerInput(pressedScale, reduceMotion) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                // §1 — feedback on pointer-down, not release.
                if (haptic) haptics.tap()
                scope.launch { scale.animateTo(pressTarget, downSpring) }
                val up = waitForUpOrCancellation()
                scope.launch { scale.animateTo(1f, upSpring) }
                if (up != null) onTap()
            }
        }
}

/**
 * §2/§6/§9 — swipe-to-reveal-delete for list rows, replacing a static
 * always-visible delete icon. 1:1 horizontal tracking while dragging;
 * past the threshold the row rubber-bands (§9) so it still resists
 * rather than sliding freely off-screen; on release, momentum (§6)
 * decides commit-vs-snap-back the same way the cover flow decides which
 * page to land on — not just a raw distance check — so a fast short
 * flick can still commit and a slow long drag can still cancel. A
 * `snap()` haptic marks the commit threshold being crossed, matching
 * §13's causality rule (fire exactly when the state actually flips).
 */
fun Modifier.swipeToDelete(
    thresholdPx: Float = 220f,
    onDelete: () -> Unit,
): Modifier = composed {
    val offsetX = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val haptics = LocalHapticFeedback.current

    this
        .graphicsLayer { translationX = offsetX.value }
        .pointerInput(thresholdPx) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val velocityTracker = VelocityTracker()
                var crossedThreshold = false
                horizontalDrag(down.id) { change ->
                    velocityTracker.addPosition(change.uptimeMillis, change.position)
                    val raw = offsetX.value + change.positionChange().x
                    val proposed = min(0f, raw) // only swipe left-to-delete
                    val overshoot = -proposed - thresholdPx
                    val clamped = if (overshoot > 0f) {
                        -thresholdPx - rubberband(overshoot, thresholdPx, constant = 0.3f)
                    } else proposed
                    scope.launch { offsetX.snapTo(clamped) }
                    val nowPast = clamped <= -thresholdPx
                    if (nowPast != crossedThreshold) haptics.snap()
                    crossedThreshold = nowPast
                }
                val velocity = velocityTracker.calculateVelocity().x
                val projected = offsetX.value + project(velocity)
                val shouldDelete = projected <= -thresholdPx
                if (shouldDelete) {
                    scope.launch {
                        offsetX.animateTo(-1200f, appleMomentumSpring(), initialVelocity = velocity)
                        onDelete()
                    }
                } else {
                    scope.launch { offsetX.animateTo(0f, appleSpring(), initialVelocity = velocity) }
                }
            }
        }
}
