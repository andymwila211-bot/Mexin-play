package tech.softclicks.mexinplay.core.ui.glass

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import android.provider.Settings

/**
 * §12 — translucent materials as a floating functional layer, not an
 * opaque fill. Every surface in the shell (top pills, search field,
 * bottom sheets, the Pulse/Flux switch) should be built from one of
 * these tiers instead of a flat `Color(0xFF1A1A1F)` box, so hierarchy
 * reads from material weight the way the skill describes it — heavier,
 * darker material for structural chrome, lighter material to draw the
 * eye to what's interactive.
 *
 * No blur: see the fix note on `glassSurface` below for why. `blurRadius`
 * is kept on the enum (unused) rather than removed, so a future real
 * backdrop-blur implementation has weight-appropriate values ready.
 */
enum class GlassWeight(val tint: Color, val blurRadius: Float, val borderAlpha: Float) {
    /** Small chips/pills — buttons, badges. Lightest material, draws the eye. */
    Light(tint = Color(0xF01C1C22), blurRadius = 18f, borderAlpha = 0.10f),

    /** Cards, rows, the switch track. Medium weight. */
    Regular(tint = Color(0xF4151519), blurRadius = 24f, borderAlpha = 0.08f),

    /** Sheets, structural panels behind other content. Heaviest, darkest. */
    Heavy(tint = Color(0xF80E0E12), blurRadius = 32f, borderAlpha = 0.06f),
}

/**
 * Applies a glass material: a tinted fill and a bright top-catching-light
 * edge per §12's CSS example (`border-top: 1px solid rgba(255,255,255,0.4)`).
 * Never stack two `Light` surfaces — the skill calls this out explicitly,
 * legibility collapses.
 *
 * BUG FIX (was here): this used to also apply a `RenderEffect` blur via
 * `graphicsLayer { renderEffect = ... }` directly on the modifier chain of
 * the composable itself — e.g. the `Row` containing the "New Playlist"
 * Icon + Text. In Compose, a `graphicsLayer` modifier rasterizes and
 * blurs *everything drawn inside that layout node*, which includes its
 * children. Since `glassSurface` is applied straight onto content-bearing
 * Rows/Boxes (not a separate background-only layer), the blur was hitting
 * the pill's own label text and icon, not "the backdrop behind it" — the
 * comment above claimed it blurred "the layer's own content + tint," but
 * the tint is a flat solid color, and blurring a flat color is a visual
 * no-op. There was nothing else in that layer for the blur to usefully
 * affect except the children — which is exactly the smeared, illegible
 * "New Playlist" pill in the screenshot. It wasn't a rare edge case; it
 * fired on every glass surface that had text/icon content, all the time.
 *
 * Real backdrop-blur-behind (blurring whatever content actually sits
 * underneath the pill) isn't a modifier-chain-level effect at all on
 * Android — it needs a shared composited snapshot of the layer behind the
 * surface (Compose 1.7+'s `GraphicsLayer.record`/`drawLayer` snapshot
 * APIs, or an AGSL backdrop shader keyed to a captured frame), which is a
 * bigger, separate change. Until that lands, a flat tint + edge highlight
 * is the honest "frosted chip" look — legible, cheap, and correct on every
 * API level — rather than a broken effect that happens to look "glassy"
 * by accident of blurring text.
 */
@Composable
fun Modifier.glassSurface(
    shape: Shape = RoundedCornerShape(20.dp),
    weight: GlassWeight = GlassWeight.Regular,
): Modifier {
    val reduceTransparency = rememberReducedTransparencyPreference()
    val fillAlphaBoost = if (reduceTransparency) 0.35f else 0f // near-solid fallback per §14

    return this
        .clip(shape)
        .background(weight.tint.copy(alpha = (weight.tint.alpha + fillAlphaBoost).coerceAtMost(1f)))
        .border(width = 1.dp, brush = topEdgeHighlight(weight.borderAlpha), shape = shape)
}

/** The "light catching the material" edge — bright at top, fading out, per §12. */
private fun topEdgeHighlight(baseAlpha: Float): Brush = Brush.verticalGradient(
    colors = listOf(Color.White.copy(alpha = baseAlpha * 2.5f), Color.White.copy(alpha = baseAlpha * 0.3f)),
)

/**
 * §14 — `prefers-reduced-transparency` equivalent. Android exposes no
 * direct API for this, so this reads the closest system signal
 * (Settings.Global "transition_animation_scale" == 0, which is what
 * users with "Remove animations" / high-contrast-adjacent accessibility
 * settings tend to also have set) as a heuristic. Defaults to false —
 * i.e. full glass — when the signal is unavailable rather than guessing
 * transparency is unwanted.
 */
@Composable
fun rememberReducedTransparencyPreference(): Boolean {
    val context = LocalContext.current
    return remember(context) {
        runCatching {
            Settings.Global.getFloat(context.contentResolver, Settings.Global.TRANSITION_ANIMATION_SCALE, 1f) == 0f
        }.getOrDefault(false)
    }
}
