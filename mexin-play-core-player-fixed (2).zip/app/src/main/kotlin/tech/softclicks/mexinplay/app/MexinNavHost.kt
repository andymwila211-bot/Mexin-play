package tech.softclicks.mexinplay.app

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetValue
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import tech.softclicks.mexinplay.core.ui.glass.AppTypography
import tech.softclicks.mexinplay.core.ui.glass.GlassWeight
import tech.softclicks.mexinplay.core.ui.glass.appleSpring
import tech.softclicks.mexinplay.core.ui.glass.glassSurface
import tech.softclicks.mexinplay.core.ui.glass.pressScale
import tech.softclicks.mexinplay.core.ui.glass.rememberReducedMotionPreference
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.launch
import tech.softclicks.mexinplay.core.player.PlaybackController
import tech.softclicks.mexinplay.core.player.model.PlayableItem
import tech.softclicks.mexinplay.core.ui.glass.AuraBackground
import tech.softclicks.mexinplay.core.ui.glass.ShellColors
import tech.softclicks.mexinplay.feature.flux.FluxHomeScreen
import tech.softclicks.mexinplay.feature.pulse.PulseHomeScreen

private const val ROUTE_LIBRARY = "library"
private const val ROUTE_PULSE = "pulse"
private const val ROUTE_FLUX = "flux"

/** Local overlay state for the playlist screens — kept out of NavController's back stack since
 *  these sit above Pulse/Flux as full-screen overlays, not sibling destinations in the pill. */
private sealed class PlaylistOverlay {
    object Hidden : PlaylistOverlay()
    object List : PlaylistOverlay()
    data class Detail(val playlistId: Long, val playlistName: String) : PlaylistOverlay()
}

/**
 * Library is the permanent root; Pulse/Flux are peer destinations reached
 * from it, not stacked on top of each other. popUpTo the graph's start
 * destination (with saveState) before navigating means switching Pulse
 * <-> Flux via the bottom pill replaces one for the other instead of
 * piling up an infinite back stack, and — the actual point — pressing
 * back from either player returns to Library, not to the other player.
 * Standard Navigation-Compose bottom-nav idiom, applied here because the
 * graph shape now has a real root screen instead of Pulse being it.
 */
private fun navigateToSection(navController: NavController, route: String) {
    navController.navigate(route) {
        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

/**
 * Top-level shell. Flat backdrop, no color-morphing glow — Pulse and
 * Flux are visually distinct through layout, not a shared decorative
 * effect. Discover is a real sub-screen (ModalBottomSheet), not an
 * inline list on the player — reached via a button on each player
 * screen, opens at half height, and has an explicit expand control
 * since drag-to-expand alone isn't discoverable. The two utility
 * buttons (Playlists, Search) sit on opposite top corners as pills,
 * not stacked together as circles.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MexinNavHost(playbackController: PlaybackController, viewModel: MexinPlayViewModel) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ROUTE_LIBRARY

    val pulseQueue by viewModel.pulseQueue.collectAsState()
    val fluxQueue by viewModel.fluxQueue.collectAsState()
    val nowPlaying by viewModel.nowPlaying.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val playlists by viewModel.playlists.collectAsState()

    var isSearchOpen by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var playlistOverlay by remember { mutableStateOf<PlaylistOverlay>(PlaylistOverlay.Hidden) }
    var addToPlaylistItem by remember { mutableStateOf<PlayableItem?>(null) }
    var isDiscoverOpen by remember { mutableStateOf(false) }

    fun filtered(items: List<PlayableItem>): List<PlayableItem> {
        if (searchQuery.isBlank()) return items
        return items.filter { it.title.contains(searchQuery, ignoreCase = true) }
    }

    Box(modifier = Modifier.fillMaxSize().background(ShellColors.base)) {
        AuraBackground()

        NavHost(navController = navController, startDestination = ROUTE_LIBRARY) {
            composable(ROUTE_LIBRARY) {
                LibraryHomeScreen(
                    onOpenPulse = { navigateToSection(navController, ROUTE_PULSE) },
                    onOpenFlux = { navigateToSection(navController, ROUTE_FLUX) },
                    onOpenPlaylists = { playlistOverlay = PlaylistOverlay.List },
                )
            }
            composable(ROUTE_PULSE) {
                PulseHomeScreen(
                    nowPlaying = nowPlaying,
                    isPlaying = isPlaying,
                    onPlayPause = { viewModel.togglePlayPause() },
                    onNext = { viewModel.playNext() },
                    onPrevious = { viewModel.playPrevious() },
                    onOpenDiscover = { isDiscoverOpen = true },
                    playbackController = playbackController,
                )
            }
            composable(ROUTE_FLUX) {
                FluxHomeScreen(
                    nowPlaying = nowPlaying,
                    isPlaying = isPlaying,
                    onPlayPause = { viewModel.togglePlayPause() },
                    onNext = { viewModel.playNext() },
                    onPrevious = { viewModel.playPrevious() },
                    onOpenDiscover = { isDiscoverOpen = true },
                    playbackController = playbackController,
                )
            }
        }

        when (val overlay = playlistOverlay) {
            is PlaylistOverlay.List -> {
                Box(modifier = Modifier.fillMaxSize().background(ShellColors.base)) {
                    PlaylistsScreen(
                        playlists = playlists,
                        onCreatePlaylist = { viewModel.createPlaylist(it) },
                        onDeletePlaylist = { viewModel.deletePlaylist(it) },
                        onOpenPlaylist = { id ->
                            val name = playlists.firstOrNull { it.id == id }?.name.orEmpty()
                            playlistOverlay = PlaylistOverlay.Detail(id, name)
                        },
                        onBack = { playlistOverlay = PlaylistOverlay.Hidden },
                    )
                }
            }
            is PlaylistOverlay.Detail -> {
                val tracks by remember(overlay.playlistId) { viewModel.tracksForPlaylist(overlay.playlistId) }
                    .collectAsState(initial = emptyList())
                Box(modifier = Modifier.fillMaxSize().background(ShellColors.base)) {
                    PlaylistDetailScreen(
                        playlistName = overlay.playlistName,
                        tracks = tracks,
                        onPlay = { viewModel.play(it, tracks) },
                        onRemove = { mediaId -> viewModel.removeFromPlaylist(overlay.playlistId, mediaId) },
                        onBack = { playlistOverlay = PlaylistOverlay.List },
                    )
                }
            }
            PlaylistOverlay.Hidden -> Unit
        }

        if (isDiscoverOpen) {
            val screenHeightDp = LocalConfiguration.current.screenHeightDp.dp
            val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)
            val isExpanded = sheetState.currentValue == SheetValue.Expanded
            val queue = if (currentRoute == ROUTE_FLUX) fluxQueue else pulseQueue
            val coroutineScope = rememberCoroutineScope()

            ModalBottomSheet(
                onDismissRequest = { isDiscoverOpen = false },
                sheetState = sheetState,
                containerColor = GlassWeight.Heavy.tint,
            ) {
                Box(modifier = Modifier.fillMaxWidth().height(if (isExpanded) screenHeightDp * 0.9f else screenHeightDp * 0.5f)) {
                    DiscoverSheetContent(
                        items = filtered(queue),
                        isExpanded = isExpanded,
                        onToggleExpand = {
                            coroutineScope.launch {
                                if (isExpanded) sheetState.partialExpand() else sheetState.expand()
                            }
                        },
                        onSelectItem = { viewModel.play(it, queue) },
                        onLongPressItem = { addToPlaylistItem = it },
                    )
                }
            }
        }

        addToPlaylistItem?.let { item ->
            val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
            ModalBottomSheet(
                onDismissRequest = { addToPlaylistItem = null },
                sheetState = sheetState,
                containerColor = GlassWeight.Heavy.tint,
            ) {
                AddToPlaylistSheetContent(
                    item = item,
                    playlists = playlists,
                    onPickPlaylist = { id -> viewModel.addToPlaylist(id, item); addToPlaylistItem = null },
                    onCreateAndAdd = { name -> viewModel.createPlaylistAndAdd(name, item); addToPlaylistItem = null },
                )
            }
        }

        val isOnPlayerScreen = currentRoute == ROUTE_PULSE || currentRoute == ROUTE_FLUX

        if (playlistOverlay == PlaylistOverlay.Hidden && isOnPlayerScreen) {
            if (isSearchOpen) {
                SearchOverlay(
                    query = searchQuery,
                    onQueryChange = { searchQuery = it },
                    onClose = { isSearchOpen = false; searchQuery = "" },
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 20.dp, start = 20.dp, end = 20.dp),
                )
            } else {
                // Split to opposite corners for symmetry, not stacked together.
                TopPillButton(
                    icon = Icons.Filled.PlaylistPlay,
                    label = "Lists",
                    contentDescription = "Playlists",
                    modifier = Modifier.align(Alignment.TopStart).padding(top = 20.dp, start = 20.dp),
                    onClick = { playlistOverlay = PlaylistOverlay.List },
                )
                TopPillButton(
                    icon = Icons.Filled.Search,
                    label = "Search",
                    contentDescription = "Search",
                    modifier = Modifier.align(Alignment.TopEnd).padding(top = 20.dp, end = 20.dp),
                    onClick = { isSearchOpen = true },
                )
            }

            // Both reference screens — portrait Pulse and landscape Flux —
            // anchor the pill bottom-center, so one placement covers both.
            // Only shown once "inside" a player — Library is the picker,
            // this pill is for flipping between sections once you're in one.
            PulseFluxSwitch(
                currentRoute = currentRoute,
                onSelect = { route -> navigateToSection(navController, route) },
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp),
            )
        }
    }
}

/**
 * Redesign pass on the shell chrome: pills and the switch track are now
 * real glass materials (§12 — Light weight, since these sit on top of
 * everything and should draw the eye) instead of a flat fill color, and
 * every tap target uses [pressScale] so pointer-down gives instant
 * feedback (§1) instead of relying on `clickable`'s ripple alone.
 */
@Composable
private fun TopPillButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .glassSurface(shape = RoundedCornerShape(50), weight = GlassWeight.Light)
            .pressScale(pressedScale = 0.95f) { onClick() }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = contentDescription, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = label, style = AppTypography.bodyMuted, color = Color.White.copy(alpha = 0.8f))
    }
}

/**
 * §12 "materialize, don't just fade" — scales up from the pill it
 * replaces rather than simply appearing, so the search field reads as
 * the same chrome taking a new shape (§7 — hint in the direction of the
 * gesture: it grows from where the search pill was, top-right).
 */
@Composable
private fun SearchOverlay(
    query: String,
    onQueryChange: (String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val reduceMotion = rememberReducedMotionPreference()
    val entrance = remember { Animatable(if (reduceMotion) 1f else 0.85f) }
    LaunchedEffect(Unit) { entrance.animateTo(1f, appleSpring(damping = 1f, response = 0.3f)) }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = entrance.value
                scaleY = entrance.value
                transformOrigin = androidx.compose.ui.graphics.TransformOrigin(1f, 0f) // anchored to the top-right trigger, per §7
            }
            .glassSurface(shape = RoundedCornerShape(24.dp), weight = GlassWeight.Regular)
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Search, contentDescription = null, tint = Color.White.copy(alpha = 0.5f), modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Box(modifier = Modifier.weight(1f)) {
            if (query.isEmpty()) {
                Text("Search your library", style = AppTypography.body, color = Color.White.copy(alpha = 0.4f))
            }
            BasicTextField(
                value = query,
                onValueChange = onQueryChange,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                cursorBrush = androidx.compose.ui.graphics.SolidColor(Color.White),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Icon(
            Icons.Filled.Close,
            contentDescription = "Close search",
            tint = Color.White.copy(alpha = 0.6f),
            modifier = Modifier.size(18.dp).pressScale(pressedScale = 0.9f, onTap = onClose),
        )
    }
}

/**
 * The selected-segment pill now slides between Pulse/Flux with a real
 * spring (§4/§5) instead of each segment independently swapping its own
 * background — one continuous piece of chrome moving, not two static
 * states blinking between each other. `BoxWithConstraints` gives the
 * track's real measured width so the indicator's travel distance is
 * exact rather than guessed.
 */
@Composable
private fun PulseFluxSwitch(
    currentRoute: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val reduceMotion = rememberReducedMotionPreference()
    androidx.compose.foundation.layout.BoxWithConstraints(
        modifier = modifier
            .glassSurface(shape = RoundedCornerShape(30.dp), weight = GlassWeight.Light)
            .padding(5.dp),
    ) {
        val segmentWidth = maxWidth / 2
        val indicatorOffset = remember { Animatable(if (currentRoute == ROUTE_FLUX) 1f else 0f) }
        val target = if (currentRoute == ROUTE_FLUX) 1f else 0f
        LaunchedEffect(target) {
            val spec = if (reduceMotion) appleSpring<Float>(damping = 1f, response = 0.2f) else appleSpring(damping = 0.85f, response = 0.35f)
            indicatorOffset.animateTo(target, spec)
        }

        Box(
            modifier = Modifier
                .width(segmentWidth)
                .height(44.dp)
                .graphicsLayer { translationX = indicatorOffset.value * segmentWidth.toPx() }
                .clip(RoundedCornerShape(24.dp))
                .background(Color.White),
        )

        Row {
            SwitchSegment(
                label = "Pulse",
                icon = Icons.Filled.GraphicEq,
                selected = currentRoute == ROUTE_PULSE,
                width = segmentWidth,
                onClick = { onSelect(ROUTE_PULSE) },
            )
            SwitchSegment(
                label = "Flux",
                icon = Icons.Filled.AutoAwesome,
                selected = currentRoute == ROUTE_FLUX,
                width = segmentWidth,
                onClick = { onSelect(ROUTE_FLUX) },
            )
        }
    }
}

@Composable
private fun SwitchSegment(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    width: androidx.compose.ui.unit.Dp,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .width(width)
            .clip(RoundedCornerShape(24.dp))
            .pressScale(pressedScale = 0.96f, haptic = !selected) { onClick() }
            .padding(horizontal = 22.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (selected) Color.Black else Color.White.copy(alpha = 0.55f),
            modifier = Modifier.height(16.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = label,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (selected) Color.Black else Color.White.copy(alpha = 0.6f),
        )
    }
}
