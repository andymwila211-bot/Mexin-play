package tech.softclicks.mexinplay.core.ui.glass

import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import android.provider.Settings

/**
 * §12 — translucent materials as a floating functional layer, not an
 * opaque fill. Every surface in the shell (top pills, search field,
 * bottom sheets, the Pulse/Flux switch) should be built from one of
 * these tiers instead of a flat `Color(0xFF1A1A1F)` box, so hierarchy
 * reads from material weight the way the skill describes it — heavier,
 * darker material for structural chrome, lighter material to draw the
 * eye to what's interactive.
 *
 * `backdrop-filter` has no direct Compose equivalent, so this blurs the
 * layer's own content + a translucent tint rather than what's *behind*
 * it (RenderEffect blur-behind needs a graphics layer capture API that
 * isn't exposed pre-API 31 either way) — visually the same "frosted"
 * read the skill asks for, at a fraction of the complexity, and it
 * degrades safely: `prefers-reduced-transparency` and API <31 both fall
 * back to a near-solid tint with no blur (§14 — frostier/solid, not a
 * broken visual).
 */
enum class GlassWeight(val tint: Color, val blurRadius: Float, val borderAlpha: Float) {
    /** Small chips/pills — buttons, badges. Lightest material, draws the eye. */
    Light(tint = Color(0xF01C1C22), blurRadius = 18f, borderAlpha = 0.10f),

    /** Cards, rows, the switch track. Medium weight. */
    Regular(tint = Color(0xF4151519), blurRadius = 24f, borderAlpha = 0.08f),

    /** Sheets, structural panels behind other content. Heaviest, darkest. */
    Heavy(tint = Color(0xF80E0E12), blurRadius = 32f, borderAlpha = 0.06f),
}

/**
 * Applies a glass material: blur (where supported + allowed), a tinted
 * fill, and a bright top-catching-light edge per §12's CSS example
 * (`border-top: 1px solid rgba(255,255,255,0.4)`). Never stack two
 * `Light` surfaces — the skill calls this out explicitly, legibility
 * collapses.
 */
@Composable
fun Modifier.glassSurface(
    shape: Shape = RoundedCornerShape(20.dp),
    weight: GlassWeight = GlassWeight.Regular,
): Modifier {
    val reduceTransparency = rememberReducedTransparencyPreference()
    val effectiveBlur = if (reduceTransparency || Build.VERSION.SDK_INT < Build.VERSION_CODES.S) 0f else weight.blurRadius
    val fillAlphaBoost = if (reduceTransparency) 0.35f else 0f // near-solid fallback per §14

    return this
        .clip(shape)
        .then(
            if (effectiveBlur > 0f) {
                Modifier.graphicsLayer {
                    renderEffect = RenderEffect
                        .createBlurEffect(effectiveBlur, effectiveBlur, Shader.TileMode.CLAMP)
                        .asComposeRenderEffect()
                }
            } else Modifier,
        )
        .background(weight.tint.copy(alpha = (weight.tint.alpha + fillAlphaBoost).coerceAtMost(1f)))
        .border(width = 1.dp, brush = topEdgeHighlight(weight.borderAlpha), shape = shape)
}

/** The "light catching the material" edge — bright at top, fading out, per §12. */
private fun topEdgeHighlight(baseAlpha: Float): Brush = Brush.verticalGradient(
    colors = listOf(Color.White.copy(alpha = baseAlpha * 2.5f), Color.White.copy(alpha = baseAlpha * 0.3f)),
)

/**
 * §14 — `prefers-reduced-transparency` equivalent. Android exposes no
 * direct API for this, so this reads the closest system signal
 * (Settings.Global "transition_animation_scale" == 0, which is what
 * users with "Remove animations" / high-contrast-adjacent accessibility
 * settings tend to also have set) as a heuristic. Defaults to false —
 * i.e. full glass — when the signal is unavailable rather than guessing
 * transparency is unwanted.
 */
@Composable
fun rememberReducedTransparencyPreference(): Boolean {
    val context = LocalContext.current
    return remember(context) {
        runCatching {
            Settings.Global.getFloat(context.contentResolver, Settings.Global.TRANSITION_ANIMATION_SCALE, 1f) == 0f
        }.getOrDefault(false)
    }
}
