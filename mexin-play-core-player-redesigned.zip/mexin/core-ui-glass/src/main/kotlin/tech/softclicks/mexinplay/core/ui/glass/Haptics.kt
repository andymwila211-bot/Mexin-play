package tech.softclicks.mexinplay.core.ui.glass

import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType

/**
 * §13 — three rules for multimodal feedback: causality (fire on the
 * actual causal event, not a nearby proxy), harmony (visual + haptic on
 * the same frame — call this from the same callback that commits the
 * visual change, never from a LaunchedEffect a frame later), and
 * utility (reserve for meaningful moments; over-feedback trains people
 * to ignore all of it). These names document *which* moment each call
 * site should fire on — don't sprinkle `tick()` on every recomposition.
 */

/** A light tap: pointer-down on a button, a segment switch committing. */
fun HapticFeedback.tap() = performHapticFeedback(HapticFeedbackType.TextHandleMove)

/** A snap/settle: a scrubber landing on a value, a card docking into place, a swipe-to-delete threshold crossing. */
fun HapticFeedback.snap() = performHapticFeedback(HapticFeedbackType.GestureEnd)

/** A commit with consequence: deleting a playlist, removing a track. Reserved — not for routine navigation. */
fun HapticFeedback.confirm() = performHapticFeedback(HapticFeedbackType.LongPress)
